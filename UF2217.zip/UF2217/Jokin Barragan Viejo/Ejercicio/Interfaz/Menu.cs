﻿using System;

namespace Interfaz
{
	public static class Menu
	{
		public static int anchoTotal = Estilo.anchoTotal;
		public static int seccion = -1;
		public static int seccionOpcion = -1;
		public static char opcion = '0';

		//Diferentes opciones del menu
		public static readonly char[] opciones = { 'S', 'O', 'X' };
		private static readonly string[] secciones = { "Clientes", "Artículos", "Categorías" };
		private static readonly string[][] opcionesSeccion = new string[][]
		{
			new string[] {"Ver listado", "Nuevo cliente", "Buscar cliente por Id", "Buscar cliente por nombre", "Buscar cliente por un campo expecificado", "Editar cliente", "Borrar cliente" },
			new string[] {}, //Es una seccion de ejemplo, sin opciones (Artículos)
			new string[] {}  //Es una seccion de ejemplo, sin opciones (Categorías)
		};

		//Cada vez que el usuario introduce un texto y pasa por esta función, determina si
		//es una opción de los diferentes menus. Siempre devuelve el texto, por si no es una opción 
		public static string Comandos(string comando = "")
		{
			if (!SetOpcion(comando))
			{
				if (opcion == 'S')
				{
					SetSeccion(comando);
					opcion = (seccion > -1) ? 'O' : 'S';
				}else if(opcion == 'O'){
					SetOpcionSeccion(comando);
					opcion = '0';
				}
			}
			return comando;
		}

		//muestra los menus en diferentes estados segun lo que ha ido introduciendo el usuario mediante la funcion Comandos
		public static void Nav()
		{
			switch (opcion)
			{
				case 'S':
					ShowMenu();
					seccionOpcion = -1;
					//ConsoleEx.Com();
					//Comandos(Console.ReadLine());
					break;
				case 'O':
					if (seccion > -1)
					{
						ShowMenu(false);
						ShowSeccionOpciones();
					}
					else
					{
						ShowMenu();
					}
					//ConsoleEx.Com();
					//Comandos(Console.ReadLine());
					break;
				case 'X':
					System.Environment.Exit(0);
					break;
				case '0':
					if (seccion > -1 && seccionOpcion > -1)
					{
						ShowMenu(false);
					}
					else
					{
						ShowMenu();
						opcion = 'S';
					}
					break;
			}
		}

		//Cambia la variable opcion general si existe el comando recivido en el array de opciones
		public static bool SetOpcion(string comando)
		{
			if (Char.TryParse(comando, out char c))
			{
				if (Array.Exists(opciones, o => o == c))
				{
					opcion = c;
					return true;
				}
			}
			return false;
		}

		//Cambia la variable seccion si existe el indice recivido en el array de secciones
		public static bool SetSeccion(string comando)
		{
			if (!SetOpcion(comando))
			{
				if (Int32.TryParse(comando, out int c))
				{
					if (c <= secciones.Length)
					{
						seccion = c - 1;
						return true;
					}
				}
			}
			return false;
		}

		//Cambia la variable opcion de seccion si existe el indice en el array opciones de seccion
		public static bool SetOpcionSeccion(string comando)
		{
			if (!SetOpcion(comando))
			{
				if (Int32.TryParse(comando, out int c))
				{
					if (seccion > -1 && c <= opcionesSeccion[seccion].Length)
					{
						seccionOpcion = c - 1;
						return true;
					}
				}
			}
			return false;
		}

		//Muestra el menu de secciones y opciones generales
		public static void ShowMenu(bool activo = true)
		{
			int anchoRestante = anchoTotal - 1;
			string s;
			//Pinta las secciones
			for (int i = 0; i < secciones.Length; i++)
			{
				if (seccion == i)
				{
					Console.BackgroundColor = ConsoleColor.DarkYellow;
				}
				else{
					Console.BackgroundColor = (activo) ? ConsoleColor.DarkCyan : ConsoleColor.DarkGray;
				}
				s= (activo) ? $" [{i + 1}] {secciones[i]} " : $" [ ] {secciones[i]} ";
				Console.Write(s);
				anchoRestante -= s.Length;
			}

			//Pinta las opciones generales
			Console.BackgroundColor = (activo) ? ConsoleColor.DarkCyan : ConsoleColor.DarkGray;
			Console.ForegroundColor = ConsoleColor.White;
			if (!activo)
			{
				Console.WriteLine(string.Format("{0," + anchoRestante + "}", " [S] Seccion [O] Opciones "));
			}
			else
			{
				Console.WriteLine(string.Format("{0," + anchoRestante + "}", (seccion > -1) ? " [O] Opciones " : " "));
			}
			Console.ResetColor();
		}

		//Muestra el menu de opcines de seccion
		public static void ShowSeccionOpciones()
		{
			if (seccion > -1)
			{
				Menu.seccionOpcion = -1;
				if (opcionesSeccion[seccion].Length > 0)
				{
					Console.BackgroundColor = ConsoleColor.DarkGray;
					for (int i = 0; i < opcionesSeccion[seccion].Length; i++)
					{
						Console.WriteLine($" [{i + 1}] {opcionesSeccion[seccion][i],-40} ");
					}
				}
				else
				{
					Console.WriteLine("Sección en construcción. No hay opciones. ");
				}
				Console.ResetColor();
			}
		}
	}
}
