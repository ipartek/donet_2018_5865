﻿using System;
using Utilidades;

namespace Interfaz
{
	public static class Estilo
	{
		//Pinta una marca que indica se puede introducir una opcion/comando
		public static void Com()
		{
			Console.WriteLine();
			Console.BackgroundColor = ConsoleColor.DarkCyan;
			Console.ForegroundColor = ConsoleColor.Black;
			Console.Write(" Com -> ");
			Console.ResetColor();
			Console.Write(" ");
		}

		public static int anchoTotal = 120;

		public static void SeccionTitulo(string s)
		{
			ConsoleEx.WriteLineColor(string.Format(" {0,-" + (anchoTotal - 2) + " }", ""), ConsoleColor.Gray, ConsoleColor.Black);
			ConsoleEx.WriteLineColor(string.Format(" {0,-" + (anchoTotal - 2) + " }", s), ConsoleColor.Gray, ConsoleColor.Black);
			ConsoleEx.WriteLineColor(string.Format(" {0,-" + (anchoTotal - 2) + " }", ""), ConsoleColor.Gray, ConsoleColor.Black);
			Console.WriteLine();
		}

		public static void MsgOk(string s)
		{
			ConsoleEx.WriteLineColor($"{s}", ConsoleColor.Black, ConsoleColor.DarkGreen);
		}

		public static void MsgInfo(string s)
		{
			ConsoleEx.WriteLineColor($"{s}", ConsoleColor.Black, ConsoleColor.DarkCyan);
		}

		public static void MsgError(string s)
		{
			ConsoleEx.WriteLineColor($" {s} ", ConsoleColor.DarkRed, ConsoleColor.White);
		}

		public static void MsgConfirmar(string s)
		{
			ConsoleEx.WriteColor($" {s} (Y/N)", ConsoleColor.DarkRed, ConsoleColor.White);
			Console.Write(" ");
		}

		public static void MsgCampo(string s)
		{
			ConsoleEx.WriteColor($" {s} :", ConsoleColor.DarkCyan, ConsoleColor.Black);
			Console.Write(" ");

		}
	}
}
