﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipos
{
	//Necesito hacer un tipo Fecha en vez de usar el DateTime directamente,
	//y que las fechas me devuelvan un formato concreto con un simple ToString
	//sin argumentos, para hacer la busqueda de cliente por nombre de campo
	//de forma genérica para todos los campos. (Acceso a las propiedades por indice) 
	public class Fecha 
	{
		public DateTime Dt { get; set; }

		public Fecha(DateTime fecha)
		{
			Dt = fecha;
		}

		//suma años a un tipo Fecha
		public DateTime AddYears(int n)
		{
			return Dt.AddYears(n);
		}

		public override string ToString()
		{
			return string.Format(Dt.ToString("dd/MM/yyyy"));
		}
	}
}
