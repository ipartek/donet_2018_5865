﻿using System;
using System.Reflection;
using System.Text.RegularExpressions;
using Utilidades;

namespace Tipos
{
	public class Cliente
	{
		private string nombre;
		private string apellidos;
		private string email;
		private Fecha fnacimiento;

		public int Id { get; set; }
		public string Nombre
		{
			get { return nombre; }
			set { nombre = ValidarValor(value, 0).ToTitleCase(); }
		}
		public string Apellidos
		{
			get { return apellidos; }
			set { apellidos = ValidarValor(value, 1).ToTitleCase(); }
		}
		public Dni Dni { get; set; }
		public string Email
		{
			get { return email; }
			set { email = ValidarValor(value, 2).ToLower(); }
		}
		public Fecha Fnacimiento
		{
			get { return fnacimiento; }
			set
			{
				if (value.AddYears(18) > DateTime.Now)
				{
					throw new Excepcion("No se peude dar de alta a un menor de edad.");
				}
				fnacimiento = value;
			}
		}
		public string Nacionalidad
		{
			get
			{
				return (Dni.EsNacional()) ? "Español" : "Extranjero"; ;
			}
		}


		//Para validar todos los campos de cliente
		private string ValidarValor(string value, int idCampo)
		{
			value = value.Trim();
			value = Regex.Replace(value, @"\s+", " ");
			if (value == null)
			{
				throw new Excepcion("No se admite campo nulo");
			}

			if (value.Length == 0)
			{
				throw new Excepcion("Campo obligatorio");
			}

			if (!Regex.IsMatch(value, RegEx[idCampo]))
			{
				throw new Excepcion(errorMSG[idCampo]);
			}

			return value;
		}

		//Sirve para acceder al valor de las propiedades de cliente mediante un indice. cliente['Nombre']
		public object this[string key]
		{
			get
			{
				PropertyInfo propiedad = this.GetType().GetProperty(key);
				if (propiedad == null)
				{
					return null; //devuelve nulo si no existe la propiedad
				}

				return propiedad.GetValue(this, null); //devuelve, creo, el valor de la propiedad
													   //return propiedad.Name;
			}
		}

		//Errores devueltos por el validador
		private static readonly string[] errorMSG = {
			"Formato incorrecto -> Mínimo 2 caracteres.",
			"Formato incorrecto -> Mínimo 2 apellidos con mínimo 2 caracteres cada uno.",
			"Formato incorrecto -> Formato incorrecto, '12345678L' o 'X1234567L'.",
			"Formato incorrecto -> Formato incorrecto, 'nombre@dominio.com'."
		};
		//Expresiones regulares utilizadas por el validador
		private static readonly string[] RegEx = {
			@"^\D{2,}$",
			@"^\D{2,} \D{2,}$",
			@"^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",
			@"^\d{4}\-\d{2}\-\d{2}$"
		};

		public Cliente() { }

		public Cliente(int id, string nombre, string apellidos, string dni, string email, string fnacimiento)
		{
			Id = id;
			Nombre = nombre;
			Apellidos = apellidos;
			Dni = new Dni(dni);
			Email = email;
			Fnacimiento = new Fecha(DateTime.Parse(fnacimiento));
			
		}

		public override string ToString()
		{
			return string.Format($"Id: {Id} | Nombre: {Nombre} | Apellidos: {Apellidos} | DNI/NIE: {Dni} | Email: {Email} | F. nacimiento: {Fnacimiento} | Nacionalidad: {Nacionalidad}");
		}

	}
}
