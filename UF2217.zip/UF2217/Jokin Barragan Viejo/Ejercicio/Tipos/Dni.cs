﻿using System;
using System.Text.RegularExpressions;
using Utilidades;

namespace Tipos
{
	public class Dni
	{
		public string SNumero { get; set; }

		private const string LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE";

		public Dni(string dni)
		{
			if (dni == null)
			{
				throw new Excepcion("No se aceptan DNIs incorrectos");
			}
			else
			{
				dni = dni.ToUpper();
			}
			if (!Regex.IsMatch(dni, @"^[XYZ\d]\d{7}[" + LETRAS + "]$"))
			{
				throw new Excepcion("El formato de DNI no es correcto");
			}
			if (!EsValido(dni))
			{
				throw new Excepcion("El DNI no es válido");
			}
			SNumero = ExtraerNumero(dni);
		}

		public char Letra
		{
			get { return CalcularLetra(SNumero); }
		}

		public static bool EsValido(string dni)
		{
			string sNumero = ExtraerNumero(dni);
			char letra = dni[8];
			return letra == CalcularLetra(sNumero);
		}

		private static string ExtraerNumero(string dni)
		{
			return dni.CutRight(1);
		}

		private static char CalcularLetra(string SN)
		{
			int numero = int.Parse(SN.Replace('X', '0').Replace('Y', '1').Replace('Z', '2'));
			return LETRAS[numero % 23];
		}

		public bool EsNacional()
		{
			char c = SNumero[0];
			return char.IsNumber(c);
		}

		public override string ToString()
		{
			return string.Format($"{SNumero}{Letra}");
		}
	}
}
