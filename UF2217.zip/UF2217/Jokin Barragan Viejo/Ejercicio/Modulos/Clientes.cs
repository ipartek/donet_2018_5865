﻿using System;
using Interfaz;
using Utilidades;
using Tipos;
using System.Text.RegularExpressions;

namespace Modulos
{
	//La seccion de clientes con todas sus opciones y funciones
	public static class Clientes
	{
		private static int CID = 1;
		private static BBDD<Cliente> clientes = new BBDD<Cliente>("BBDDclientes");
		private static Cliente cliente = null;
		public static void Main()
		{
			switch (Menu.seccionOpcion)
			{
				case 0: //Listado clientes
					Estilo.SeccionTitulo("Listado de cliente");
					MostrarCabeceraCliente();
					ListarClientes(clientes);
					Menu.seccionOpcion = -1;
					break;
				case 1: //nuevo cliente
					Estilo.SeccionTitulo("Nueva alta de cliente");
					cliente = new Cliente();
					if (RellenarCliente(cliente) != null)
					{
						cliente.Id = CID;
						CID++;
						clientes.Add(cliente);
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						Estilo.MsgOk("Cliente dado de alta correctamente.");
						Menu.seccionOpcion = -1;
					}
					break;
				case 2: //buscar cliente por Id
					Estilo.SeccionTitulo($"Buscar cliente por campo {celdasLabel[0]}");
					cliente = BuscarClienteCampo(clientes, "Id");
					if (cliente != null)
					{
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						Menu.seccionOpcion = -1;
					}
					break;
				case 3: //buscar cliente por Nombre
					Estilo.SeccionTitulo($"Buscar cliente por campo {celdasLabel[1]}");
					cliente = BuscarClienteCampo(clientes, "Nombre");
					if (cliente != null)
					{
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						Menu.seccionOpcion = -1;
					}
					break;
				case 4: //buscar cliente por un campo expecificado por el usuario
					Estilo.SeccionTitulo("Buscar cliente por un campo expecificado");
					cliente = BuscarClienteCampo(clientes, null);
					if (cliente != null)
					{
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						Menu.seccionOpcion = -1;
					}
					break;
				case 5: //editar cliente
					Estilo.SeccionTitulo("Editar cliente");
					if (cliente == null)
					{
						Estilo.MsgError("No hay un cliente seleccionado. Busca primero un cliente.");
						Menu.seccionOpcion = -1;
					}
					if (cliente != null)
					{
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						Estilo.MsgInfo("Deja el campo vacio si quieres conservar el valor original");
						if (RellenarCliente(cliente,true) != null)
						{
							Estilo.MsgOk("Cliente editado correctamente.");
							Menu.seccionOpcion = -1;
						}
					}
					break;
				case 6: //borrar cliente
					Estilo.SeccionTitulo("Borrar cliente");
					if (cliente == null)
					{
						Estilo.MsgError("No hay un cliente seleccionado. Busca primero un cliente.");
						Menu.seccionOpcion = -1;
					}
					if (cliente != null)
					{
						MostrarCabeceraCliente();
						MostrarCliente(cliente);
						if (BorrarCliente(clientes, cliente))
						{
							Estilo.MsgOk("Cliente borrado correctamente.");
						}
						else
						{
							Estilo.MsgInfo("El cliente no se ha borrado.");
						}
						Menu.seccionOpcion = -1;
					}
					break;
				default:
					Estilo.MsgError("La opción seleccionada no existe.");
					Menu.seccionOpcion = -1;
					break;
			}
			//Console.WriteLine();
		}

		private static readonly string celdasAncho = " {0,-5} | {1,-12} | {2,-18} | {3,-10} | {4,-18} | {5,-13} | {6,-12} ";

		private static readonly string[] celdasLabel = {
			"ID",
			"Nombre",
			"Apellidos",
			"DNI/NIE",
			"Email",
			"F. nacimiento",
			"Nacionalidad"
		};

		//Muestra una tabla de clientes (sin cabecera)
		private static void ListarClientes(BBDD<Cliente> clientes)
		{
			bool par = false;
			foreach (Cliente c in clientes.Componentes)
			{
				MostrarCliente(c, par);
				par = (par) ? false : true; //Para alternar el color de las filas, pares e inpares, en cada vuelta del foreach
			}
		}

		//Muestra unca fila de cabecera para tabla de clientes
		private static void MostrarCabeceraCliente()
		{
			Console.WriteLine();
			string s = string.Format(
				celdasAncho,
				celdasLabel[0],
				celdasLabel[1],
				celdasLabel[2],
				celdasLabel[3],
				celdasLabel[4],
				celdasLabel[5],
				celdasLabel[6]
			);
			ConsoleEx.WriteLineColor(s, ConsoleColor.DarkBlue, ConsoleColor.White);
		}

		//Muestra un cliente en formato de fila de tabla
		private static void MostrarCliente(Cliente cliente, bool par = false)
		{
			string s = string.Format(
				celdasAncho,
				cliente.Id,
				cliente.Nombre.Truncate(12),
				cliente.Apellidos.Truncate(18),
				cliente.Dni.ToString(),
				cliente.Email.Truncate(18),
				cliente.Fnacimiento.ToString(),
				cliente.Nacionalidad
			);
			ConsoleEx.WriteLineColor(s, (par) ? ConsoleColor.DarkGray : ConsoleColor.Gray, ConsoleColor.Black);
		}

		////Para buscar clientes con campos concretos //////// Ya no lo necesto con la nueva función BuscarclienteCampo
		//private static Cliente BuscarCliente(BBDD<Cliente> clientes, int campo)
		//{
		//	string input;
		//	Cliente clienteEncontrado;
		//	while (true) //repetimos hasta que el usuario se canse introduciendo una opcion del menu
		//	{
		//		ConsoleEx.WriteColor($"Introduce el campo {celdasLabel[campo]}: ", ConsoleColor.DarkCyan, ConsoleColor.Black);
		//		input = Menu.Comandos(Console.ReadLine());
		//		if (Menu.opcion == '0')
		//		{
		//			switch (campo)
		//			{
		//				case 0: //Busca por Id
		//					if (Int32.TryParse(input, out int numero))
		//					{
		//						clienteEncontrado = clientes.Find(e => e.Id == numero);
		//						if (clienteEncontrado != null)
		//						{
		//							return clienteEncontrado;
		//						}
		//					}
		//					else
		//					{
		//						ConsoleEx.WriteLineColor("No es un número entero.", ConsoleColor.DarkRed, ConsoleColor.White);
		//					}
		//					break;
		//				case 1: //Busca por nombre
		//					clienteEncontrado = clientes.Find(e => e.Nombre.ToLower() == input.ToLower());
		//					if (clienteEncontrado != null)
		//					{
		//						return clienteEncontrado;
		//					}
		//					break;
		//				default:
		//					throw new Exception("Se a pasado a la función un campo incorrecto");
		//			}
		//			ConsoleEx.WriteLineColor("No se ha encontrado un cliente.", ConsoleColor.DarkRed, ConsoleColor.White);
		//		}
		//		else
		//		{
		//			return null;
		//		}
		//	}
		//}

		//Para buscar clientes con cualquier campo
		private static Cliente BuscarClienteCampo(BBDD<Cliente> clientes, string campo = null)
		{
			string input;
			Cliente clienteEncontrado;
			//Pide el campo por el que buscar. Se asegura de que el campo introducido existe
			//Si a la función se le envia, mediante argumento, un campo, se salta este paso
			while (campo == null) //repetimos hasta que el usuario se canse introduciendo una opcion del menu
			{
				Estilo.MsgCampo($"Nombre del campo por el buscar");
				campo = Menu.Comandos(Console.ReadLine());
				if (Menu.opcion == '0')
				{
					campo = campo.ToTitleCase();
					if (!typeof(Cliente).TienePropiedad(campo))
					{
						Estilo.MsgError("El campo no existe.");
						campo = null;
					}
				}
				else
				{
					return null;
				}
			}
			//Pide el valor para el campo seleccionado y busca el cliente con dicho valor
			while (true) //repetimos hasta que el usuario se canse introduciendo una opcion del menu
			{
				Estilo.MsgCampo($"Introduce el campo {campo}");
				input = Menu.Comandos(Console.ReadLine());
				if (Menu.opcion == '0')
				{
					clienteEncontrado = clientes.Find(e => e[campo].ToString().ToLower() == input.ToLower());
					if (clienteEncontrado != null)
					{
						return clienteEncontrado;
					}
					Estilo.MsgError("No se ha encontrado un cliente.");
				}
				else
				{
					return null;
				}
			}
		}

		//Rellena todos los campos de un objeto cliente mediante delegados a la funcion SetCampo
		private static Cliente RellenarCliente(Cliente cliente, bool vacio = false)
		{
			//Devuelve un nulo cuando el usuario cancela desde la funcion SetCampo introducir más datos
			//Devuelve cliente si todos los datos se han introducido correctamente
			if (vacio == false) { 
				return
				!SetCampo(value => cliente.Nombre = value, 1) ||
				!SetCampo(value => cliente.Apellidos = value, 2) ||
				!SetCampo(value => cliente.Dni = new Dni(value), 3) ||
				!SetCampo(value => cliente.Email = value, 4) ||
				!SetCampo(value => cliente.Fnacimiento = new Fecha(DateTime.Parse(value)), 5)
					? null
					: cliente;
			} else { 
				return
			!SetCampo(value => cliente.Nombre = value, 1, cliente.Nombre, vacio) ||
			!SetCampo(value => cliente.Apellidos = value, 2, cliente.Apellidos, vacio) ||
			!SetCampo(value => cliente.Dni = new Dni(value), 3, cliente.Dni.ToString(), vacio) ||
			!SetCampo(value => cliente.Email = value, 4, cliente.Email, vacio) ||
			!SetCampo(value => cliente.Fnacimiento = new Fecha(DateTime.Parse(value)), 5, cliente.Fnacimiento.ToString(), vacio)
				? null
				: cliente;
			}
		}

		//Rellena un campo del objeto cliente
		private static bool SetCampo(Action<string> set, int idCampo, string valorOriginal = null, bool vacio = false)
		{
			string input;
			while (true) //repetimos hasta que el usuario se canse introduciendo una opcion del menu
			{
				Estilo.MsgCampo($"{celdasLabel[idCampo],14}");
				input = Menu.Comandos(Console.ReadLine());

				if (vacio == true && input == "")
				{
					input = valorOriginal;
				}

				if (Menu.opcion == '0')
				{
					try
					{
						set(input);
						return true;
					}
					catch (Exception e)
					{
						Estilo.MsgError(e.Message);
					}
				}
				else
				{
					return false;

				}
			}
		}

		//Borra un lciente de la lista de clientes
		private static bool BorrarCliente(BBDD<Cliente> clientes, Cliente cliente)
		{
			Estilo.MsgConfirmar("¿Estás seguro de querer borrar el cliente seleccionado?");
			if (Console.ReadLine().ToUpper() == "Y")
			{
				clientes.Remove(cliente);
				return true;
			}
			else
			{
				return false;
			}
		}

		public static void ClientesDePrueba()
		{
			string[][] cp = new string[][]
			{
				new string[] {"Ana",	"Balbuena Gutierrez",	"12345678Z", "anabg@gamil.com",		"10/10/2000"},
				new string[] {"José",	"Gonzalez Nuñez",		"25323345T", "josegn@gamil.com",	"20/12/1950"},
				new string[] {"Juan",	"Viejo Rosal",			"05323345H", "juanvr@hotmail.es",	"17/01/1980"},
				new string[] {"Pedro",	"Saez de Santamaria",	"X1234567L", "pedross@gamil.com",	"07/11/1990"},
				new string[] {"Maria",	"Diez de Lucas",		"Y1223344B", "mariadl@aol.com",		"02/05/1970"},
				new string[] {"Sofia",	"Moreno Fernandez",		"56347834L", "sofiamf@gamil.com",	"18/07/1980"},
			};

			for (int i = 0; i < cp.Length; i++)
			{
				clientes.Add(new Cliente(CID, $"{cp[i][0]}", $"{cp[i][1]}", $"{cp[i][2]}", $"{cp[i][3]}", $"{cp[i][4]}"));
				CID++;
			}
		}
	}
}
