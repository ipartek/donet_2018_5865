﻿using System;
using Utilidades;

namespace Modulos
{
	public static class Articulos
	{
		public static void Main()
		{
			ConsoleEx.WriteLineColor(" Sección en construcción ", ConsoleColor.Gray, ConsoleColor.DarkRed);
		}
	}
}
