﻿using System;
using Utilidades;

namespace Modulos
{
	public static class Categorias
	{
		public static void Main()
		{
			ConsoleEx.WriteLineColor(" Sección en construcción ", ConsoleColor.Gray, ConsoleColor.DarkRed);
		}
	}
}
