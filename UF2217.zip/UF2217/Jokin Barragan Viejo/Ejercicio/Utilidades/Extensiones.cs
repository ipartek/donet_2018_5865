﻿using System;
using System.Globalization;

namespace Utilidades
{
	public static class Extensiones
	{
		public static string CutRight(this string s, int cuantosCaracteresAQuitar)
		{
			return s.Substring(0, s.Length - cuantosCaracteresAQuitar);
		}

		public static string Truncate(this string s, int anchoMaximo)
		{
			if (string.IsNullOrEmpty(s)) return s;
			return s.Length <= anchoMaximo ? s : s.Substring(0, anchoMaximo - 1) + "¬";
		}

		public static string ToTitleCase(this string s)
		{
			return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(s.ToLower());
		}

		//Para saber si una clase tiene una propiedad con un nombre indicado
		public static bool TienePropiedad(this Type obj, string propiedad)
		{
			return obj.GetProperty(propiedad) != null;
		}
		
	}


	public static class ConsoleEx //Console no se puede extender (o eso he entendido), así que creo una clase con un nombre similar para que lo parezca.
	{
		//Imita al Console.WriteLine pero añadiendo color
		public static void WriteLineColor(string s, ConsoleColor colorFondo = ConsoleColor.Black, ConsoleColor colorTexto = ConsoleColor.White)
		{
			Console.BackgroundColor = colorFondo;
			Console.ForegroundColor = colorTexto;
			Console.WriteLine(s);
			Console.ResetColor();
			s.ToTitleCase();
		}
		//Imita al Console.Write pero añadiendo color
		public static void WriteColor(string s, ConsoleColor colorFondo = ConsoleColor.Black, ConsoleColor colorTexto = ConsoleColor.White)
		{
			Console.BackgroundColor = colorFondo;
			Console.ForegroundColor = colorTexto;
			Console.Write(s);
			Console.ResetColor();
		}
	}
}
