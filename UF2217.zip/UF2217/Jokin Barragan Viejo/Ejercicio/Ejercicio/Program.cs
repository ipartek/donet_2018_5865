﻿using System;
using Interfaz;
using Utilidades;
using Modulos;

namespace Ejercicio
{
	class Program
	{
		static void Main(string[] args)
		{
			Clientes.ClientesDePrueba();
			Console.WindowWidth = Estilo.anchoTotal; //Pone un ancho por defecto a la ventana de la consola
			Menu.opcion = 'S';//Opcion del menu por defecto nada más inciar el programa
			while (true) //El programa se ejecuta indefinidamente hasta que se selecciona la opción 'X'
			{
				Cabecera();
				Menu.Nav();
				if (Menu.seccion != -1 && Menu.seccionOpcion != -1)
				{
					Cuerpo();
				}
				if (Menu.seccionOpcion == -1)
				{
					Estilo.Com(); //Marcador que indica se que se puede introducir un comando.
					Menu.Comandos(Console.ReadLine());
				}
				Console.Clear();
			}
		}

		private static void Cabecera()
		{
			string[] logo = new string[] {
				"  ▄▄▄▄   ▄▄▄   ▄▄▄  ▄▄▄▄  ▄▄▄▄         ▄▄▄  ▄▄▄▄  ▄▄▄▄                                                       Cerrar [X]",
				"  ██▄██ ██ ██ ██ ██  ██  ██▄▄   ▄▄▄▄  ██▄██ ██▄██ ██▄██                                                                ",
				"  ██▀██ ██ ██ ██ ██  ██   ▀▀██  ▀▀▀▀  ██▀██ ██▀▀  ██▀▀                                                                 ",
				"  ▀▀▀▀   ▀▀▀   ▀▀▀   ▀▀  ▀▀▀▀         ▀▀ ▀▀ ▀▀    ▀▀                                                                   ",
			};

			Console.BackgroundColor = ConsoleColor.Gray;
			Console.ForegroundColor = ConsoleColor.DarkCyan;
			foreach (string fila in logo)
			{
				Console.WriteLine(fila);
			}
			Console.ResetColor();
		}

		static void Cuerpo()
		{
			switch (Menu.seccion)
			{
				case 0:
					Clientes.Main();
					break;
				case 1:
					Articulos.Main();
					break;
				case 2:
					Categorias.Main();
					break;
			}
		}
	}
}
