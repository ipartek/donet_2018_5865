﻿using System.Text.RegularExpressions;
namespace Tipos
{

    public class Cliente
    {
        /*protected const string NOMBRE_POR_DEFECTO = "desconocido@desconocidez.com";
        protected const string APELLIDOS_POR_DEFECTO = "desconocido@desconocidez.com";
        protected const string EMAIL_POR_DEFECTO = "desconocido@desconocidez.com";
        protected const string DNI_POR_DEFECTO = "desconocido@desconocidez.com";
        */
        
        //Propiedad estática / de clase / compartida
        public Dni Dni { get; set; }
        public string FechaNacimiento { get; set; }
        public string Nacionalidad { get; set; }

        //Variables de instancia / Campos / Fields
        // private string email;

        //Constructores
        public Cliente(string id_cliente, string nombre, string apellidos, string email, string password, Dni dni, string fechanacimiento, string nacionalidad)
        {
            ID_Cliente = id_cliente;
            Nombre = nombre;
            Apellidos = apellidos;
            Email = email;
            Password = password;
            Dni = dni;
            FechaNacimiento = fechanacimiento;
            Nacionalidad = nacionalidad;
        }

        public Cliente()
        {
        }

        public string id_cliente;
        public string ID_Cliente
        {

            get { return id_cliente; }

            set
            {

                if (value == null)
                {
                    throw new TiposException("No se admiten nombres nulos");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }
                if (!Regex.IsMatch(value.Trim(), @"^[\d]{3,}"))
                {
                    throw new TiposException("El nombre debe tener al menos 3 números");
                }
                id_cliente = value;
            }
        }
        public string nombre;
        public string Nombre
        {

            get { return nombre; }

            set
            {

                if (value == null)
                {
                    throw new TiposException("No se admiten nombres nulos");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }
                if (!Regex.IsMatch(value.Trim(), @"^\w{3,}$"))
                {
                    throw new TiposException("El nombre debe tener al menos 3 letras");
                }
                nombre = value;
            }
        }

        public string apellidos;
        public string Apellidos
        {

            get { return apellidos; }

            set
            {

                if (value == null)
                {
                    throw new TiposException("No se admiten nombres nulos");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }
                if (!Regex.IsMatch(value.Trim(), @"^\w{3,}$"))
                {
                    throw new TiposException("El apellido debe tener al menos 5 letras");
                }
                apellidos = value;
            }
        }


        private string email;
        //Propiedad
        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                if (value == null)
                {
                    throw new TiposException("No se admiten emails nulos");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el email");
                }

                if (!Regex.IsMatch(value.Trim(), @"^\w+@\w+\.\w+$"))
                {
                    throw new TiposException("El email introducido no es válido. Debe ser del formato email@email.com");
                }

                email = value.Trim();
            }
        }

        private string password;
        //Propiedad
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                if (value == null)
                {
                    throw new TiposException("No se admiten emails nulos");
                }
                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el email");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }
                if (!Regex.IsMatch(value.Trim(), @"^\w{5,}$"))
                {
                    throw new TiposException("El password debe tener al menos 5 letras");
                }

                password = value.Trim();
            }
        }



        //    //public string Nombre
        //    //{
        //    //    Acceso get
        //    //    get { return nombre; }
        //    //    Acceso set
        //    //    set { nombre = value; }
        //    //}

        //    public Usuario() : this(EMAIL_POR_DEFECTO, passwordPorDefecto)
        //    {
        //        Console.WriteLine("Constructor vacío");
        //    }

        //    ~Usuario()
        //    //DESTRUCTOR
        //    {
        //        Console.WriteLine("Destructor");
        //    }

        //    //Propiedad "automática" que genera la variable y los accesos
        //public string Password { get; set; }
        //public Dni Dni { get; set; }

        //    //Métodos de acceso
        public string GetEmail()
        {
            return email;
        }

        //    public void SetEmail(string email)
        //    {
        //        this.email = email;
        //    }



    //    public virtual string FormatoVertical =>
    ////        //TODO: Modificar este texto por implementación real
    ////        //"________TEXTO DE PRUEBA___________";
    //throw new NotImplementedException();
    //    string.Format(
    //            "Email: {0}\nPassword: {1}\n", Email, Password);

        //    //Método de instancia
        public virtual string GetTexto()
        {
            return string.Format("id_cliente: {0}, Nombre: {1}, Apellidos:{2} Email:{3} Password:{4} Dni:{5} Fecha de Nacimiento:{6} Nacionalida:{7}", ID_Cliente, Nombre, Apellidos, Email, Password, Dni,FechaNacimiento,Nacionalidad);
        }

        public enum Formatos
        {
            Horizontal,
            Vertical
        }


        // Sobrecargas

        public string GetTexto(string formato)
        {
            switch (formato)
            {
                case "Horizontal":
                    return GetTexto();
                case "Vertical":
                    return string.Format("{0},{1}", Email, Password);
                default:
                    return GetTexto();
            }
        }

        //public string GetTexto(Formatos formato)
        //{
        //    switch (formato)
        //    {
        //        case Formatos.horizontal:
        //            return GetTexto("bonito");
        //        case Formatos.vertical:
        //            return GetTexto("compacto");
        //        default:
        //            return GetTexto();
        //    }
        //}

        //  //  Sobrecarga de operadores
        //public static bool operator >(Usuario u1, Usuario u2)
        //    {
        //        return u1.Email.CompareTo(u2.Email) > 0;
        //    }

        //    public static bool operator <(Usuario u1, Usuario u2)
        //    {
        //        return u1.Email.CompareTo(u2.Email) < 0;
        //    }

        public override string ToString()
        {
            return GetTexto();
           // return "Cliente: " +  "ID: " + ID_Cliente + "Nombre: " + Nombre + "Apellidos: " + Apellidos + "DNI: " + Dni;
        }

    }

}
