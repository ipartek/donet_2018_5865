﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Tipos
{
    //Genéricos
    //Podemos crear un grupo así: 
    //Grupo<Usuario> grupo = new Grupo<Usuario>();
    public class Grupo<TComponente>
    {
        private List<TComponente> componentes = new List<TComponente>();

        public string ID_Cliente { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string DNI { get; set; }
        public string Fechanacimiento { get; set; }
        public string Nacionalidad { get; set; }

        public Grupo(string nombre)
        {
            Nombre = nombre;
        }

        public void Add(TComponente componente)
        {
            if (componente == null)
            {
                throw new Exception("No se admiten componentes nulos");
            }

            componentes.Add(componente);
        }

        public TComponente Find(Predicate<TComponente> delegadoDeBusqueda)
        {
            return componentes.Find(delegadoDeBusqueda);
        }

        public void Remove(TComponente componente)
        {
            if (componente == null)
            {
                throw new Exception("No se admiten componentes nulos");
            }

            componentes.Remove(componente);
        }

        private ReadOnlyCollection<TComponente> GetComponentes()
        {
            return new ReadOnlyCollection<TComponente>(componentes);
        }

        public ReadOnlyCollection<TComponente> Componentes
        {
            get { return GetComponentes(); }
        }

        //Indizador / Indexador
        public TComponente this[int i]
        {
            get { return componentes[i]; }
            set { componentes[i] = value; }
        }

        public TComponente this[Predicate<TComponente> funcionDeBusqueda]
        {
            get { return Find(funcionDeBusqueda); }
            set
            {
                componentes[componentes.IndexOf(Find(funcionDeBusqueda))] = value;
            }
        }
    }
}
