﻿using System;
using Tipos;
using Utilidades;

namespace EjercicioConsola
{
    class Program
    {
        private enum OpcionesMenu
        {
            Alta = 1, Editar = 2, Baja = 3, Listado = 4, Buscar_ID = 5, Buscar_nombre = 6, Buscar_por_nombre = 7, Salir = 0
        }

        private static Grupo<Cliente> g = new Grupo<Cliente>("EjercicioConsola");
        static void Main(string[] args)
        {


            int opcionelegida;
            g.Add(new Cliente("123", "iker", "bet", "pepe@hotmail.com", "pasahitza", new Dni("22948213D"), "a", "a"));
            g.Add(new Cliente("124", "Pab", "Mon", "manolo@yahoo.com", "geheimish", new Dni("39924971F"), "b", "b"));
            do
            {
                Mostrarmenu();
                opcionelegida = PedirOpcion();
                Procesaropcion(opcionelegida);
            } while (!ElUsuarioQuiereSalir(opcionelegida));
        }

        private static bool ElUsuarioQuiereSalir(int opcion) =>
            (OpcionesMenu)opcion == OpcionesMenu.Salir;

        private static void Procesaropcion(int opcionelegida)
        {
            OpcionesMenu opcionMenu = (OpcionesMenu)opcionelegida;
            switch (opcionMenu)
            {
                case OpcionesMenu.Salir:
                    ExitProgram();
                    break;
                case OpcionesMenu.Alta: 
                    MenuAltaUsuario();
                    mostrarlistado();
                    break;
                case OpcionesMenu.Editar:
                    ModificaUsuario();
                    break;
                case OpcionesMenu.Baja:  // baja de datos de cliente
                    Console.WriteLine("Dar de baja a cliente");
                    Console.WriteLine("Selecciona elemento que quieres borrar");
                    int i = int.Parse(Console.ReadLine());
                    g.Remove(g[i]);
                    mostrarlistado();
                    break;
                case OpcionesMenu.Listado:  // Ver el listado
                    mostrarlistado();
                    break;
                case OpcionesMenu.Buscar_ID:  // Buscar por el ID
                    Console.WriteLine("Selecciona el ID del elemento que quieres buscar");
                    string j = Console.ReadLine();
                    Cliente cliente = g.Find(u => u.ID_Cliente == j);
                    Console.WriteLine(cliente);
                    break;
                case OpcionesMenu.Buscar_nombre:
                    Console.WriteLine("Selecciona el nombre del elemento que quieres buscar");
                    string search_name = Console.ReadLine();
                    Cliente cliente_Nombre = g.Find(u => u.Nombre == search_name);
                    Console.WriteLine(cliente_Nombre);
                    break;
                default:
                    break;
            }
        }

        private static void mostrarlistado()
        {
            foreach (Cliente item in g.Componentes)
            {
                Console.WriteLine(item);
            }
        }

        public static void Menu()
        {
            int Option;
            do
            {
                Mostrarmenu();
                Option = PedirOpcion();

            } while (!ElUsuarioQuiereSalir(Option));
        }

        private static void Mostrarmenu()
        {
            Console.WriteLine("  Menu de gestión de Clientes  ");
            Console.WriteLine("***********************************");
            Console.WriteLine("1. Alta de un nuevo cliente");
            Console.WriteLine("2. Modificación de datos de cliente");
            Console.WriteLine("3. Baja de cliente");
            Console.WriteLine("4. Ver listado");
            Console.WriteLine("5. Buscar por ID");
            Console.WriteLine("6. Buscar por nombre");
            Console.WriteLine("6. Buscar por nombre");
            Console.WriteLine("***********************************");
        }
        private static int PedirOpcion() //params int[] opciones)
        {
            int opcion;
            do
            {
                opcion = LeerEntero("Elige una opción del menú: ");
            }
            while (!ExisteOpcion(opcion)); 

            return opcion;
        }

        private static bool ExisteOpcion(int opcion)
        {

            bool existe = Enum.IsDefined(typeof(OpcionesMenu), opcion);

            if (!existe)
            {
                Console.WriteLine("No existe esa opción");
            }

            return existe;
        }

        private static int LeerEntero(string mensaje)
        {
            int entero;
            string resultado;

            bool correcto = true;

            do
            {
                Console.WriteLine("Elige una opción");
                resultado = Console.ReadLine();
                correcto = int.TryParse(resultado, out entero);

                if (!correcto)
                {
                    Console.WriteLine("Eso no es un número");
                }
            }
            while (!correcto);

            return entero;
        }

        private static void ExitProgram()
        {
            Console.WriteLine();
            Console.WriteLine("Bye Bye, Has decidido terminar el Programa. Pulse una tecla para salir...");
        }

        public static void MenuAltaUsuario()
        {
            Cliente cliente = new Cliente();
            bool repetir = false;
            repetir = Recogidatos(cliente);
            g.Add(new Cliente(cliente.ID_Cliente, cliente.Nombre, cliente.Apellidos, cliente.Email, cliente.Password, cliente.Dni, cliente.FechaNacimiento, cliente.Nacionalidad));
            mostrarlistado();
        }
        public static void ModificaUsuario()
        {
            int indexCliente;
            Console.WriteLine("introduce la linea que deseas modificar:");
            indexCliente = int.Parse(Console.ReadLine());
            bool repetir = false;
            Cliente cliente = new Cliente();
            repetir = Recogidatos(cliente);
            g[0] = new Cliente(cliente.ID_Cliente, cliente.Nombre, cliente.Apellidos, cliente.Email, cliente.Password, cliente.Dni, cliente.FechaNacimiento, cliente.Nacionalidad);
            mostrarlistado();
        }
        private static bool Recogidatos(Cliente cliente)
        {
            bool repetir;
            do
            {
                Console.WriteLine("Introduce el ID de cliente");
                try
                {
                    repetir = false;
                    cliente.ID_Cliente = Console.ReadLine();// intenta meter en el valor segun el formato estipulado
                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }

            } while (repetir);
            do
            {
                Console.WriteLine("Introduce el nombre cliente");
                try
                {
                    repetir = false;
                    cliente.Nombre = Console.ReadLine();

                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }

            } while (repetir);
            do
            {
                Console.WriteLine("Introduce los apellidos cliente");
                try
                {
                    repetir = false;
                    cliente.Apellidos = Console.ReadLine();

                }

                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }
            } while (repetir);
            do
            {
                Console.WriteLine("Introduce el email:");
                try
                {
                    repetir = false;
                    cliente.Email = Console.ReadLine();

                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }
            } while (repetir);
            do
            {
                Console.WriteLine("Introduce el password");
                try
                {
                    repetir = false;
                    cliente.Password = Console.ReadLine();// intenta meter en el valor segun el formato estipulado

                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }
            } while (repetir);
            do
            {
                Console.WriteLine("Introduce fecha de nacimiento en (formato DD/MM/YYYY)");
                string d, hoy;
                try
                {
                    repetir = false;
                    d = cliente.FechaNacimiento = Console.ReadLine();
                    DateTime fechaDT, hoyDT;
                    fechaDT = Convert.ToDateTime(d);
                    hoy = DateTime.Now.ToString("dd/MM/yyyy");
                    hoyDT = Convert.ToDateTime(hoy);
                    DateTime zeroTime = new DateTime(1, 1, 1);
                    TimeSpan span = hoyDT - fechaDT;
                    int years = (zeroTime + span).Year - 1;

                    Console.WriteLine("tienes estis {0} años ", years);
                    if (years >= 18)
                    {
                        Console.WriteLine("Eres mayor de edad");
                        
                    }
                    else
                    {
                        throw new TiposException("Eres menor de edad");
                    }
                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }
                catch (Exception)
                {
                    repetir = true;
                    Console.WriteLine("La fecha introducida no es valida");
                }
            } while (repetir);
            do
            {
                try
                {
                    repetir = false;
                    int inacionalidad;
                    string S_nacion;
                    Console.WriteLine("Introduce nacionalidad 0: Española y 1: extrangera");
                    S_nacion = Console.ReadLine();
                    inacionalidad = int.Parse(S_nacion);
                    switch (inacionalidad)
                    {
                        case 0:
                            cliente.Nacionalidad = "Española";
                            Console.WriteLine("nacionalidad española");
                            break;
                        case 1:
                            cliente.Nacionalidad = "Extranjera";
                            Console.WriteLine("nacionalidad extrangera");
                            break;
                        default:
                            throw new TiposException("Elige una opcion válida");
                            break;
                    }
                }
                catch (TiposException te)
                {
                    repetir = true;
                    Console.WriteLine(te.Message);
                }
                catch (Exception)
                {
                    repetir = true;
                    Console.WriteLine("La fecha introducidad no es valida");
                }
                //nacionalidadOK = true;
            } while (repetir);
            return repetir;
        }
    }
}
