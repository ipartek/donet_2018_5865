﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Tipos;

namespace Ejercicio3
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Grupo<Cliente> g = new Grupo<Cliente>("Pruebas");
            int contador = 1;
            int IdCont = 2;
            CrearCliente(g, contador, IdCont);
            Menu(g, contador, IdCont);
        }

        static void CrearCliente(Grupo<Cliente> g, int contador, int IdCont)
        {
            g.Add(new Cliente("1", "Juan", "Garcia Fernandez", "jgarcia@email.com", "1234", "12345678Z", "25/04/1983", "Es"));
        }

        static void Menu(Grupo<Cliente> g, int contador, int IdCont)
        {
            string sOpcion;
            int iOpcion;
            Console.WriteLine();
            Console.WriteLine("Menu Principal");
            Console.WriteLine("1. Alta");
            Console.WriteLine("2. Modificacion");
            Console.WriteLine("3. Baja");
            Console.WriteLine("4. Ver Listado");
            Console.WriteLine("5. Buscar por ID");
            Console.WriteLine("6. Buscar por Nombre");
            Console.WriteLine("7. Buscador");
            Console.WriteLine("8. Salir");
            sOpcion = Console.ReadLine();
            

            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");
            
            if (sOpcion == "" || !val.IsMatch(sOpcion))
            {
                Console.WriteLine();
                Console.WriteLine("Eige una opcion entre el 1 y el 8");
                Console.WriteLine();
                Menu(g, contador, IdCont);
            }
            else
            {
                iOpcion = int.Parse(sOpcion);

                if (iOpcion <= 8 && iOpcion > 0)
                {
                    switch (iOpcion)
                    {
                        case 1: Alta(g, contador, IdCont); break;
                        case 2: Modificacion(g, contador, IdCont); break;
                        case 3: Baja(g, contador, IdCont); break;
                        case 4: Lista(g, contador, IdCont); break;
                        case 5: BuscaID(g, contador, IdCont); break;
                        case 6: BuscaNombre(g, contador, IdCont); break;
                        case 7: Buscar(g, contador, IdCont); break;
                        case 8: Environment.Exit(1); break;
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Opcion no valida. Tiene que ser un numero entre 1 y 8");
                    Console.WriteLine();
                    Menu(g, contador, IdCont);
                }
            }
            
        }

        static void Alta(Grupo<Cliente> g, int contador, int IdCont)
        {

            Console.WriteLine();
            Console.WriteLine("ALTA DE CLIENTES");
            //Console.WriteLine("Introducir ID: ");
            //string Id = Console.ReadLine();
            string Id = Convert.ToString(IdCont);
            Console.WriteLine("Introducir Nombre: ");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Introducir Apellidos: ");
            string Apellido = Console.ReadLine();
            Console.WriteLine("Introducir Email: ");
            string Email = Console.ReadLine();
            Console.WriteLine("Introducir Pass: ");
            string Password = Console.ReadLine();
            Console.WriteLine("Introducir Dni (Letra Mayuscula): ");
            string Dn = Console.ReadLine();
            Console.WriteLine("Introducir Fecha de nacimeinto(DD/MM/AAAA): ");
            string Fecha = Console.ReadLine();
            Console.WriteLine("Introducir Nacionalidad (ES/EX): ");
            string Nacionalidad = Console.ReadLine();
            Console.WriteLine();
            
            Boolean IdValido = Cliente.ValidarId(Id);
            Boolean NombreValido = Cliente.ValidarNombre(Nombre);
            Boolean ApellidoValido = Cliente.ValidarApellido(Apellido);
            Boolean EmailValido = Cliente.ValidarEmail(Email);
            Boolean FechaValida = Cliente.ValidarFecha(Fecha);
            Boolean NavionalidadValida = Cliente.ValidarNacionalidad(Nacionalidad);
            
            if (!IdValido)
            {
                Alta(g, contador, IdCont);
            }

            if (!NombreValido)
            {
                Alta(g, contador, IdCont);
            }

            if (!ApellidoValido)
            {
                Alta(g, contador, IdCont);
            }
            
            if (!EmailValido)
            {
                Alta(g, contador, IdCont);
            }

            if (!FechaValida)
            {
                Alta(g, contador, IdCont);
            }

            if (!NavionalidadValida)
            {
                Alta(g, contador, IdCont);
            }

            try
            {
                Dni dni = new Dni(Dn);
                if (Dni.EsValido(Dn))
                {
                    dni = new Dni(Dn);
                    if (IdValido && NombreValido && ApellidoValido && EmailValido && FechaValida && NavionalidadValida)
                    {
                        g.Add(new Cliente(Id, Nombre, Apellido, Email, Password, Dn, Fecha, Nacionalidad));
                        contador++;
                        IdCont++;
                    }
                    
                }
            }
            catch
            {
                Console.WriteLine("Error: Dni no Valido. No se ha guradado el Ususario");
                Console.WriteLine("VUELVE A INTENTARLO");
                Console.WriteLine();
                Alta(g, contador, IdCont);
            }

            Boolean NacValido = Cliente.ValidarNacionalidad(Nacionalidad);
            if (!NacValido)
            {
                Alta(g, contador, IdCont);
            }
            
            Menu(g, contador, IdCont);
            
        }

        static void Modificacion(Grupo<Cliente> g, int contador, int IdCont)
        {
            Console.WriteLine();
            Console.WriteLine("MODIFICADO DE DATOS");
            Console.WriteLine("Id del Cliente a editar: ");
            string IdModiciado = Console.ReadLine();

            int i = 0;
            Boolean encontrado = false;
            for (i = 0; i < contador; i++)
            {
                if (g.Componentes[i].Id == IdModiciado)
                {
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado)
            {
                Console.WriteLine(@"¡CLIENTE NO ENCONTRADO!");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Nombre Actual: " + g.Componentes[i].Nombre);
                Console.WriteLine("Introducir Nombre: ");
                string Nombre = Console.ReadLine();
                if (Nombre == "")
                {
                    Nombre = g.Componentes[i].Nombre;
                }

                Console.WriteLine("Apellido Actual: " + g.Componentes[i].Apellido);
                Console.WriteLine("Introducir Apellidos: ");
                string Apellido = Console.ReadLine();
                if (Apellido == "")
                {
                    Apellido = g.Componentes[i].Apellido;
                }

                Console.WriteLine("Email Actual: " + g.Componentes[i].Email);
                Console.WriteLine("Introducir Email: ");
                string Email = Console.ReadLine();
                if (Email == "")
                {
                    Email = g.Componentes[i].Email;
                }

                Console.WriteLine("Password Actual: " + g.Componentes[i].Password);
                Console.WriteLine("Introducir Pass: ");
                string Password = Console.ReadLine();
                if (Password == "")
                {
                    Password = g.Componentes[i].Password;
                }

                Console.WriteLine("Dni Actual: " + g.Componentes[i].Dni);
                Console.WriteLine("Introducir Dni: ");
                string Dn = Console.ReadLine();
                if (Dn == "")
                {
                    Dn = g.Componentes[i].Dni;
                }

                Console.WriteLine("Fecha de nacimento Actual: " + g.Componentes[i].Fecha);
                Console.WriteLine("Introducir Fecha de nacimeinto: ");
                string Fecha = Console.ReadLine();
                if (Fecha == "")
                {
                    Fecha = g.Componentes[i].Fecha;
                }

                Console.WriteLine("Nacionalidad Actual: " + g.Componentes[i].Nacionalidad);
                Console.WriteLine("Introducir Nacionalidad: ");
                string Nacionalidad = Console.ReadLine();
                if (Nacionalidad == "")
                {
                    Nacionalidad = g.Componentes[i].Nacionalidad;
                }

                Console.WriteLine();
                Boolean NombreValido = Cliente.ValidarNombre(Nombre);
                Boolean ApellidoValido = Cliente.ValidarApellido(Apellido);
                Boolean EmailValido = Cliente.ValidarEmail(Email);
                Boolean FechaValida = Cliente.ValidarFecha(Fecha);

                if (!NombreValido)
                {
                    Modificacion(g, contador, IdCont);
                }
                
                if (!ApellidoValido)
                {
                    Modificacion(g, contador, IdCont);
                }
                
                if (!EmailValido)
                {
                    Modificacion(g, contador, IdCont);
                }

                if (!FechaValida)
                {
                    Alta(g, contador, IdCont);
                }

                try
                {
                    Dni dni = new Dni(Dn);
                    if (Dni.EsValido(Dn))
                    {
                        dni = new Dni(Dn);
                        g.Componentes[i].Nombre = Nombre;
                        g.Componentes[i].Apellido = Apellido;
                        g.Componentes[i].Email = Email;
                        g.Componentes[i].Password = Password;
                        g.Componentes[i].Dni = Dn;
                        g.Componentes[i].Fecha = Fecha;
                        g.Componentes[i].Nacionalidad = Nacionalidad;
                        //g.Add(new Cliente(Nombre, Apellido, Email, Password, Dn, Fecha, Nacionalidad));
                    }
                }
                catch
                {
                    Console.WriteLine("Error: Dni no Valido. No se ha guradado el Ususario");
                    Console.WriteLine("VUELVE A INTENTARLO");
                    Console.WriteLine();
                    Modificacion(g, contador, IdCont);
                }
            }
            
            Menu(g, contador, IdCont);
        }

        static void Baja(Grupo<Cliente> g, int contador, int IdCont)
        {
            Console.WriteLine();
            Console.WriteLine("BORRADO DE CLIENTE");
            Console.WriteLine("Id del Cliente a borrar: ");
            string IdBorrado = Console.ReadLine();
            Console.WriteLine();
            Cliente usuario = g.Find(u => u.Id == IdBorrado);
            
            if (IdBorrado == "")
            {
                Console.WriteLine("ES NECESARIO PONER UN ID");
            }
            else
            {
                if (usuario != null)
                {
                    Console.WriteLine(usuario);
                    Console.WriteLine();
                    Console.WriteLine("¿ESTAS SEGURO QUE DESEAS BORRAR EL CLIENTE? (S/N)");
                    string Confirmacion = Console.ReadLine();

                    if (Confirmacion == "S" || Confirmacion == "s")
                    {
                        g.Remove(usuario);
                        Console.WriteLine("Cliente Borrado Correcctamente");
                        Console.WriteLine();
                        contador--;
                    }
                    else if (Confirmacion == "N" || Confirmacion == "n")
                    {
                        Baja(g, contador, IdCont);
                    }
                    else
                    {
                        Console.WriteLine("No se ha borrado ningun Cliente");
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine(@"¡CLIENTE NO ENCONTRADO!");
                    Console.WriteLine();
                }
            }
                Menu(g, contador, IdCont);   
        }

        static void Lista(Grupo<Cliente> g, int contador, int IdCont)
        {
            Console.WriteLine();
            Console.WriteLine("LISTADO DE CLIENTES");
            
            for (int i = 0; i < contador; i++)
            {
                Console.WriteLine(g.Componentes[i]);
                //Console.WriteLine(g.Componentes[i].Id + @" | " + g.Componentes[i].Nombre + @" | " + g.Componentes[i].Apellido + @" | " + g.Componentes[i].Email + @" | " + g.Componentes[i].Password + @" | " + g.Componentes[i].Dni + @" | " + g.Componentes[i].Fecha + @" | " + g.Componentes[i].Nacionalidad);               
            }
            Console.WriteLine();

            Menu(g, contador, IdCont);
        }

        static void BuscaID(Grupo<Cliente> g, int contador, int IdCont)
        {
            Console.WriteLine();
            Console.WriteLine("Buscar por ID");
            Console.WriteLine("Introducir ID: ");
            string BuscarId = Console.ReadLine();
            Predicate<Cliente> busquedaid = u => u.Id == BuscarId;
            Cliente idBuscado = g[busquedaid];

            if (idBuscado != null)
            {
                foreach (Cliente u in g.Componentes)
                {
                    Console.WriteLine(u);
                }
            }
            else
            {
                Console.WriteLine("No se ha encontrado nigun cliente con el ID " + BuscarId);
            }

            /*Cliente usuario = g.Find(u => u.Id == BuscarId);
            Console.WriteLine(usuario);
            Console.WriteLine();*/

            Menu(g, contador, IdCont);

        }

        static void BuscaNombre(Grupo<Cliente> g, int contador, int IdCont)
        {
            Console.WriteLine();
            Console.WriteLine("Buscar por Nombre");
            Console.WriteLine("Introducir Nombre: ");
            string BuscarNombre = Console.ReadLine();
            Predicate<Cliente> busquedanom = u => u.Id == BuscarNombre;
            Cliente nombreBuscado = g[busquedanom];

            if (nombreBuscado != null)
            {
                foreach (Cliente u in g.Componentes)
                {
                    Console.WriteLine(u);
                }
            }
            else
            {
                Console.WriteLine("No se ha encontrado nigun cliente con el Nombre " + BuscarNombre);
            }

            /* Cliente usuario = g.Find(u => u.Id == BuscarNombre);
             Console.WriteLine(usuario);
             Console.WriteLine();*/

            Menu(g, contador, IdCont);
        }
        static void Buscar(Grupo<Cliente> g, int contador, int IdCont)
        {

            string Buscador;
            int Opcion;
            Console.Clear();
            Console.WriteLine("Buscador por campo: ");
            Console.WriteLine("1. ID");
            Console.WriteLine("2. Nombre");
            Console.WriteLine("3. Apellidos");
            Console.WriteLine("4. Email");
            Console.WriteLine("5. Password");
            Console.WriteLine("6. DNI");
            Console.WriteLine("7. Fecha de nacimiento");
            Console.WriteLine("8. Nacionalidad");
            Console.WriteLine("9. Volver al Menu");
            Buscador = Console.ReadLine();

            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");

            if (Buscador == "" || !val.IsMatch(Buscador))
            {
                Console.WriteLine();
                Console.WriteLine("Eige una opcion entre el 1 y el 9");
                Console.WriteLine();
                Buscar(g, contador, IdCont);
            }
            else
            {
                Opcion = int.Parse(Buscador);

                if (Opcion <= 9 && Opcion > 0)
                {
                    switch (Opcion)
                    {
                        case 1:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por ID");
                            Console.WriteLine("Introducir ID: ");
                            string BuscarId = Console.ReadLine();
                            Predicate<Cliente> busquedaid = u => u.Id == BuscarId;
                            Cliente idBuscado = g[busquedaid];

                            if (idBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con el ID " + BuscarId);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 2:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Nombre");
                            Console.WriteLine("Introducir Nombre: ");
                            string BuscarNombre = Console.ReadLine();
                            Predicate<Cliente> busquedanom = u => u.Id == BuscarNombre;
                            Cliente nombreBuscado = g[busquedanom];

                            if (nombreBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con el Nombre " + BuscarNombre);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 3:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Apellidos");
                            Console.WriteLine("Introducir Apellidos: ");
                            string BuscarApellidos = Console.ReadLine();
                            Predicate<Cliente> busquedaap = u => u.Id == BuscarApellidos;
                            Cliente apellidoBuscado = g[busquedaap];

                            if (apellidoBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con los Apellidos " + BuscarApellidos);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 4:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Email");
                            Console.WriteLine("Introducir Email: ");
                            string BuscarEmail = Console.ReadLine();
                            Predicate<Cliente> busquedaemail = u => u.Id == BuscarEmail;
                            Cliente emailBuscado = g[busquedaemail];

                            if (emailBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con el Email " + BuscarEmail);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 5:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Password");
                            Console.WriteLine("Introducir Password: ");
                            string BuscarPass = Console.ReadLine();
                            Predicate<Cliente> busquedapass = u => u.Id == BuscarPass;
                            Cliente passBuscado = g[busquedapass];

                            if (passBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con la Password " + BuscarPass);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 6:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por DNI");
                            Console.WriteLine("Introducir DNI: ");
                            string BuscarDni = Console.ReadLine();
                            Predicate<Cliente> busquedadni = u => u.Id == BuscarDni;
                            Cliente dniBuscado = g[busquedadni];

                            if (dniBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con el DNI " + BuscarDni);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 7:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Fecha de Nacimineto");
                            Console.WriteLine("Introducir Fecha de Nacimiento: ");
                            string BuscarFecha = Console.ReadLine();
                            Predicate<Cliente> busquedafecha = u => u.Id == BuscarFecha;
                            Cliente fechaBuscado = g[busquedafecha];

                            if (fechaBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                    Menu(g, contador, IdCont);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con la Fecha de Nacimiento " + BuscarFecha);
                                Buscar(g, contador, IdCont);
                            }
                           
                            break;
                        case 8:
                            Console.WriteLine();
                            Console.WriteLine("Buscar por Nacionalidad");
                            Console.WriteLine("Introducir Nacinalidad: ");
                            string BuscarNacionalidad = Console.ReadLine();
                            Predicate<Cliente> busquedanac = u => u.Id == BuscarNacionalidad;
                            Cliente nacionalidadBuscado = g[busquedanac];

                            if (nacionalidadBuscado != null)
                            {
                                foreach (Cliente u in g.Componentes)
                                {
                                    Console.WriteLine(u);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se ha encontrado nigun cliente con Nacionalidad " + BuscarNacionalidad);
                                Buscar(g, contador, IdCont);
                            }
                            
                            break;
                        case 9:
                            Menu(g, contador, IdCont);
                            break;
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Opcion no valida. Tiene que ser un numero entre 1 y 9");
                    Console.WriteLine();
                    Buscar(g, contador, IdCont);
                }
            }
            Menu(g, contador, IdCont);
        }
    }
}
