﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
//csc /t:library Usuario.cs /out:Tipos.dll

namespace Tipos
{
    public class Cliente
    {
        
       
        private string id;
        private string nombre;
        private string apellido;
        private string email;
        private string password;
        private string dni;
        private string fecha;
        private string nacionalidad;

        public Cliente(string id = null, string nombre = null, string apellido = null, string email = null, string password = null, string dni = null, string fecha = null, string nacionalidad = null)
        
        {
            Id = id;
            Nombre = nombre;
            Apellido = apellido;
            Email = email;
            Password = password;
            Dni = dni;
            Fecha = fecha;
            Nacionalidad = nacionalidad;
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string Dni
        {
            get { return dni; }
            set { dni = value; }
        }               

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }
        public string Nacionalidad
        {
            get { return nacionalidad; }
            set { nacionalidad = value; }
        }

        


        public virtual string GetTexto()
        {
            return string.Format("ID: {0}, Nombre: {1}, Apellidos: {2}, Email: {3}, Password: {4}, Dni: {5}, Fecha de nacimiento: {6}, Nacionalidad: {7}", Id, Nombre, Apellido, Email, Password, Dni, Fecha, Nacionalidad);
        }

        public enum Formatos
        {
            Bonito,
            Compacto
        }

        //Sobrecargas
        public string GetTexto(string formato)
        {
            switch (formato)
            {
                case "bonito":
                    return GetTexto();
                case "compacto":
                    return string.Format("{0},{1},{2},{3},{4},{5},{6},{7}",Id, Nombre, Apellido, Email, Password, Dni, Fecha, Nacionalidad);
                default:
                    return GetTexto();
            }
        }

        public string GetTexto(Formatos formato)
        {
            switch (formato)
            {
                case Formatos.Bonito:
                    return GetTexto("bonito");
                case Formatos.Compacto:
                    return GetTexto("compacto");
                default:
                    return GetTexto();
            }
        }

        //Sobrecarga de operadores
        public static bool operator >(Cliente u1, Cliente u2)
        {
            return u1.Email.CompareTo(u2.Email) > 0;
        }

        public static bool operator <(Cliente u1, Cliente u2)
        {
            return u1.Email.CompareTo(u2.Email) < 0;
        }

        public override string ToString()
        {
            return GetTexto();
        }

        public static bool ValidarNacionalidad(string ValNac)
        {
            if (ValNac == "ES" || ValNac == "EX" || ValNac == "es" || ValNac == "ex" || ValNac == "Es" || ValNac == "Ex" || ValNac == "eS" || ValNac == "eX" || ValNac == "")
            {
                return true;
            }
            else
            {
                Console.WriteLine(@"La nacionalidad no es valida. Tiene que ser (ES/EX)");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
        }

        public static bool ValidarEmail(string ValEm)
        {
            Regex val = new Regex(@"^[^@]+@[^@]+\.[a-zA-Z]{2,}$");
            if (val.IsMatch(ValEm) || ValEm == "")
            {
                return true;
            }
            else
            {
                Console.WriteLine("Formato del correo invalido");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
        }
        
        public static bool ValidarApellido(string ValAp)
        {
            Regex val = new Regex(@"\s");
            if ((ValAp.Length >= 5 && val.IsMatch(ValAp)) || ValAp == "")
            {
                return true;
            }
            else
            {
                Console.WriteLine("Tiene que haber 2 apellidos y el total tiene que tener 5 caracteres");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;

            }
        }

        public static bool ValidarNombre(string ValNom)
        {
            if (ValNom.Length < 2)
            {
                Console.WriteLine("El Nombre debetener mas de 2 caracteres");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool ValidarId(string ValId)
        {

            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");
            if (ValId == "0")
            {
                Console.WriteLine("El ID no puede ser 0");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
            else if (ValId == "")
            {
                Console.WriteLine("El ID es obligatorio");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
            else if (!val.IsMatch(ValId))
            {
                Console.WriteLine("El ID no puede ser una letra");
                Console.WriteLine("VUELVE A INTENTARLO");
                return false;
            }
            else
            {
                return true;
            }

        }
        
        public static bool ValidarFecha (string ValFecha)
        {
            if (ValFecha == "")
            {
                return true;
            }
            else
            {
                Regex val = new Regex(@"^([0][1-9]|[12][0-9]|3[01])(\/)([0][1-9]|[1][0-2])\2(\d{4})$");
                string d = ValFecha.Substring(0, 2);
                string m = ValFecha.Substring(3, ValFecha.Length - 8);
                string a = ValFecha.Substring(ValFecha.Length - 4, 4);
                string FechaHoy = DateTime.Now.ToString("yyyyMMddHHmmss");
                string D = FechaHoy.Substring(6, FechaHoy.Length - 12);
                string M = FechaHoy.Substring(4, FechaHoy.Length - 12);
                string A = FechaHoy.Substring(0, 4);

                if (!val.IsMatch(ValFecha))
                {
                    Console.WriteLine("Formato de Fecha invalido");
                }
                else
                {
                    int dia = Convert.ToInt32(d);
                    int mes = Convert.ToInt32(m);
                    int anno = Convert.ToInt32(a);
                    int Dia = Convert.ToInt32(D);
                    int Mes = Convert.ToInt32(M);
                    int Anno = Convert.ToInt32(A);
                    if ((Anno - anno) > 18)
                    {
                        return true;
                    }
                    else if ((Anno - anno) == 18)
                    {
                        if (mes < Mes)
                        {
                            return true;
                        }
                        else if (mes == Mes && dia <= Dia)
                        {
                            return true;
                        }
                        else if (mes > Mes)
                        {
                            Console.WriteLine("No se puede introducir una fecha posterior a la actual");
                            return false;
                        }
                        else if (mes == Mes && dia >= Dia)
                        {
                            Console.WriteLine("No se puede introducir una fecha posterior a la actual");
                            return false;
                        }                        
                        else
                        {
                            Console.WriteLine("Hay que ser mayor de edad para registrarse");
                            return false;
                        }
                    }
                    else if (anno > Anno)
                    {
                        Console.WriteLine("No se puede introducir una fecha posterior a la actual");
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("Hay que ser mayor de edad para registrarse");
                        return false;
                    }
                }
                return false;
            }
        }
    }   
}
