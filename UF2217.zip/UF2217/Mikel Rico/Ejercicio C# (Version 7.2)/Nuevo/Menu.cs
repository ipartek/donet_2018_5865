﻿using System;
using System.Collections.Generic;

namespace Nuevo
{
    class Menu
    {
        private int opcion;
        private List<Cliente> listaClientes;

        public void desplegar()
        {
            listaClientes = new List<Cliente>();

            do
            {
                do
                {
                    Console.Clear();
                    Console.WriteLine("");
                    Console.WriteLine("\t********* OPCION *********");
                    Console.WriteLine("\t*                        *");
                    Console.WriteLine("\t*  1- Alta               *");
                    Console.WriteLine("\t*  2- Modificación       *");
                    Console.WriteLine("\t*  3- Baja	         *");
                    Console.WriteLine("\t*  4- Ver listado        *");
                    Console.WriteLine("\t*  5- Buscar por Id      *");
                    Console.WriteLine("\t*  6- Buscar por Nombre  *");
                    Console.WriteLine("\t*  7- Salir              *");
                    Console.WriteLine("\t*                        *");
                    Console.WriteLine("\t**************************");
                    Console.WriteLine("");
                    Console.WriteLine("\tElige una opcion: ");
                    opcion = Convert.ToInt32(Console.ReadLine());

                    /* OPCION INVALIDA */
                    if (opcion < 1 || opcion > 7)
                    {
                        Console.WriteLine("\tIngrese una opcion válida\n");
                    }

                    switch (opcion)
                    {
                        case 1:
                            Console.WriteLine("\tHa elegido dar de alta un nuevo cliente\n");
                            Funciones.Alta();
                            break;
                        case 2:
                            Console.WriteLine("\tHa elegido modificar un nuevo cliente\n");
                            Funciones.Modificacion();
                            break;
                        case 3:
                            Console.WriteLine("\tHa elegido dar de baja un cliente\n");
                            Funciones.Baja();
                            break;
                        case 4:
                            Console.WriteLine("\tHa elegido ver el listado de clientes\n");
                            Funciones.Listado();
                            break;
                        case 5:
                            Console.WriteLine("\tHa elegido buscar un cliente por su id\n");
                            Funciones.BuscarId();
                            break;
                        case 6:
                            Console.WriteLine("\tHa elegido buscar un cliente por su nombre\n");
                            Funciones.BuscarNombre();
                            break;
                        case 7:
                            Console.WriteLine("\tEsta seguro de que quiere salir?\n");
                            Funciones.Salir();
                            break;
                        default:
                            Console.WriteLine("Selecciona una de las opciones dadas!");
                            break;
                    }


                } while (opcion < 1 || opcion > 7);
            } while (opcion != 7);
        }
    }
}
