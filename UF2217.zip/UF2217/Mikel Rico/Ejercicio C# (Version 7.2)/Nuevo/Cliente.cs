﻿using System;

namespace Nuevo
{
    [Serializable()]

    public class Cliente
    {
        public Cliente (int id, string nombre, string apellidos, string email, string password, string dni, string nacimiento, string nacionalidad)
        {
            Id = id;
            Nombre = nombre ?? throw new ArgumentNullException(nameof(nombre));
            Apellidos = apellidos ?? throw new ArgumentNullException(nameof(apellidos));
            Email = email ?? throw new ArgumentNullException(nameof(email));
            Password = password ?? throw new ArgumentNullException(nameof(password));
            Dni = dni ?? throw new ArgumentNullException(nameof(dni));
            Nacimiento = nacimiento ?? throw new ArgumentNullException(nameof(nacimiento));
            Nacionalidad = nacionalidad ?? throw new ArgumentNullException(nameof(nacionalidad));
        }

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Dni { get; set; }
        public string Nacimiento { get; set; }
        public string Nacionalidad { get; set; }

        public override string ToString() => $"{Id}, {Nombre}, {Apellidos}, {Email}, {Password}, {Dni}, {Nacimiento}, {Nacionalidad}";
        public Cliente() { }
    };

}