﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Nuevo
{
    public class Funciones
    {

        public static List<Cliente> ListaClientes = new List<Cliente>();

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Dni { get; set; }
        public string Nacimiento { get; set; }
        public string Nacionalidad { get; set; }


        public static void Alta()
       {
            Cliente NuevoCliente = new Cliente();

            Console.WriteLine("\tId: ");
            ValidarId();
            NuevoCliente.Id = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("\tNombre: ");
            ValidarNombre(Console.ReadLine());
            NuevoCliente.Nombre = Console.ReadLine();

            Console.WriteLine("\tApellidos: ");
            ValidarApellidos(Console.ReadLine());
            NuevoCliente.Apellidos = Console.ReadLine();

            Console.WriteLine("\tEmail: ");
            ValidarEmail(Console.ReadLine());
            NuevoCliente.Email = Console.ReadLine();

            Console.WriteLine("\tPassword: ");
            ValidarPassword(Console.ReadLine());
            NuevoCliente.Password = Console.ReadLine();

            Console.WriteLine("\tDNI: ");
            ValidarDni();
            NuevoCliente.Dni = Console.ReadLine();

            Console.WriteLine("\tNacimiento: ");
            ValidarNacimiento();
            NuevoCliente.Nacimiento = Console.ReadLine();

            Console.WriteLine("\tNacionalidad: ");
            ValidarNacionalidad();
            NuevoCliente.Nacionalidad = Console.ReadLine();

            ListaClientes.Add(NuevoCliente);

            Console.WriteLine("\tNuevo cliente registrado");
        }

        public static void Modificacion()
        {
            
        }

        public static void Baja()
        {
            Console.WriteLine("\tIngrese id a eliminar: ");
            int idEliminar = Convert.ToInt32(Console.ReadLine());
      
            
                
                    /*Console.WriteLine("¿Realmente desea eliminar a " + cl.Nombre + "? [si/no]");
                    respuesta = Console.ReadLine();
                    respuesta = respuesta.ToLower();*/

                    ListaClientes.RemoveAll(c => c.Id == idEliminar);
                
            
        }

        public static void Listado()
        {
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine("               Listado de Clientes");
            Console.WriteLine("------------------------------------------------------");

            foreach (Cliente cl in ListaClientes)
            {
                Console.WriteLine("------------------------------------------------------------");
                Console.WriteLine(cl);
                Console.WriteLine("\tID: " + cl.Id);
                Console.WriteLine("\tNombre: " + cl.Nombre);
                Console.WriteLine("\tApellido: " + cl.Apellidos);
                Console.WriteLine("\tEmail: " + cl.Email);
                Console.WriteLine("\tPassword: " + cl.Password);
                Console.WriteLine("\tDNI: " + cl.Dni);
                Console.WriteLine("\tNacimiento: " + cl.Nacimiento);
                Console.WriteLine("\tNacionalidad: " + cl.Nacionalidad);
                Console.WriteLine(" ");
            }
        }

        public static void BuscarId()
        {
            Console.WriteLine("\tID a buscar: ");
            int idBuscar = Convert.ToInt32(Console.ReadLine());

            foreach (Cliente cl in ListaClientes)
            {
                if (cl.Id == idBuscar)
                {
                    Console.WriteLine("------------------------");
                    Console.WriteLine(cl);
                    Console.WriteLine("\tID: " + cl.Id);
                    Console.WriteLine("\tNombre: " + cl.Nombre);
                    Console.WriteLine("\tApellido: " + cl.Apellidos);
                    Console.WriteLine("\tEmail: " + cl.Email);
                    Console.WriteLine("\tPassword: " + cl.Password);
                    Console.WriteLine("\tDNI: " + cl.Dni);
                    Console.WriteLine("\tNacimiento: " + cl.Nacimiento);
                    Console.WriteLine("Nacionalidad: " + cl.Nacionalidad);
                    Console.WriteLine(" ");

                    break;
                }
            }
        }

        public static void BuscarNombre()
        {
            Console.WriteLine("\tNombre a buscar: ");
            string nombreBuscar = Console.ReadLine();

            foreach (Cliente cl in ListaClientes)
            {
                if (cl.Nombre == nombreBuscar)
                {
                    Console.WriteLine("------------------------");
                    Console.WriteLine(cl);
                    Console.WriteLine("\tID: " + cl.Id);
                    Console.WriteLine("\tNombre: " + cl.Nombre);
                    Console.WriteLine("\tApellido: " + cl.Apellidos);
                    Console.WriteLine("\tEmail: " + cl.Email);
                    Console.WriteLine("\tPassword: " + cl.Password);
                    Console.WriteLine("\tDNI: " + cl.Dni);
                    Console.WriteLine("\tNacimiento: " + cl.Nacimiento);
                    Console.WriteLine("\tNacionalidad: " + cl.Nacionalidad);
                    Console.WriteLine(" ");
                }
            }
        }

        public static void Salir()
        {
            Console.WriteLine("\tGracias por utilizar esta aplicación");
            Console.ReadLine();
        }

        /* VALIDAR ID */
        public static void ValidarId()
        {
            int Id;
            Console.Write("Ingrese un número entero: ");

            //TryParse intenta convertir lo que lee a entero, si lo logra devuelve true, si falla devuelve false
            // El resultado de la conversión lo guarda en el segundo parámetro, en este caso la variable entero
            // y por eso se debe usar la palabra reservada out
            while (!Int32.TryParse(Console.ReadLine(), out Id))
            {
                Console.Write("El valor ingresado no es válido.\nIngrese un número entero válido: ");
            }
            Console.WriteLine("El Id ingresado es: {0}", Id);
        }

        /* VALIDAR NOMBRE */
        public static void ValidarNombre(string Nombre)
        {
            Regex Val = new Regex(@"^[a-zA-Z]+$");
            if (!Val.IsMatch(input: Nombre))//controlo que el nombre sea solo letras
            {
                Console.WriteLine("el nombre solo debe contener letras \\n");
            }
        }

        /* VALIDAR APELLIDOS */
        public static void ValidarApellidos(string Apellidos)
        {
            Regex Val = new Regex(@"^[a-zA-Z]+$");
            if (!Val.IsMatch(input: Apellidos))//Apellido 4 caracteres y un espacion
            {
                Console.WriteLine("el apellido debe contener como minimo 4 caracteres y un espacio \\n");
            }
        }

        /* VALIDAR EMAIL */
        public static void ValidarEmail(string Email)
        {
            Regex Val = new Regex(@"\w + ([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            if (!Val.IsMatch(input: Email))
            {
                Console.WriteLine("Email no valido \\n");
            }
        }

        /* VALIDAR CONTRASEÑA */
        public static void ValidarPassword(string Password)
        {
            Regex Val = new Regex(@"/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&#.$($)$-$_])[A-Za-z\d$@$!%*?&#.$($)$-$_]{8,15}$/;");
            if (!Val.IsMatch(input: Password))
            {
                Console.WriteLine("Contraseña no válida \\n");
            }
        }

        /* VALIDAR DNI */
        public static void ValidarDni()
        {
            throw new Exception("DNI no valida");
        }

        /* VALIDAR NACIMIENTO */
        public static void ValidarNacimiento()
        {
            int edad;
            Console.Write("¿Cuantos años tienes? ");
            edad = Int16.Parse(Console.ReadLine());

            if (edad >= 18)
                Console.Write("\n\n\tTu tienes " + edad + " años y eres mayor de edad.");
            else
                Console.Write("\n\n\tTu tienes " + edad + " años y NO eres mayor de edad.");
        }

        /* VALIDAR NACIONALIDAD */
        public static void ValidarNacionalidad()
        {
            throw new Exception("Nacionalidad no valida");
        }
    }
}
