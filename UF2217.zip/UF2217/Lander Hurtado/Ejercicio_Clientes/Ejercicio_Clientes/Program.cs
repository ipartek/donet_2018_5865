﻿using System;
using System.Text.RegularExpressions;
using Entidades;
using Acceso_a_datos;
using System.IO;

namespace Ejercicio_Clientes
{
    class Program
    {
        static void Main(string[] args)
        {
            Lista<Cliente> lista = new Lista<Cliente>();
            int contador = 1, nclientes;
            string seleccion, nombre, id, apellidos, contrasena, email, dni, fecha, nacionalidad;
            DateTime hoy = DateTime.Now;
            bool seguir = true;



            Regex er_nombre = new Regex(@"[a-zA-Z]{2,}");
            Regex er_apellidos = new Regex(@"[a-zA-Z]*\s[a-zA-Z]");
            Regex er_email = new Regex(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$");



            try
            {

                String[] values = File.ReadAllText(@"Lista.csv").Split(',');
                nclientes = values.Length / 8;
                for (int i = 0; i < nclientes; i++)
                {
                    Cliente cliente = new Cliente();
                    cliente.Id = Int32.Parse(values[i * 8]);
                    contador = Int32.Parse(values[i * 8])+1;
                    cliente.Nombre = values[i * 8 + 1];
                    cliente.Apellidos = values[i * 8 + 2];
                    cliente.Email = values[i * 8 + 3];
                    cliente.Contrasena = values[i * 8 + 4];
                    cliente.Dni = values[i * 8 + 5];
                    cliente.Fecha_Nacimiento = values[i * 8 + 6];
                    cliente.Nacionalidad = values[i * 8 + 7];
                    lista.Add(cliente);
                }
            }
            catch { }

            try
            {
                while (seguir)
                {
                    Console.WriteLine("\n-----Menu-----\nElige una opción: \n-1.Alta \n-2.Modificación \n-3.Baja \n-4.Ver listado \n-5.Buscar por Id \n-6.Buscar por Nombre \n-7.Buscar por campo especifico \n-0.Salir\n--------------");

                    seleccion = Console.ReadLine();
                    switch (seleccion)
                    {
                        case "1":
                            Cliente cliente = new Cliente();
                            PedirCampo("Nombre: ", s => cliente.Nombre = s);
                            PedirCampo("Apellidos: ", s => cliente.Apellidos = s);
                            PedirCampo("Contraseña: ", s => cliente.Contrasena = s);
                            PedirCampo("Email: ", s => cliente.Email = s);
                            PedirCampo("Dni: ", s => cliente.Dni = s);
                            PedirCampo("Fecha de nacimiento: ", s => cliente.Fecha_Nacimiento = s);
                            //PedirCampo("Nacionalidad: ", s => cliente.Nacionalidad = s);
                            cliente.Nacionalidad = "";
                            cliente.Id = contador;
                            contador = contador + 1;
                            lista.Add(cliente);

                            break;
                        case "2":
                            Console.Write("\n-Escribe el id del cliente que deseas modificar:");
                            id = Console.ReadLine();
                            cliente = lista.FindById(id);
                            PedirCampo("Nombre: ", s => cliente.Nombre = s);
                            PedirCampo("Apellidos: ", s => cliente.Apellidos = s);
                            PedirCampo("Contraseña: ", s => cliente.Contrasena = s);
                            PedirCampo("Email: ", s => cliente.Email = s);
                            PedirCampo("Dni: ", s => cliente.Dni = s);
                            PedirCampo("Fecha de nacimiento: ", s => cliente.Fecha_Nacimiento = s);
                            //PedirCampo("Nacionalidad: ", s => cliente.Nacionalidad = s);
                            cliente.Nacionalidad = "";

                            break;
                        case "3":
                            Console.Write("\n-Escribe el id del cliente que deseas dar de baja:");
                            id = Console.ReadLine();
                            lista.Borrar(id);
                            break; ;
                        case "4":
                            foreach (Cliente c in lista.Componentes)
                            {
                                Console.WriteLine(c.ToString());
                            }
                            break;
                        case "5":
                            try
                            {
                                Console.Write("\n-Escribe el id del cliente que deseas buscar:");
                                id = Console.ReadLine();
                                cliente = lista.FindById(id);
                                Console.WriteLine(cliente.ToString());
                            }
                            catch (Exception e) { Console.WriteLine("No se ha encontrado a ningun cliente con esos datos"); }
                            break;
                        case "6":

                            Console.Write("\n-Escribe el nombre del cliente que deseas buscar:");
                            nombre = Console.ReadLine();
                            foreach (Cliente c in lista.FindByNombre(nombre)) { Console.WriteLine(c.ToString()); }
                            break;
                        case "7":
                            Console.Write("\n-Escribe el campo por el que quieres buscar un cliente:\n 1-Id\n 2-Nombre\n 3-Apellido\n 4-Contraseña\n 5-Email\n 6-Dni\n 7-Fecha de nacimiento\n 8-Nacionalidad\n");
                            seleccion = Console.ReadLine();
                            try
                            {
                                switch (seleccion)
                                {
                                    case "1":
                                        Console.Write("\nEscribe el Id que quieres buscar:");
                                        id = Console.ReadLine();
                                        cliente = lista.FindById(id);
                                        Console.WriteLine(cliente.ToString());
                                        break;
                                    case "2":
                                        Console.Write("\nEscribe el nombre que quieres buscar: ");
                                        nombre = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByNombre(nombre)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "3":
                                        Console.Write("\nEscribe los apellidos que quieres buscar: ");
                                        apellidos = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByApellidos(apellidos)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "4":
                                        Console.Write("\nEscribe la contraseña que quieres buscar: ");
                                        contrasena = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByContrasena(contrasena)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "5":
                                        Console.Write("\nEscribe el Email que quieres buscar: ");
                                        email = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByEmail(email)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "6":
                                        Console.Write("\nEscribe el Dni que quieres buscar: ");
                                        dni = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByDni(dni)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "7":
                                        Console.Write("\nEscribe la fecha de nacimiento que quieres buscar: ");
                                        fecha = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByFecha(fecha)) { Console.WriteLine(c.ToString()); }
                                        break;
                                    case "8":
                                        Console.Write("\nEscribe la Nacionalidad que quieres buscar: ");
                                        nacionalidad = Console.ReadLine();
                                        foreach (Cliente c in lista.FindByNacionalidad(nacionalidad)) { Console.WriteLine(c.ToString()); }
                                        break;

                                }
                            }
                            catch (Exception e) { Console.WriteLine("No se ha encontrado a ningun cliente con esos datos"); }

                            break;
                        case "0":
                            seguir = false;
                            break;
                        default:
                            Console.WriteLine("Introduce un numero del 0 al 7");
                            break;
                    }
                }
            }
            finally
            {
                using (StreamWriter tw = new StreamWriter("Lista.csv", false))
                {
                    foreach (Cliente c in lista.Componentes)
                    {
                        tw.Write(c.csv());
                    }
                }
            }

        }
        


        private delegate void DelegadoPedirCampo(string o);

        private static void PedirCampo(string mensaje, DelegadoPedirCampo dpc)
        {
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.Write(mensaje);
                    dpc(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.Write(e.Message);
                    repetir = true;
                }
            } while (repetir == true);
        }

    }
    
}
