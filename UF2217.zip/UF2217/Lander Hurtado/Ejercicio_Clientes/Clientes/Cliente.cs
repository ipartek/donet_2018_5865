﻿using System;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tipos
{
    public class Cliente
    {
        private int id, num;
        private string nombre, apellidos, email, contrasena, dni, fecha_nacimiento, nacionalidad;
        private string numero, letr, letra_ex, letra;
        private DateTime nacimiento;
        DateTime hoy = DateTime.Now;
        


        Regex er_esp = new Regex(@"^\d{8}[TRWAGMYFPDXBNJZSQVHLCKET]$");
        Regex er_extr = new Regex(@"^[XYZ]\d{7}[TRWAGMYFPDXBNJZSQVHLCKET]$");

        Regex er_nombre = new Regex(@"[a-zA-Z]{2,}");
        Regex er_apellidos = new Regex(@"[a-zA-Z]*\s[a-zA-Z]");
        Regex er_email = new Regex(@"^[a-zA-Z0-9_\-\.~]+@[a-zA-Z0-9_\-\.~]+\.[a-zA-Z]+$");


        public object this[string propertyName]
        {
            get { return GetType().GetProperty(propertyName).GetValue(this, null); }
        }



        /*
        public string this[string campo]
        {
            get
            {
                switch (campo)
                {
                    case "Id":
                        return Id.ToString() ;
                    case "Nombre":
                        return Nombre;
                    case "Apellidos":
                        return Apellidos;
                    case "Contraseña":
                        return Contrasena;
                    case "Email":
                        return Email;
                    case "Dni":
                        return Dni;
                    case "Fecha":
                        return Fecha_Nacimiento;
                    case "Nacionalidad":
                        return Nacionalidad;
                    default:
                        return "No se encontraron coincidencias";
                }
            }

        }
        */

        public int Id {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set {
                if (!er_nombre.IsMatch(value)) { throw new Exception("\nEl nombre que has intoducido no cumplen con el formato\n"); }
                else { nombre = value; }
            }
        }

        public string Apellidos
        {
            get { return apellidos; }
            set {
                if (!er_apellidos.IsMatch(value)) { throw new Exception("\nLos apellidos que has intoducido no cumplen con el formato\n"); }
                else { apellidos = value; }
            }
        }

        public string Email
        {
            get { return email; }
            set {
                if (!er_email.IsMatch(value)) { throw new Exception($"\nEl Email que has intoducido no cumplen con el formato {Email}\n"); }
                else { email = value; }
            }
        }

        public string Contrasena
        {
            get { return contrasena; }
            set { contrasena = value; }
        }

        public string Dni
        {
            get { return dni; }
            set {
                if (!nif(value)) { throw new Exception("\nEl Dni es incorrecto\n"); }
                else { dni = value; }
            }
        }

        public string Fecha_Nacimiento
        {
            get { return fecha_nacimiento; }
            set {
                nacimiento = DateTime.Parse(value);
                nacimiento = nacimiento.AddYears(18);
                if (nacimiento.Date >= hoy.Date) { throw new Exception("\nTienes que ser mayor de 18 años\n"); }
                else { fecha_nacimiento = value; }
            }
        }

        public string Nacionalidad
        {
            get { return nacionalidad; }
            set {
                if (value != "Español" && value != "Extrangero") { throw new Exception("\nTienes que introducir Español o Extrangero\n"); }
                else { nacionalidad = value; }
            }
        }


        public Cliente(int Id, string Nombre, string Apellidos,  string Contrasena, string Email, string Dni, string Fecha_nacimiento, string Nacionalidad)
        {

            id = Id;
            nombre = Nombre;
            apellidos = Apellidos;
            contrasena = Contrasena;
            email = Email;
            dni = Dni;
            fecha_nacimiento = Fecha_nacimiento;
            nacionalidad = Nacionalidad;
            
        }

        public Cliente() { }


        public bool nif(string dni)
        {


            if (er_esp.IsMatch(dni))
            {
                numero = dni.Substring(0, dni.Length - 1);
                letr = dni.Substring(dni.Length - 1, 1);
                num = Convert.ToInt32(numero);
                num = num % 23;
                letra = "TRWAGMYFPDXBNJZSQVHLCKE";
                letra = letra.Substring(num,1);
                if (letra == letr)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else if (er_extr.IsMatch(dni))
            {
                letra_ex = dni.Substring(0, 1);
                numero = dni.Substring(1, dni.Length - 2);
                letr = dni.Substring(dni.Length - 1, 1);
                switch (letra_ex)
                {
                    case "X":
                        numero = "0" + numero;
                        break;
                    case "Y":
                        numero = "1" + numero;
                        break;
                    case "Z":
                        numero = "2" + numero;
                        break;
                }
                num = Convert.ToInt32(numero);
                num = num % 23;
                letra = "TRWAGMYFPDXBNJZSQVHLCKE";
                letra = letra.Substring(num, 1);
                if (letra == letr)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }




        public override string ToString()
        {
            return string.Format("\n-Id: {7}\n-Nombre: {0}\n-Apellidos: {1}\n-Email: {2}\n-Contraseña: {3}\n-DNI: {4}\n-Fecha de Nacimiento: {5}\n-Nacionalidad: {6}\n", nombre, apellidos, email, contrasena, dni, fecha_nacimiento, nacionalidad, id);
        }
    }
}
