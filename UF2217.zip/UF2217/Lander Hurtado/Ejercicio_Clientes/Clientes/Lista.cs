﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Tipos
{
    public class Lista<T>
    {
        private List<Cliente> lista = new List<Cliente>();
        StringBuilder listado = new StringBuilder();
        private Cliente result;

        

        public void Add(Cliente cliente)
        {
            if(cliente == null)
            {
                throw new Exception("No se admiten clientes nulos");
            }
            lista.Add(cliente);
        }

        public void Borrar(string id)
        {
            Cliente cliente = FindById(id);
            lista.Remove(cliente);
        }

        private ReadOnlyCollection<Cliente> GetComponentes()
        {
            return new ReadOnlyCollection<Cliente>(lista);
        }

        public ReadOnlyCollection<Cliente> Componentes
        {
            get { return GetComponentes(); }
        }

        public Cliente FindById(string id){return lista.Find(c => c.Id == Int32.Parse(id));}
        public List<Cliente> FindByNombre (string nombre){return lista.FindAll(c => c["Nombre"] == nombre); }
        public List<Cliente> FindByApellidos(string apellidos) { return lista.FindAll(c => c["Apellidos"] == apellidos); }
        public List<Cliente> FindByContrasena(string contrasena) { return lista.FindAll(c => c["Contraseña"] == contrasena); }
        public List<Cliente> FindByEmail(string email) { return lista.FindAll(c => c["Email"] == email); }
        public List<Cliente> FindByDni(string dni) { return lista.FindAll(c => c["Dni"] == dni); }
        public List<Cliente> FindByFecha(string fecha) { return lista.FindAll(c => c["Fecha"] == fecha); }
        public List<Cliente> FindByNacionalidad(string nacionalidad) { return lista.FindAll(c => c["Nacionalidad"] == nacionalidad); }

    }
}
