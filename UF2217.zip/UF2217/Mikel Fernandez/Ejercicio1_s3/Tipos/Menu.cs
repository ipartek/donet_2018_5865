﻿using System;

namespace Tipos
{
    public class Menu
    {
        private static int opcion;
        public static int desplegarMenu()
        {
            Console.WriteLine("EJERCICIO 1 - MENU DE CLIENTES");
            Console.WriteLine("==============================\n");
            Console.WriteLine("1. ALTA");
            Console.WriteLine("2. MODIFICACIÓN");
            Console.WriteLine("3. CONSULTAR LISTA");
            Console.WriteLine("4. BAJA");
            Console.WriteLine("5. BUSCAR POR ID");
            Console.WriteLine("6. BUSCAR POR NOMBRE");
            Console.WriteLine("7. SALIR\n");
            Console.Write("INTRODUCE UN NÚMERO DE OPCION: ");
            // return Convert.ToInt32(Console.ReadLine());
            opcion = Convert.ToInt32(Console.ReadLine());
            return (opcion);
        }
    }
}
            /*if (opcion < 1 || opcion > 7)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("INTRODUCE UN NÚMERO DE OPCIÓN VÁLIDO");
                Console.ResetColor();
                Console.ReadKey();
                Console.Clear();
            }*/