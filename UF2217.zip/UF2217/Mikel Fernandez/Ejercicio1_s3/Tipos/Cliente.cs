﻿using System;
using System.Text.RegularExpressions;


namespace Tipos
{
    public class Cliente
    {
        // IDENTIFICADOR
        private int id;
        // No hay condiciones de excepcion porque las variables int, no pueden ser nulas, minimo 0, y tampoco pueden ser negativas
        public int Id { get; set; }

        // NOMBRE
        private string nombre;
        public string Nombre
        {
            //Control de excepciones de Nombre. No puede Ser nulo. Debe tener al menos 2 caracteres.
            get { return nombre; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("EL CAMPO NOMBRE NO PUEDE SER NULO");
                }
                if (value.Trim().Length < 2)
                {
                    throw new TiposException("LA LONGITUD DEL NOMBRE DEBE SER AL MÍNIMO 2");
                }
                nombre = value.Trim();
            }
        }
        // APELLIDOS
        private string apellidos;
        public string Apellidos
        {
            // Control de excepciones de Apellidos. No puede ser nulo. Cada apellido debe tener 5 caracteres y un espacio.
            get { return apellidos; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("EL CAMPO APELLIDOS NO PUEDE SER NULO");
                }
                if (!Regex.IsMatch(value.Trim(), @"^\D{5,} \D{5,}$"))
                {
                    throw new TiposException("EL CAMPO APELLIDOS DEBE TENER DOS APELLIDOS DE 5 LETRAS Y UN ESPACIO ENTRE ELLOS");
                }
                apellidos = value.Trim();
            }
        }

        // CUENTA DE CORREO ELECTRONICO
        private string email;
        public string Email
        {
            // Control de excepciones del correo electronico, se han añadido las del ejemplo.
            get { return email; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("EMAIL INTRODUCIDO ES NULO");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("ES OBLIGATORIO RELLENAR EL EMAIL");
                }

                if (!Regex.IsMatch(value.Trim(), @"^\w+@\w+\.\w+$"))
                {
                    throw new TiposException("EL FORMATO DEL EMAIL NO ES VALIDO");
                }
                email = value.Trim();
            }
        }
        // CONTRASEÑA
        private string passwd;
        // No hay condiciones de excepcion
        public string Passwd { get; set; }

        // NUMERO DE IDENTIFICACION PERSONAL
        private string dni;

        public string Dni { get; set; }

        // FECHA DE NACIMIENTO
        private DateTime fecnac;
        public string Fecnac { get; set; }

        // NACIONALIDAD
        private string nacion;
        public string Nacion
        {
            // Control de excepciones del correo electronico, se han añadido las del ejemplo.
            get { return nacion; }
            set
            {
                /*if (value != "ESPAÑOLA" && value != "EXTRANJERA")
                {
                    throw new TiposException("La nacionalidad solo puede ser ESPAÑOLA o EXTRANJERA");
                }*/
            }
        }

        public Cliente(int id = 0, string nombre = "", string apellidos = "", string email = "", string passwd = "", string dni = "", string fecnac = "", string nacion = "")
        {
            Id = id;
            Nombre = nombre;
            Apellidos = apellidos;
            Email = email;
            Passwd = passwd;
            Dni = dni;
            Fecnac = fecnac;
            Nacion = nacion;
        }
    }
}
