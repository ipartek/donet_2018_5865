﻿using System;
using System.Collections.Generic;

namespace Tipos
{
    public class Metodos
    {
        public static List<Cliente> clientes = new List<Cliente>();
        private static int opcion;

        // Función que pinta un menú por pantalla y devuelve el valor introducido por el usuario.
        public static int desplegarMenu()
        {
            Console.WriteLine("EJERCICIO 1 - MENU DE CLIENTES");
            Console.WriteLine("==============================\n");
            Console.WriteLine("1. ALTA");
            Console.WriteLine("2. MODIFICACIÓN");
            Console.WriteLine("3. CONSULTAR LISTA");
            Console.WriteLine("4. BAJA");
            Console.WriteLine("5. BUSCAR POR ID");
            Console.WriteLine("6. BUSCAR POR NOMBRE");
            Console.WriteLine("7. SALIR\n");
            Console.Write("INTRODUCE UN NÚMERO DE OPCION: ");
            // return Convert.ToInt32(Console.ReadLine());
            opcion = Convert.ToInt32(Console.ReadLine());
            return (opcion);
        }

        // Función que recibe un valor y devuelve un valor booleano en función de las condiciones
        public static bool ComprobarOpcion(int opcion) => opcion < 1 || opcion > 7;

        // Función que recibe un valor y ejecuta otras funciones.
        public static void ProcesarOpcion(int opcion)
        {
            switch (opcion)
            {
                case 1:
                    Alta();
                    break;
                case 2:
                    Modificacion();
                    break;
                case 3:
                    Listado();
                    break;
                case 4:
                    Baja();
                    break;
                case 5:
                    BusquedaId();
                    break;
                case 6:
                    BusquedaNombre();
                    break;
                default:
                    break;
            }
        }

        // Función que que se encarga de recibir un valor y devolver un valor booleano para determinar la salida del programa.
        public static bool PeticionSalir(int opcion) => opcion == 7; // Funcionalmente esta linea es una pijada, podría implementarse de forma mas sencilla en Program.cs

        // Función que almacena un conjunto de datos.
        public static void Alta()
        {
            Cliente cliente = new Cliente();
            Console.WriteLine("ALTA DE NUEVO CLIENTE");
            Console.WriteLine("=====================");
            Console.WriteLine("Id: ");
            cliente.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nombre: ");
            cliente.Nombre = Console.ReadLine();
            Console.WriteLine("Apellidos: ");
            cliente.Apellidos = Console.ReadLine();
            Console.WriteLine("Cuenta de correo electrónico: ");
            cliente.Email = Console.ReadLine();
            Console.WriteLine("Password: ");
            cliente.Passwd = Console.ReadLine();
            Console.WriteLine("Número de Documento de identidad: ");
            cliente.Dni = Console.ReadLine();
            Console.WriteLine("Fecha de Nacimiento: ");
            cliente.Fecnac = Console.ReadLine();
            Console.WriteLine("Nacionalidad: ");
            cliente.Nacion = Console.ReadLine();
            clientes.Add(cliente);
        }

        // Método que mediante un bucle pinta linea a linea lo contenido en usuario
        private static void Listado()
        {
            foreach (Cliente cliente in clientes)
            {
                Console.WriteLine(cliente);
            }
        }

        // Método que modifica un conjunto de datos
        public static void Modificacion()
        {
            throw new TiposException("FUNCIÓN AÚN NO OPERATIVA");
        }

        // Método que elimina un conjunto de datos
        public static void Baja()
        {
            throw new TiposException("FUNCIÓN AÚN NO OPERATIVA");
        }

        // Método que busca por Id en un conjunto de datos
        public static void BusquedaId()
        {
            throw new TiposException("FUNCIÓN AÚN NO OPERATIVA");
        }

        // Método que busca por Nombre en un conjunto de datos
        public static void BusquedaNombre()
        {
            throw new TiposException("FUNCIÓN AÚN NO OPERATIVA");
        }

        // Método que mediante un bucle genera una serie de valores
        public static void GenerarDatosDePrueba()
        {
            clientes.Add(new Cliente(1, "Mikel", "Fernandez Llamas", "mikelfl@email.com", "12345", "88649271A", "01/01/1970", "Española"));
            clientes.Add(new Cliente(2, "Alberto", "Pelaez Rodriguez", "albertopr@email.com", "12345", "56456145T", "01/01/1970", "Española"));
            clientes.Add(new Cliente(3, "Jonathan", "Castro Gonzalez", "jonathancg@email.com", "12345", "71128356M", "01/01/1970", "Española"));
        }
    }
}
