﻿using System;
using System.Collections.Generic;
using static System.Console;
using Tipos;

namespace EjemploUsuario
{
    class Program
    {
        static void Main(string[] args)
        {
            Metodos.GenerarDatosDePrueba();
            int opcion;
            do
            {
                opcion = Metodos.desplegarMenu();
                if (!Metodos.ComprobarOpcion(opcion))
                {
                    Metodos.ProcesarOpcion(opcion);
                }
            } while (!Metodos.PeticionSalir(opcion));
        }

    }
}