﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio
{
    public class Metodos
    {
        public static List<Cliente> clientes = new List<Cliente>();
        private enum OpcionesMenu
        {
            Alta = 1, Modificacion = 2, Baja = 3, Listado = 4, BuscarId = 5, BuscarNombre = 6, Salir = 0
        }

        public static void MostrarMenu()

        {
            Console.WriteLine("*********************************************************************");
            Console.WriteLine("\t MENU PRINCIPAL");
            Console.WriteLine("*********************************************************************");
            foreach (int valor in Enum.GetValues(typeof(OpcionesMenu)))
            {
                Console.WriteLine($"\t {valor}. {(OpcionesMenu)valor}");
            }
            Console.WriteLine("*********************************************************************");

        }
        public static void ProcesarOpcion(int opcion)
        {
            OpcionesMenu opcionMenu = (OpcionesMenu)opcion;

            switch (opcionMenu)
            {
                case OpcionesMenu.Alta:
                    Alta();
                    break;
                case OpcionesMenu.Modificacion:
                    Modificacion();
                    break;
                case OpcionesMenu.Baja:
                    Baja();
                    break;
                case OpcionesMenu.Listado:
                    Listado();
                    break;
                case OpcionesMenu.BuscarId:
                    BuscarId();
                    break;
                case OpcionesMenu.BuscarNombre:
                    BuscarNombre();
                    break;
                case OpcionesMenu.Salir:
                    Salir();
                    break;
                default:
                    break;
            }
        }

        public static void Salir()
        {

            Console.WriteLine("\t Gracias por utililizar mi aplicacion");

        }

        private static void BuscarNombre()

        {
            string NOMBREBuscar;
            bool correcto = true;
            
                Console.Write("\t NOMBRE A BUSCAR: ");
                NOMBREBuscar = Console.ReadLine();

                correcto = Int32.TryParse((NOMBREBuscar), out int entero);
                if (correcto)
                {
                    throw new TiposException("\t Introduzca un nombre valido y no un número");
                }
           


            foreach (Cliente c in clientes)
            {
                if (c.Nombre == NOMBREBuscar)
                {
                    Console.WriteLine("\t ID:" + c.Id);
                    Console.WriteLine("\t NOMBRE:" + c.Nombre);
                    Console.WriteLine("\t APELLIDOS:" + c.Apellidos);
                    Console.WriteLine("\t EMAIL:" + c.Email);
                    Console.WriteLine("\t CONTRASEÑA:" + c.Password);
                    Console.WriteLine("\t DNI:" + c.Dni);
                    Console.WriteLine("\t FECHA DE NACIMIENTO:" + c.Fechanacimiento);
                    Console.WriteLine("\t NACIONALIDAD:" + c.Nacionalidad);
                }
            }

        }

        private static void BuscarId()
        {

            Console.Write("\t ID A BUSCAR: ");
            int IDBuscar = Convert.ToInt32(Console.ReadLine());
            foreach (Cliente c in clientes)
            {
                if (c.Id == IDBuscar)
                {
                    Console.WriteLine("\t ID:" + c.Id);
                    Console.WriteLine("\t NOMBRE:" + c.Nombre);
                    Console.WriteLine("\t APELLIDOS:" + c.Apellidos);
                    Console.WriteLine("\t EMAIL:" + c.Email);
                    Console.WriteLine("\t CONTRASEÑA:" + c.Password);
                    Console.WriteLine("\t DNI:" + c.Dni);
                    Console.WriteLine("\t FECHA DE NACIMIENTO:" + c.Fechanacimiento);
                    Console.WriteLine("\t NACIONALIDAD:" + c.Nacionalidad);
                    break;
                }
            }
        }

        private static void Baja()
        {
            int idEliminar;
            Console.WriteLine("\t INGRESE ID PARA DAR DE BAJA AL CLIENTE CORRESPONDIENTE");
            idEliminar = Int32.Parse(Console.ReadLine());
            clientes.RemoveAll( c => c.Id == idEliminar);
       
        }

        private static void Modificacion()
        {
            Console.Write("\t INTRODUZCA ID A BUSCAR PARA MODIFICAR CLIENTE DESEADO: ");
            int IDBuscar = Convert.ToInt32(Console.ReadLine());
            foreach (Cliente c in clientes)
            {
                if (c.Id == IDBuscar)
                {
                    Console.WriteLine("\t ESTE ES EL CLIENTE QUE QUIERE MODIFICAR");
                    Console.WriteLine("\t ID:" + c.Id);
                    Console.WriteLine("\t NOMBRE:" + c.Nombre);
                    Console.WriteLine("\t APELLIDOS:" + c.Apellidos);
                    Console.WriteLine("\t EMAIL:" + c.Email);
                    Console.WriteLine("\t CONTRASEÑA:" + c.Password);
                    Console.WriteLine("\t DNI:" + c.Dni);
                    Console.WriteLine("\t FECHA DE NACIMIENTO:" + c.Fechanacimiento);
                    Console.WriteLine("\t NACIONALIDAD:" + c.Nacionalidad);
                    Console.WriteLine("\t ID: ");
                    c.Id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\t NOMBRE: ");
                    c.Nombre = Console.ReadLine();
                    Console.WriteLine("\t APELLIDOS: ");
                    c.Apellidos = Console.ReadLine();
                    Console.WriteLine("\t EMAIL: ");
                    c.Email = Console.ReadLine();
                    Console.WriteLine("\t PASSWORD: ");
                    c.Password = Console.ReadLine();
                    Console.WriteLine("\t DNI: ");
                    c.Dni = Console.ReadLine();
                    Console.WriteLine("\t FECHA DE NACIMIENTO: ");
                    c.Fechanacimiento = Console.ReadLine();
                    Console.WriteLine("\t NACIONALIDAD: ");
                    c.Nacionalidad = Console.ReadLine();
                }
            }
        }

        public static bool ElUsuarioQuiereSalir(int opcion) =>
           (OpcionesMenu)opcion == OpcionesMenu.Salir;

        public static void Alta()
        {
            Cliente clientenuevo = new Cliente();
            Console.Write("\t ID: ");
            clientenuevo.Id = Convert.ToInt32(Console.ReadLine());
            Console.Write("\t NOMBRE: ");
            clientenuevo.Nombre = Console.ReadLine();
            Console.Write("\t APELLIDOS: ");
            clientenuevo.Apellidos = Console.ReadLine();
            Console.Write("\t EMAIL: ");
            clientenuevo.Email = Console.ReadLine();
            Console.Write("\t PASSWORD: ");
            clientenuevo.Password = Console.ReadLine();
            Console.Write("DNI: ");
            clientenuevo.Dni = Console.ReadLine();
            Console.Write("\t FECHA DE NACIMIENTO: ");
            clientenuevo.Fechanacimiento = Console.ReadLine();
            Console.Write("\t NACIONALIDAD: ");
            clientenuevo.Nacionalidad = Console.ReadLine();

            clientes.Add(clientenuevo);

        }

        public static int PedirOpcion()
        {
            int opcion;

            do
            {
                opcion = LeerEntero("\t Elige una opción del menú: ");
            }
            while (!ExisteOpcion(opcion));

            return opcion;
        }
        private static bool ExisteOpcion(int opcion)
        {
            bool existe = Enum.IsDefined(typeof(OpcionesMenu), opcion);

            if (!existe)
            {
                Console.WriteLine("\t No existe esa opción");
            }

            return existe;
        }

        private static int LeerEntero(string mensaje)
        {
            int entero;
            string resultado;

            bool correcto = true;

            do
            {
                Console.Write(mensaje);
                resultado = Console.ReadLine();
                correcto = int.TryParse(resultado, out entero);

                if (!correcto)
                {
                    Console.WriteLine("\t Eso no es un número");
                }
            }
            while (!correcto);

            return entero;
        }
        public static void GenerarDatosDePrueba()
        {
            //for (int i = 1; i <= 5; i++)
            //    clientes.Add(new Cliente ($"{i}", $"nombre{i}", $"apellidos apellidos{i}",$"email{i}@b.c", $"password{i}", $"dni", $"Español"));
            clientes.Add(new Cliente(1, "Pepe", "Gomez Gonzalez", "qweqwewqe@ds.com", "dsdasdasdasd", "12345678Z", ("02/05/1984"), "Español"));
            clientes.Add(new Cliente(2, "Pepe", "Gomez Gonzalez", "qweqqe@ds.com", "dsdasdasdasd", "12345678Z", ("02/05/1984"), "Español"));
            clientes.Add(new Cliente(3, "pepe", "Gomez Gonzalez", "qweqwwqe@ds.com", "dsdasdasdasd", "12345678Z", ("02/05/1984"), "Español"));
        }

        public static void Listado()
        {
            foreach (Cliente c in clientes)
            {
                Console.WriteLine("\t ID :" + c.Id);
                Console.WriteLine("\t NOMBRE :" + c.Nombre);
                Console.WriteLine("\t APELLIDOS: " + c.Apellidos);
                Console.WriteLine("\t EMAIL: " + c.Email);
                Console.WriteLine("\t CONTRASEÑA: " + c.Password);
                Console.WriteLine("\t DNI: " + c.Dni);
                Console.WriteLine("\t FECHA DE NACIMIENTO: " + c.Fechanacimiento);
                Console.WriteLine("\t NACIONALIDAD: " + c.Nacionalidad);

            }
        }

        
    }
}
