﻿using System;
namespace Ejercicio
{
    public class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                Metodos.GenerarDatosDePrueba();
                int opcion;

                do
                {
                    Metodos.MostrarMenu();
                    opcion = Metodos.PedirOpcion();
                    Metodos.ProcesarOpcion(opcion);
                } while (!Metodos.ElUsuarioQuiereSalir(opcion));

            }
            catch (TiposException te)
            {
                Console.WriteLine("\t " +te.Message);
            }
            catch (FormatException)
            {
                Console.WriteLine("\t El formato introducido no es válido");
            
            }
        }

        
    }
}
