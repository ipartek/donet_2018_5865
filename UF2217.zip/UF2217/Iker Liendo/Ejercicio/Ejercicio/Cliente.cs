﻿using System;
using System.Text.RegularExpressions;

namespace Ejercicio
{
    public class Cliente
    {
        public Cliente(int id, string nombre, string apellidos, string email, string password, string dni, string fechanacimiento, string nacionalidad)
        {
            Id = id;
            Nombre = nombre ?? throw new ArgumentNullException(nameof(nombre));
            Apellidos = apellidos ?? throw new ArgumentNullException(nameof(apellidos));
            Email = email ?? throw new ArgumentNullException(nameof(email));
            Password = password ?? throw new ArgumentNullException(nameof(password));
            Dni = dni ?? throw new ArgumentNullException(nameof(dni));
            Fechanacimiento = fechanacimiento ?? throw new ArgumentNullException(nameof(fechanacimiento));
            Nacionalidad = nacionalidad ?? throw new ArgumentNullException(nameof(nacionalidad));
        }

        public int Id { get; set; }

        private string nombre;
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {

                if (value == null)
                {
                    throw new TiposException("Rellene el Nombre por favor");
                }
                if (!(value.Length > 2))
                {
                    throw new TiposException("Ha de tener mas de 2 letras");
                }

                if (!Regex.IsMatch(value, @"^\D{3,}$"))
                {
                    throw new TiposException("Debe tener minimo 3 letras");
                }
               

                nombre = value;
            }
        }

        private string apellidos;
        public string Apellidos
        {
            get
            {
                return apellidos;
            }
            set
            {
                if (value == null)
                {
                    throw new TiposException("Rellene el Apellido por favor");
                }
                if (!Regex.IsMatch(value, @"^\D{5,} \D{5,}$"))
                {
                    throw new TiposException("Debe tener minimo 5 letras y un espacio");
                }
                apellidos = value;
            }

        }

        private string email;
        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten emails nulos");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el email");
                }

                if (!Regex.IsMatch(value.Trim(), @"^\w+@\w+\.\w+$"))
                {
                    throw new TiposException("El email introducido no es válido");
                }

                email = value.Trim();
            }
        }

        public string Password { get; set; }
        
        public string Dni { get; set; }

        private string fechanacimiento;
        public string Fechanacimiento
        {
            get
            {
                return fechanacimiento;
            }

            set
            {
                
                DateTime Fechanac = Convert.ToDateTime(value);
                DateTime fecha = DateTime.Now.AddYears(-18);
                int result = DateTime.Compare(Fechanac, fecha);
                if (result > 0)
                {
                    throw new TiposException("Debes de ser mayor de edad");
                }
                fechanacimiento = value;
            }
        }
        private string nacionalidad;
        public string Nacionalidad
        {
            get
            {
                return nacionalidad;
            }
            set
            {
                if (value != "Español" && value != "Extranjero")
                {
                    throw new TiposException("Debe introducir Español o Extranjero");
                }
                nacionalidad = value;
            }

        }

        public Cliente() { }

        public override string ToString() => $"{Id},{Nombre},{Apellidos},{Email},{Password},{Dni},{Fechanacimiento},{Nacionalidad}";
    }
}
