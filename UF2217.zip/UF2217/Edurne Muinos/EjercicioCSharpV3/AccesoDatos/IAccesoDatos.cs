﻿using System;
using System.Collections.Generic;


namespace AccesoDatos
{
    interface IAccesoDatos<T>
    {
        List<T> Lista { get; set; }

        //metodos
        void Add(T t);
        void Eliminar(T t);
        void Modificar(T t);
    }
}
