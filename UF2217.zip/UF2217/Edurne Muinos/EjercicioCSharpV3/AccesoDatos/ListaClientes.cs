﻿using AccesoDatos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tipos;

namespace AccesoDatos
{
    public class ListaClientes: IAccesoDatos<Cliente>
    {
        private List<Cliente> lista;

        public List<Cliente> Lista
        {
            get { return lista; }
            set { lista = value; }
        }
        //Metodos Constructores
        public ListaClientes()
        {
            lista = new List<Cliente>();
        }

        //Metodos de Clase
        public void Add(Cliente cliente)
        {
            lista.Add(cliente);
        }
        public void Eliminar(Cliente cliente)
        {
            int i = 0;
            foreach (Cliente c in lista)
            {
                if (cliente.Id == c.Id)
                {
                    lista.RemoveAt(i);
                    break;
                }
                i = i + 1;
            }
        }
        public void Modificar(Cliente cliente)
        {
            DateTime fechaAyuda = new DateTime();

            foreach (Cliente c in lista)
            {
                if (c.Id == cliente.Id)
                {
                    if (cliente.Nombre != "")
                    {
                        c.Nombre = cliente.Nombre;
                    }
                    if (cliente.Apellido1 != "")
                    {
                        c.Apellido1 = cliente.Apellido1;
                    }
                    if (cliente.Apellido2 != "")
                    {
                        c.Apellido2 = cliente.Apellido2;
                    }
                    if (cliente.Email != "")
                    {
                        c.Email = cliente.Email;
                    }
                    if (cliente.Password != "")
                    {
                        c.Password = cliente.Password;
                    }
                    if (cliente.Dni.Numero != 0)
                    {
                        c.Dni = cliente.Dni;
                    }
                    if (cliente.FechaNacimineto.Year != fechaAyuda.Year && cliente.FechaNacimineto.Month != fechaAyuda.Month &&
                        cliente.FechaNacimineto.Day != fechaAyuda.Day)
                    {
                        c.FechaNacimineto = cliente.FechaNacimineto;
                    }
                    c.Nacionalidad = cliente.Nacionalidad;
                }
            }
        }


        //metodos
        public void Borrar(string nombre)
        {
            int i = 0;
            foreach(Cliente cliente in lista)
            {
                if(cliente.Nombre == nombre)
                {
                    lista.RemoveAt(i);
                    break;
                }
                i = i + 1;
            }
        }
        public void Borrar(int id)
        {
            int i = 0;
            foreach (Cliente cliente in lista)
            {
                if (cliente.Id == id)
                {
                    lista.RemoveAt(i);
                    break;
                }
                i = i + 1;
            }
        }
        public Cliente GetById(int id)
        {
            string sId = id.ToString();
            foreach(Cliente cliente in lista)
            {
                if(cliente["id"] == sId)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByNombre(string nombre)
        {
            foreach(Cliente cliente in lista)
            {
                if(cliente["nombre"] == nombre)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByEmail(string email)
        {
            foreach (Cliente cliente in lista)
            {
                if (cliente["email"] == email)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByApellido1(string ape1)
        {
            foreach (Cliente cliente in lista)
            {
                if (cliente["apellido1"] == ape1)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByApellido2(string ape2)
        {
            foreach (Cliente cliente in lista)
            {
                if (cliente["apellido2"] == ape2)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByDni(string dni)
        {
            foreach (Cliente cliente in lista)
            {
                if (cliente["dni"] == dni)
                {
                    return cliente;
                }
            }
            return null;
        }
        public Cliente GetByFechaNacimiento(string fecha)
        {
            foreach (Cliente cliente in lista)
            {
                if (cliente["fechaNacimineto"] == fecha)
                {
                    return cliente;
                }
            }
            return null;
        }

        //Devuelve true si existe el cliente, metodos static
        public static bool ExisteCliente(int idCliente, List<Cliente> list)
        {
            foreach (Cliente cliente in list)
            {
                if (cliente.Id == idCliente)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ExisteCliente(string nombreCliente, List<Cliente> list)
        {
            foreach (Cliente cliente in list)
            {
                if (cliente["nombre"] == nombreCliente)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ExisteClienteByApelliido1(string apellido1, List<Cliente> list)
        {
            foreach (Cliente cliente in list)
            {
                if (cliente["apellido1"] == apellido1)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ExisteClienteByApellido2(string apellido2, List<Cliente> list)
        {
            foreach (Cliente cliente in list)
            {
                if (cliente["apellido2"] == apellido2)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ExisteClienteByEmail(string email, List<Cliente> list)
        {
            foreach (Cliente cliente in list)
            {
                if (cliente["email"] == email)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ExisteClienteByDni(string dni, List<Cliente> list)
        {
            
            if (dni == "")
            {
                throw new TiposException("El dni no puede ser vacio");
            }
            foreach (Cliente cliente in list)
            {
                if (cliente["dni"] == dni)
                {
                    return true;
                }
            }
            return false;
        }

        public override string ToString()
        {
            string formato = "";
            foreach(Cliente cliente in lista)
            {
                formato = formato + cliente.ToString() + "\n";
            }
            return formato;
        }

    }
}
