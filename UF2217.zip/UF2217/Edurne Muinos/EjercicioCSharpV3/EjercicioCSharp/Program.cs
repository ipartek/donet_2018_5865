﻿using AccesoDatos;
using System;
using Tipos;

namespace EjercicioCSharp
{
    public enum Menu
    {
        Alta,
        Modificacion,
        Baja,
        VerListado,
        BuscarPorId,
        BuscarPorNombre,
        Buscar,
        Salir
    }
    public enum OpcionesCampo
    {
        id,
        nombre,
        apellido1,
        apellido2,
        email,
        dni,
        salir
    }
    
        
    
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                //id global para hacer las altas
                int idGlobal = 4;
                bool repetir = true;
                ListaClientes listaCli = new ListaClientes();
                //Llenar lista de clientes
                DateTime fecha = new DateTime(1999, 05, 23);
                Cliente cl1 = new Cliente(1, "Pepe", "pepe@email.com", "sdfasf", "12345678Z", fecha,
                    Cliente.TipoCliente.Espaniol, "apellido1", "apellido2");
                Cliente cl2 = new Cliente(2, "Raul", "gusana@email.com", "egegergeg", "45815697L", new DateTime(1998, 07, 12),
                    Cliente.TipoCliente.Espaniol, "Gonzalez", "perezz");
                Cliente cl3 = new Cliente(3, "Maria", "mari@email.com", "kjkjisdf", "Y2345678Z", new DateTime(2000, 12, 22),
                    Cliente.TipoCliente.Extranjero, "apellido1", "apellido2");
                listaCli.Add(cl1);
                listaCli.Add(cl2);
                listaCli.Add(cl3);


                while (repetir)
                {


                    //Mostrar Menu
                    MostrarMenu();
                    //Elegir una opcion valida
                    string valorPantalla;
                    int x;
                    bool esNum;
                    do
                    {
                        Console.WriteLine("Elige una opcion del 0 al 7: ");
                        valorPantalla = Console.ReadLine();
                        esNum = int.TryParse(valorPantalla, out x);
                        if (!esNum  || x > 7)
                        {
                            Console.WriteLine("No existe esa opcion o no es un numero.");
                        }
                    } while (!esNum || x > 7);
                    x = int.Parse(valorPantalla);

                    switch (x)
                    {
                        case 0:
                            CrearCliente(listaCli, ref idGlobal);
                            VerListado(listaCli);
                            break;
                        case 1:
                            VerListado(listaCli);
                            ModificarCliente(listaCli);
                            break;
                        case 2:
                            VerListado(listaCli);
                            DarBaja(listaCli);
                            Console.WriteLine("EL CLIENTE SE HA ELIMINADO CORRECTAMENTE");
                            VerListado(listaCli);
                            break;
                        case 3:
                            VerListado(listaCli);
                            break;
                        case 4:
                            BuscarPorId(listaCli);
                            break;
                        case 5:
                            BuscarPorNombre(listaCli);
                            break;
                        case 6:
                            BuscarPorCualquierCampo(listaCli);
                            break;
                        case 7:
                            repetir = false;
                            break;
                        default:
                            Console.WriteLine("no es una opcion valida");
                            break;
                    }


                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                Console.ReadKey();
            }
        }

        

        private static void CrearCliente(ListaClientes listaCli,ref int idGlobal)
        {
            Cliente cliente;
            cliente = new Cliente();

            //Id
            cliente.Id = idGlobal;

            //Nombre
            PedirNombre("El nombre del Cliente", cliente);

            //El primer Apellldio
            PedirApellido1("El primer apellido del cliente", cliente);

            //El segundo apellido
            PedirApellido2("El segundo apellido del cliente", cliente);

            //Email
            PedirEmail("El Email del cliente", cliente);

            //Contraseña
            PedirPassword("La contraseña del cliente", cliente);

            //fecha nacimeinto
            PedirFechaNacimineto("La fecha de nacimiento del cliente", cliente);

            //Nacionalidad
            PedirNacionalidad("Nacionalidad del cliente: Español o extranjero", cliente);

            //DNI
            PedirDni("El dni del cliente", cliente);

            //Comprueba si el tipo de dni coincide con la nacionalidad.
            // cliente.EsCorrectoNacionalidad();
            if (cliente.Nacionalidad == Cliente.TipoCliente.Extranjero)
            {
                if (!cliente.Dni.EsDniExtranjero())
                {
                    throw new TiposException("No puedes ser Extranjero y tener un Dni Español.");
                }
            }//Si eres español no puedes tener dni extranjero
            else
            {
                if (cliente.Dni.EsDniExtranjero())
                {
                    throw new TiposException("No puedes ser Español y tener un Dni Extranjero.");

                }

            }

            listaCli.Add(cliente);
            idGlobal = idGlobal + 1;
        }

        private static void PedirNombre(string mensaje, Cliente cliente)
        {
            bool repetir;
            string nombre;
            do
            {
                repetir = false;
                try
                {
                    Console.WriteLine(mensaje);
                    nombre = Console.ReadLine();
                    cliente.Nombre = nombre;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirApellido1(string mensaje, Cliente cliente)
        {
            bool repetir;
            string ape1;
            do
            {
                repetir = false;
                try
                {

                    Console.WriteLine(mensaje);
                    ape1 = Console.ReadLine();
                    cliente.Apellido1 = ape1;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirApellido2(string mensaje,Cliente cliente)
        {
            bool repetir;
            string ape2;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje);
                    ape2 = Console.ReadLine();
                    cliente.Apellido2 = ape2;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirEmail(string mensaje, Cliente cliente)
        {
            bool repetir;
            string email;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje);
                    email = Console.ReadLine();
                    cliente.Email = email;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirPassword(string mensaje, Cliente cliente)
        {
            bool repetir;
            string psw;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje,cliente);
                    psw = Console.ReadLine();
                    cliente.Password = psw;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirFechaNacimineto(string mensaje, Cliente cliente)
        {
            bool repetir;
            DateTime fechaNacimiento = new DateTime();
            string fNacimineto;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje);
                    fNacimineto = Console.ReadLine();
                    fechaNacimiento = DateTime.Parse(fNacimineto);
                    cliente.FechaNacimineto = fechaNacimiento;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirNacionalidad(string mensaje, Cliente cliente)
        {
            bool repetir;
            Cliente.TipoCliente nacionalidad;
            string n;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje);
                    n = Console.ReadLine();
                    if (n.Equals("Extranjero", StringComparison.InvariantCultureIgnoreCase))
                    {
                        nacionalidad = Cliente.TipoCliente.Extranjero;
                    }
                    else
                    {
                        nacionalidad = Cliente.TipoCliente.Espaniol;
                    }
                    cliente.Nacionalidad = nacionalidad;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private static void PedirDni(string mensaje, Cliente cliente)
        {
            bool repetir;
            string dni;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensaje);
                    dni = Console.ReadLine();
                    cliente.Dni = new Dni(dni);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }

        private static void ModificarCliente(ListaClientes listaCli)
        {
            string nombre, ape1, ape2, email, psw, fnAyuda, tipoAyuda, dniAyuda, valor;
            Cliente.TipoCliente nacionalidad;
            int x, idCliente;
            Dni dni;
            DateTime fechaNacimiento = new DateTime();
            bool repetir,esNum;
            Cliente cliente =  new Cliente();
            idCliente = 0;

            //Lograr el cliente
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Introduce el id del cliente que quieres modificcar");
                    valor = Console.ReadLine();
                    esNum = int.TryParse(valor, out x);
                    if (!esNum)
                    {
                        Console.WriteLine("No es un numero.");
                    }
                    idCliente = int.Parse(valor);
                    //Utilizar para cliente vacio y despues al final utilizar modificar que aparece en ListaClientes.
                    //cliente = listaCli.GetById(idCliente);
                    cliente.Id = idCliente;
                    if (cliente == null)
                    {
                        Console.WriteLine("No existe cliente con ese id");
                        repetir = true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Nombre
            do
           {
                try
                {
                    repetir = false;
                    Console.WriteLine("Nombre del Cliente ");
                    nombre = Console.ReadLine();
                    if(nombre == "")
                    {
                        break;
                    }
                    cliente.Nombre = nombre;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Primer apellido
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("El primer apellido del cliente");
                    ape1 = Console.ReadLine();
                    if (ape1 == "")
                    {
                        break;
                    }
                    cliente.Apellido1 = ape1;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Segundo apellido
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("El segundo apellido del cliente");
                    ape2 = Console.ReadLine();
                    if (ape2 == "")
                    {
                        break;
                    }
                    cliente.Apellido2 = ape2;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Email
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("El email");
                    email = Console.ReadLine();
                    if (email == "")
                    {
                        break;
                    }
                    cliente.Email = email;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Contraseña
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("La contraseña");
                    psw = Console.ReadLine();
                    if (psw == "")
                    {
                        break;
                    }
                    cliente.Password = psw;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Fecha Nacimiento
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Introduce la fecha de nacimiento dd/mm/aaaa");
                    fnAyuda = Console.ReadLine();
                    if (fnAyuda == "")
                    {
                        break;
                    }
                    fechaNacimiento = DateTime.Parse(fnAyuda);
                    //listaCli.GetById(idCliente).FechaNacimineto = fechaNacimiento;
                    cliente.FechaNacimineto = fechaNacimiento;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //DNI
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("El dni del Cliente");
                    dniAyuda = Console.ReadLine();
                    if (dniAyuda == "")
                    {
                        break;
                    }
                    dni = new Dni(dniAyuda);
                    //listaCli.GetById(idCliente).Dni = dni;
                    cliente.Dni = dni;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            //Nacionalidad
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el tipo del cliente: Español o Extranjero");
                    tipoAyuda = Console.ReadLine();
                    if (tipoAyuda == "")
                    {
                        break;
                    }
                    if (tipoAyuda.Equals("Español", StringComparison.InvariantCultureIgnoreCase))
                    {
                        nacionalidad = Cliente.TipoCliente.Espaniol;
                    }
                    else
                    {
                        nacionalidad = Cliente.TipoCliente.Extranjero;
                    }
                    //listaCli.GetById(idCliente).Nacionalidad = nacionalidad;
                    cliente.Nacionalidad = nacionalidad;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);

            listaCli.Modificar(cliente);
            if (listaCli.GetById(idCliente).Nacionalidad == Cliente.TipoCliente.Extranjero)
            {
                if (!listaCli.GetById(idCliente).Dni.EsDniExtranjero())
                {
                    throw new TiposException("No puedes ser Extranjero y tener un Dni Español.");
                }
            }//Si eres español no puedes tener dni extranjero
            else
            {
                if (listaCli.GetById(idCliente).Dni.EsDniExtranjero())
                {
                    throw new TiposException("No puedes ser Español y tener un Dni Extranjero.");

                }

            }
        }

        private static void BuscarPorNombre(ListaClientes listaCli)
        {
            string nombrePantalla ="";
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el nombre del Cliente que quieres buscar: ");
                    nombrePantalla = Console.ReadLine();
                    if (!AccesoDatos.ListaClientes.ExisteCliente(nombrePantalla,listaCli.Lista))
                    {
                        Console.WriteLine("No existe cliente con el nombre ");
                        repetir = true;
                    }
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(listaCli.GetByNombre(nombrePantalla).ToString());
        }
        private static void BuscarPorId(ListaClientes listaCli)
        {

            string valor;
            bool esId, repetir;
            int id = 0;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige id del Cliente que quieres buscar: ");
                    valor = Console.ReadLine();
                    esId = int.TryParse(valor, out id);
                    if (!esId)
                    {
                        Console.WriteLine("No es un numero.");
                    }
                    id = int.Parse(valor);

                    if (!AccesoDatos.ListaClientes.ExisteCliente(id,listaCli.Lista))
                    {
                        Console.WriteLine("No existe cliente con el id ");
                        repetir = true;
                    }
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(listaCli.GetById(id).ToString());
        }
        private static void BuscarPorDni(ListaClientes lista)
        {
            string nombrePantalla = "";
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el dni del Cliente que quieres buscar: ");
                    nombrePantalla = Console.ReadLine();
                    if (!AccesoDatos.ListaClientes.ExisteClienteByDni(nombrePantalla,lista.Lista))
                    {
                        Console.WriteLine("No existe el cliente");
                        repetir = true;
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(lista.GetByDni(nombrePantalla).ToString());
        }
        private static void BuscarPorEmail(ListaClientes lista)
        {
            string nombrePantalla = "";
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el email del Cliente que quieres buscar: ");
                    nombrePantalla = Console.ReadLine();
                    if (!AccesoDatos.ListaClientes.ExisteClienteByEmail(nombrePantalla,lista.Lista))
                    {
                        Console.WriteLine("No existe el cliente");
                        repetir = true;
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(lista.GetByEmail(nombrePantalla).ToString());
        }
        private static void BuscarPorApellido2(ListaClientes lista)
        {
            string nombrePantalla = "";
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el segundo apellido del Cliente que quieres buscar: ");
                    nombrePantalla = Console.ReadLine();
                    if (!AccesoDatos.ListaClientes.ExisteClienteByApellido2(nombrePantalla,lista.Lista))
                    {
                        Console.WriteLine("No existe el cliente");
                        repetir = true;
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(lista.GetByApellido2(nombrePantalla).ToString());
        }
        private static void BuscarPorApellido1(ListaClientes lista)
        {
            string nombrePantalla = "";
            bool repetir;

            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige el primer apellido del Cliente que quieres buscar: ");
                    nombrePantalla = Console.ReadLine();
                    if (!AccesoDatos.ListaClientes.ExisteClienteByApelliido1(nombrePantalla,lista.Lista))
                    {
                        Console.WriteLine("No existe el cliente");
                        repetir = true;
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Console.WriteLine(lista.GetByApellido1(nombrePantalla).ToString());
        }

        private static void VerListado(ListaClientes lista)
        {
            Console.WriteLine("____Listado____");
            Console.WriteLine(lista.ToString());
            Console.WriteLine("_______________");
        }

        private static void DarBaja(ListaClientes lista)
        {
            string valor;
            bool esNum, repetir;
            int id = 0;
            
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine("Elige id del Cliente que quieres eliminar: ");
                    valor = Console.ReadLine();
                    esNum = int.TryParse(valor, out id);
                    if (!esNum)
                    {
                        Console.WriteLine("No es un numero.");
                        repetir = true;
                    }
                    id = int.Parse(valor);
                    
                    if (!AccesoDatos.ListaClientes.ExisteCliente(id,lista.Lista))
                    {
                        Console.WriteLine("No existe cliente con ese id");
                        repetir = true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
            Cliente cliente = new Cliente();
            cliente = lista.GetById(id);
            // lista.Borrar(id);
            lista.Eliminar(cliente);
        }

        private static void MostrarMenu()
        {
            //TODO: hacer un forech del enum para sacar el menu.
            Console.WriteLine("-----MENU-----");

            Console.WriteLine("0 " + Menu.Alta);
            Console.WriteLine("1 " + Menu.Modificacion);
            Console.WriteLine("2 " + Menu.Baja);
            Console.WriteLine("3 " + Menu.VerListado);
            Console.WriteLine("4 " + Menu.BuscarPorId);
            Console.WriteLine("5 " + Menu.BuscarPorNombre);
            Console.WriteLine("6 " + Menu.Buscar);
            Console.WriteLine("7 " + Menu.Salir);
        }

        private static void BuscarPorCualquierCampo(ListaClientes lista)
        {
            bool repetir = true;
            while (repetir)
            {

            
                int campo;
                campo = ElegirCampo();
 
                switch (campo)
                {
                    case 0:
                        BuscarPorId(lista);
                        break;
                    case 1:
                        BuscarPorNombre(lista);
                        break;
                    case 2:
                        //VerListado(lista);
                        BuscarPorApellido1(lista);
                        break;
                    case 3:
                        //VerListado(lista);
                        BuscarPorApellido2(lista);
                        break;
                    case 4:
                       // VerListado(lista);
                        BuscarPorEmail(lista);
                        break;
                    case 5:
                       // VerListado(lista);
                        BuscarPorDni(lista);
                        Console.WriteLine("dni");
                        break;
                    case 6:
                        repetir = false;
                        break;
                    default:
                        break;
                }
            }
        }

        private static int ElegirCampo()
        {
            string campo;
            MostrarOpciones();

            
            int x;
            bool esNum;
            do
            {
                Console.WriteLine("---------------------------------------------------------------------");
                Console.WriteLine("Elige el campo por el que quieres realizar la busqueda (del 0 al 6) ");
                campo = Console.ReadLine();
                esNum = int.TryParse(campo, out x);
                if (!esNum || x > 6)
                {
                    Console.WriteLine("No existe esa opcion o no es un numero.");
                }
            } while (!esNum || x > 6);

            return x;
        }

        private static void MostrarOpciones()
        {
            
            Console.WriteLine("0 " + OpcionesCampo.id);
            Console.WriteLine("1 " + OpcionesCampo.nombre);
            Console.WriteLine("2 " + OpcionesCampo.apellido1);
            Console.WriteLine("3 " + OpcionesCampo.apellido2);
            Console.WriteLine("4 " + OpcionesCampo.email);
            Console.WriteLine("5 " + OpcionesCampo.dni);
            Console.WriteLine("6 " + OpcionesCampo.salir);

        }
    }
}
