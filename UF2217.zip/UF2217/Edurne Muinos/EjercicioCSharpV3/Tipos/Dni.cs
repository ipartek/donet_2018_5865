﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Tipos
{
    public class Dni
    {
        //Letras para calculo de la letra
        private const string LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE";

        //Propiedades
        public char? LetraExtranjero { get; set; }
        public int Numero { get; set; }
        public char Letra { get; set; }

        

        //Metodos de creacion
        public Dni(string dni)
        {
            if(dni == null)
            {
                //Console.WriteLine("Tienes que introducir un DNI valido.");
                throw new TiposException("Tienes que introducir un DNI valido");
            }
            if (!Regex.IsMatch(dni, @"^[XYZ\d]\d{7}[" + LETRAS + "]$"))
            {
                // Console.WriteLine("No es un Dni valido.");
                throw new TiposException("No es un DNI valido");
            }
            if (!EsValido(dni))
            {
                throw new TiposException("La letra del dni no concuerda con el numero");
            }
            //Comprueba si es un dni extranjero, si es saca el numero y las dos letras.
            if(Regex.IsMatch(dni, @"^[XYZ4]\d{7}[" + LETRAS + "]$"))
            {
                Numero = int.Parse(ExtraerNumeroExtranjero(dni));
                Letra = ExtraerLetra(dni);
                LetraExtranjero = ExtraerLetraExtranjero(dni);
            }
            //Si no pone la letra extranjero a null.
            else
            {
                LetraExtranjero = null;
                Numero = int.Parse(ExtraerNumero(dni));
                Letra = ExtraerLetra(dni);
            }
        }
        public Dni()
        {
            LetraExtranjero = null;
            Numero = 0;
            Letra = 'A';
        }

        private char? ExtraerLetraExtranjero(string dni)
        {
            string letra;
            letra = dni.Substring(0, 1);
            return letra[0];
        }

        private string ExtraerNumeroExtranjero(string dni)
        {
            return dni.Substring(1, dni.Length - 2); ;
        }

        //metodos internos
        private static char CalcularLetra(int numero)
        {
            return LETRAS[numero % 23];
        }

        //Metodos de clase
        //Si LetraExtranjero no es null devuelve true su es null devuelve false.
        public bool EsDniExtranjero()
        {
            return LetraExtranjero != null;
        }
        public static bool EsValido(string dni)
        {
            string sNumero = ExtraerNumero(dni);

            char letra = dni[8];

            sNumero = sNumero.Replace('X', '0').Replace('Y', '1').Replace('Z', '2');

            return letra == CalcularLetra(int.Parse(sNumero));
        }
        private static string ExtraerNumero(string dni)
        {
                return dni.Substring(0, dni.Length - 1);
        }
        private static char ExtraerLetra(string dni)
        {
            string letra;
            letra = dni.Substring(dni.Length - 1, 1);
            return letra[0];
        }
        public override string ToString()
        {
            if(LetraExtranjero == null)
            {
                return string.Format("{0}{1}", Numero.ToString(), Letra);
            }
            else
            {
                return string.Format("{0}{1}{2}",LetraExtranjero, Numero.ToString(), Letra);
            }
        }
    }
}
