﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Tipos
{
    
    public class Cliente
    {
        public enum TipoCliente
        {
            Espaniol,
            Extranjero
        }
        //variables de instancia
        private int id;
        private string nombre;
        private string apellido1;
        private string apellido2;
        private string email;
        private string password;
        private Dni dni;
        private DateTime fechaNacimineto;
        private TipoCliente nacionalidad;
        
        //Propiedades
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set
            {
                
                if (value.Length < 2)
                {
                    throw new TiposException("Error, el nombre tiene que tener dos caracteres como minimo.");
                }
                else
                {
                    nombre = value;
                }
            }
        }
        public string Apellido1
        {
            get { return apellido1; }
            set
            {
                if(value.Length < 5)
                {
                    throw new TiposException("Error, el primer apellido tiene que tener como minimo cinco caracteres");
                }
                else
                {
                    apellido1 = value;
                }
            }
        }
        public string Apellido2
        {
            get { return apellido2; }
            set
            {
                if (value.Length < 5)
                {
                    throw new TiposException("Error, el segundo apellido tienen que tener como minimo cinco caracteres");
                }
                else
                {
                    apellido2 = value;
                }
            }
        }
        public string Email
        {
            get { return email; }
            set
            {
                //despues de la arroba tiene que haber un punto y dominio de 2 o tres caracteres.
                string expresion = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
                if (!Regex.IsMatch(value, expresion))
                {
                    throw new TiposException("El email introducido no es valido");
                }
                else
                {
                    email = value;
                }
            }
        }
        public string Password
        {
            get { return password; }
            set
            {
                if(value.Trim().Length == 0)
                {
                    throw new TiposException("Es obligatorio de rellenar la Contraseña");
                }
                password = value;
            }
        }
        public Dni Dni
        {
            get { return dni; }
            set { dni = value; }
        }
        public DateTime FechaNacimineto
        {
            get { return fechaNacimineto; }
            set
            {
                DateTime hoy = DateTime.Now;
                DateTime cumpleMayoriaEdad = new DateTime(value.Year + 18, value.Month, value.Day);
                if(hoy <= cumpleMayoriaEdad)
                {
                    throw new TiposException("El cliente tiene que ser mayor de 18 años.");
                }
                else
                {
                    fechaNacimineto = value;
                }
            }
        }
        
        public TipoCliente Nacionalidad { get; set; }

        //Metodos de Creacion
        public Cliente(int nid, string nom, string em, string psw, string ndni, DateTime fNacimineto, TipoCliente tCliente, string ape1 = null, string ape2 = null)
        {
            if(ape1 == null)
            {
                apellido1 = "";

            }
            else
            {
                apellido1 = ape1;
            }
            if(ape2 == null)
            {
                apellido2 = "";
            }
            else
            {
                apellido2 = ape2;
            }
            id = nid;
            nombre = nom;
            email = em;
            password = psw;
            dni = new Dni(ndni);
            fechaNacimineto = fNacimineto;
            nacionalidad = tCliente;
        }
        public Cliente()
        {
            id = 0;
            nombre = "";
            apellido1 = "";
            apellido2 = "";
            email = "";
            password = "";
            dni = new Dni();
            fechaNacimineto = new DateTime();
            nacionalidad = TipoCliente.Espaniol;
        }

        //Metodos de clase
        public bool EsCorrectoNacionalidad()
        {
            if ( nacionalidad == Cliente.TipoCliente.Extranjero)
            {
                if (dni.LetraExtranjero == null)
                {
                    throw new TiposException("No puede tener la nacionalidad extranjera y tener un DNI.");
                }
            }//si es español no puede tener un dni extranjero
            else
            {
                if (dni.LetraExtranjero != null)
                {
                    throw new TiposException("No puede ser español y tener un DNI extranjero.");
                }
            }
            return true;
        }

        //Indexador
        public string this[string campo]
        {
            get
            {
                switch (campo)
                {
                    case "id":
                        return id.ToString();
                    case "nombre":
                        return nombre;
                    case "apellido1":
                        return apellido1;
                    case "apellido2":
                        return apellido2;
                    case "email":
                        return email;
                    case "password":
                        return password;
                    case "dni":
                        return dni.ToString();
                    case "fechaNacimineto":
                        return fechaNacimineto.ToString();
                    case "nacionalidad":
                        return nacionalidad.ToString();
                    default:
                        return "";
                }
            }
            set
            {
                switch (campo)
                {
                    case "id":
                        id = int.Parse(value);
                        break;
                    case "nombre":
                        nombre = value;
                        break;
                    case "apellido1":
                        apellido1 = value;
                        break;
                    case "apellido2":
                        apellido2 = value;
                        break;
                    case "email":
                        email = value;
                        break;
                    case "password":
                        password = value;
                        break;
                    case "dni":
                        dni = new Dni(value);
                        break;
                    case "fechaNacimineto":
                        fechaNacimineto = DateTime.Parse(value);
                        break;
                    case "nacionalidad":
                        string ayuda = value;
                        if (ayuda.Equals("Extranjero", StringComparison.InvariantCultureIgnoreCase))
                        {
                            nacionalidad = TipoCliente.Extranjero;
                        }
                        else
                        {
                            nacionalidad = TipoCliente.Espaniol;
                        }
                        break;
                    default:
                        break;
                }

            }
        }
        

        //Metodos override
        public override string ToString()
        {
            return string.Format("Id: {0}\nNombre: {1}\nApellido1: {2}\nApellido2: {3}\nEmail: {4}\nPass: {5}\nDni: {6}\n" +
                "Fecha Nacimineto: {7}\nNacionalidad: {8}", Id, Nombre, Apellido1, Apellido2, Email, Password, Dni.ToString(),
                FechaNacimineto, Nacionalidad);
        }
    }
}
