﻿namespace Tipos
{
    internal class OcultoParaBusquedasAttribute
    {
    }
}