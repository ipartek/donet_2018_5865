﻿using System;
using System.Text.RegularExpressions;
using static System.Console;

namespace Tipos
{
    public class Cliente
    {
        public string nombre, apellidos, email, password;

        public Dni dni;

        public DateTime date;

        public int idCliente { get; set; }
        
        public string Nombre { get { return nombre; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten nombres nulos");
                }

                if (value.Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el nombre");
                }

                if (!Regex.IsMatch(value, @"^[a-zA-Z]{2,}$"))
                {
                    throw new TiposException("El nombre introducido no es válido");
                }

                nombre = value;
            }
        }


        public string Apellidos { get { return apellidos; }
            set {
                if (value == null)
                {
                    throw new TiposException("No se admiten apellidos nulos");
                }

                if (value.Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el apellido");
                }

                if (!Regex.IsMatch(value, @"^[a-zA-Z]{5,45}\s[a-zA-Z]{0,45}$"))
                {
                    throw new TiposException("El apellido minimo 5 letras y un espacio");
                }

                apellidos = value;
            }
        }

        public string Email
        {
            get { return email; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten emails nulos");
                }

                if (value.Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el email");
                }

                if (!Regex.IsMatch(value, @"^[^@]+@[^@]+\.[a-zA-Z]{2,}$"))
                {
                    {
                        throw new TiposException("El email debe de contener @ . y dos letras");
                    }
                }

                    email = value;
            }
        }

        public string Password
        {
            get { return password; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten contraseñas nulas");
                }

                if (value.Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar la contraseña");
                }

                password = value;
            }
        }

        public Dni Dni { get; set; }
        
        public DateTime Fecha_Nacimiento
        {
            get { return date; }
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten fechas nulas");
                }

                if (value.AddYears(18) > DateTime.Today)
                {
                    throw new TiposException("Debes de tener al menos 18 años");
                }

                    date = value;
            }
        }

        public string Nacionalidad => Dni.Nacionalidad();

        public Cliente()
        {

        }
    }
}