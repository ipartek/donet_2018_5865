﻿using System;
using System.Text.RegularExpressions;
using Tipos;
using static System.Console;

namespace Ejercicio1
{
    class Program
    {
        static int codCliente = 0;
        static Grupo<Cliente> g = new Grupo<Cliente>("mis Listas");
        static Cliente micliente = null;

        static void Main()
        {
            var x = false;
            do
            {
                char opcion;
                
                WriteLine("\t    Menu   Clientes             ");
                WriteLine("\t************************");
                WriteLine("\t*  1- Dar de Alta a un Cliente: ");
                WriteLine("\t*  2- Modificar Datos Cliente:  ");
                WriteLine("\t*  3- Dar de baja a un Cliente: ");
                WriteLine("\t*  4- Ver Listado de Clientes	 ");
                WriteLine("\t*  5- Buscar Cliente por su Id  ");
                WriteLine("\t*  6- Buscar Cliente por su Nombre  ");
                WriteLine("\t************************");
                WriteLine("\t*  [0]- Salir                ");
                WriteLine("\t************************");
                Write("Opcion: ");

                do
                {
                    opcion = Console.ReadKey(true).KeyChar;
                } while (opcion < '0');

                Console.WriteLine(opcion + "\n");

                switch (opcion)
                {
                    case '0':
                        x = false;
                        break;

                    case '1':

                        //Alta de un cliente
                        altaCliente(g);
                        x = true;
                        break;

                    case '2':

                        //Modificacion de datos de cliente
                        modificarCliente();
                        x = true;
                        break;

                    case '3':

                        // Dar de baja a un cliente //
                        eliminarCliente(g);
                        x = true;
                        break;

                    case '4':

                        // Ver Listado de clientes //
                        WriteLine("Listado  Clientes");
                        WriteLine("==================================");
                        WriteLine("Los datos de la tabla son: (id, Nombre, Apellidos, Email, Password, Dni, Fecha Nacimiento, Nacionalidad)");
                        WriteLine(" ");
                        foreach (Cliente c in g.Componentes)
                        {
                            ListadoClientes(c);
                        }

                        x = true;
                        break;

                    case '5':
                        // Buscar cliente por Id //
                        buscarPorId(g);
                        x = true;
                        break;

                    case '6':
                        // Buscar cliente por nombre //
                        buscarPorNombre(g);
                        x = true;
                        break;
                }
            } while (x == true);
        }

        private static void eliminarCliente(Grupo<Cliente> g)
        {
            WriteLine("Introduce Id a buscar para su eliminacion: ");
            int idBuscar = int.Parse(ReadLine());

            micliente = g.Find(c => c.idCliente == idBuscar);
            if (micliente != null)
            {
                mostrarCliente(micliente);
                g.Remove(micliente);
            }
            else { WriteLine("No encontrado"); }
        }

        private static void buscarPorNombre(Grupo<Cliente> g)
        {
            WriteLine("Introduce Nombre a buscar: ");
            string nombreBuscar = Console.ReadLine();
            micliente = g.Find(c => c.Nombre == nombreBuscar);
            if (micliente != null)
            {

                mostrarCliente(micliente);
            }
            else
            {
                WriteLine("No encontrado");
            }
        }

        private static void buscarPorId(Grupo<Cliente> g)
        {
            WriteLine("Introduce Id a buscar: ");
            int idEliminar;
            if (Int32.TryParse(Console.ReadLine(), out idEliminar))
            {
                micliente = g.Find(c => c.idCliente == idEliminar);
                if (micliente != null)
                {
                    mostrarCliente(micliente);

                }
                else
                {
                    WriteLine("No encontrado");
                }
            }
            else
            {
                WriteLine("Debes de introducir solamente un id numerico");
            }
        }

        private static Cliente modificarCliente()
        {
            if (micliente != null)
            {
                //muestro el cliente seleccionado
                mostrarCliente(micliente);

                insertarCliente(micliente, micliente.idCliente);
                // Modificamos los datos del cliente //
                micliente = null;
            }
            else
            {
                WriteLine("No as seleccionado ningun cliente");
            }

            return micliente;
        }

        private static void altaCliente(Grupo<Cliente> g)
        {
            Cliente cliente = new Cliente();

            if (insertarCliente(cliente, codCliente))
            {
                g.Add(cliente);
                codCliente++;
            }

            //return codCliente;
        }

        private static void ListadoClientes(Cliente c)
        {
            Write(c.idCliente + " | ");
            Write(c.Nombre + " | ");
            Write(c.Apellidos + " | ");
            Write(c.Email + " | ");
            Write(c.Password + " | ");
            Write(c.Dni + " | ");
            Write(c.Fecha_Nacimiento.ToString("dd/MM/yyyy") + " | ");
            Write(c.Nacionalidad + " ");

            WriteLine(" ");
        }

        private static void mostrarCliente(Cliente micliente)
        {
            Console.Clear();
            Write(micliente.idCliente + " | ");
            Write(micliente.Nombre + " | ");
            Write(micliente.Apellidos + " | ");
            Write(micliente.Email + " | ");
            Write(micliente.Password + " | ");
            Write(micliente.Dni + " | ");
            Write(micliente.Fecha_Nacimiento.ToString("dd/MM/yyyy") + " | ");
            Write(micliente.Nacionalidad);

            WriteLine(" ");
        }

        private static bool insertarCliente(Cliente cliente, int codCliente)
        {
            WriteLine("\t Dar de Alta a Clientes: ");
            WriteLine("\t************************");

            //Capturamos los datos del cliente

            bool validacion = false;

            cliente.idCliente = codCliente;

            do
            {
                try
                {
                    WriteLine("Dime tu nombre: ");
                    cliente.Nombre = ReadLine();

                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);
                    validacion = false;
                }

            } while (validacion == false);

            do
            {
                try
                {
                    WriteLine("Dime tus dos apellidos: ");
                    cliente.Apellidos = ReadLine();

                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);
                    validacion = false;

                }
            } while (validacion == false);

            do
            {
                try
                {
                    WriteLine("Dime tu correo Electronico: ");
                    cliente.Email = ReadLine();
                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);
                    validacion = false;
                }
            } while (validacion == false);


            do
            {
                try
                {
                    WriteLine("Dime tu contraseña: ");
                    cliente.Password = ReadLine();

                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);
                    validacion = false;
                }
            } while (validacion == false);


            do
            {
                try
                {
                    WriteLine("Dime tu Dni: ");
                    Dni midni = new Dni(ReadLine());
                    cliente.Dni = midni;

                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);

                    validacion = false;
                }

            } while (validacion == false);

            do
            {
                try
                {
                    WriteLine("Dime Fecha de Nacimiento: ");
                    cliente.Fecha_Nacimiento = DateTime.Parse(ReadLine());

                    validacion = true;
                }
                catch (Exception e)
                {
                    WriteLine(e.Message);
                    validacion = false;
                }
            } while (validacion == false);

            return true;
        }
    }
}
