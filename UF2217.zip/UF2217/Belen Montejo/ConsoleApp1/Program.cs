﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
         static void Main(string[] args)
        {
            Console.Title = "Agenda de contactos";
            bool bandera = true;
            string BANDERA1 = "s";
            string BANDERA2 = "s";
            int x,seleccion,n;
            List<Contacto> ListaContactos = new List<Contacto>();
            do
            {

                Console.WriteLine("Bienvenido al sistema de Agenda");
                Console.WriteLine("Seleccione una opción");
                Console.WriteLine("\n 1.Si desea escribir en la agenda  \n 2.Si desea mostrar todos los contactos \n 3.Si desea buscar un contacto \n 4.Si desea eliminar un contacto \n 5.Si desea modificar un contacto");
                Console.WriteLine(" 6.Para salir del programa pulse 6");
                seleccion = int.Parse(Console.ReadLine());
                switch (seleccion)
                {
                    case 1:
                        Contacto nContacto = new Contacto("", "", "", "", "", "");
                        Edite:
                        do {
                            Console.WriteLine("Ingrese el nombre");
                            nContacto.Nombre = Console.ReadLine();
                            Console.WriteLine("Escriba apellidos");
                            nContacto.Apellidos = Console.ReadLine();
                            Console.WriteLine("Cuántos años tiene");
                            nContacto.Edad = Console.ReadLine();
                            if (int.Parse(nContacto.Edad) < 18)
                            {
                                Console.WriteLine("Es menor de edad; no puede registrarse");
                            }
                            Console.WriteLine("¿Desea ingresar otro contacto?");
                            BANDERA1 = Console.ReadLine();
                            if (BANDERA1 == "s")
                            {
                                goto Edite;
                            }
                       


                        Console.WriteLine("Ingrese el email");
                        nContacto.Email = Console.ReadLine();
                        Console.WriteLine("Ingrese el DNI");
                        nContacto.DNI = Console.ReadLine();
                        Console.WriteLine("Escriba nacionalidad");
                        nContacto.Nacionalidad = Console.ReadLine();

                        /* StreamWriter texto = FileStyleUriParser.AppendText("prueba.txt");*/
                        Console.WriteLine("¿Desea ingresar otro contacto?");
                        BANDERA1 = Console.ReadLine();
                        } while (BANDERA1 == "s");

                        break;
                    case 2:

                        foreach (Contacto b in ListaContactos)
                        {

                            Console.WriteLine("Nombre" + b.Nombre);
                            Console.WriteLine("Apellidos" + b.Apellidos);
                            Console.WriteLine("Edad" + b.Edad);
                            Console.WriteLine("Email" + b.Email);
                            Console.WriteLine("DNI" + b.DNI);
                            Console.WriteLine("Nacionalidad" + b.Nacionalidad);

                        }

                        break;
                    case 3:
                         do{
                            Console.WriteLine("Ingrese el DNI");

                      /*  string valor = Console.ReadLine();
                        var busqueda = from b in ListaContactos
                                       where (b.Nombre == valor || b.Apellidos == valor || b.Edad == valor || b.DNI == valor || b.Nacionalidad == valor)
                                       select b;
                        foreach (var s in busqueda) { Console.Write(s.ToString() + " "); }
                     */
                            string bDNI=Console.ReadLine();
                            foreach (Contacto b in ListaContactos)
                          {
                              if (bDNI == b.DNI)
                              {
                                  Console.WriteLine("Nombre" + b.Nombre);
                                  Console.WriteLine("Apellidos" + b.Apellidos);
                                  Console.WriteLine("Email" + b.Email);
                                  Console.WriteLine("DNI" + b.DNI);
                              }
                          }
                        Console.WriteLine("Si desea buscar otro contacto pulse 's'si no 'n'");
                        BANDERA2 = Console.ReadLine();
                        } while (BANDERA2 == "s") ;
                           
                            break;
                        case 4:

                            Console.WriteLine("--------------Contactos------------------");
                        foreach (Contacto b in ListaContactos)
                        {

                            Console.WriteLine("Nombre" + b.Nombre);
                            Console.WriteLine("Apellidos" + b.Apellidos);
                            Console.WriteLine("Email" + b.Email);
                            Console.WriteLine("DNI" + b.DNI);

                        }
                        Console.WriteLine("Persona que quiere eliminar");
                            string posicion = Console.ReadLine();
                            if (int.TryParse(posicion, out x))
                            {
                                int posicioncon = int.Parse(posicion);
                                if (ListaContactos.Count <= posicioncon || posicioncon < 0)
                                {
                                    Console.WriteLine("¡¡¡¡¡¡¡¡¡¡¡¡No existe ese contacto!!!!!!!!!!!!!");
                                }
                                else
                                {
                                    ListaContactos.RemoveAt(posicioncon);

                                    /*for(int i=posicioncon; i<ListaContactos.Count;i++)
                                     {
                                        ListaContactos[i]=ListaContactos[i+1];
                                     }*/
                                  
                                    Console.WriteLine("Contacto eliminado");
                                }
                            }
                            else
                            {
                                Console.WriteLine("El dato es incorrecto");
                            }
                            break;
                        case 5:
                            string cambio;
                            Console.WriteLine("--------------Contactos------------------");
                        foreach (Contacto b in ListaContactos)
                        {

                            Console.WriteLine("Nombre" + b.Nombre);
                            Console.WriteLine("Apellidos" + b.Apellidos);
                            Console.WriteLine("Email" + b.Email);
                            Console.WriteLine("DNI" + b.DNI);

                        }
                        Console.WriteLine("Persona que quiere modificar");
                            int posicionc = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("¿Quiere modificar nombre(0) apellidos(1) edad(2) dni(3) email(4) nacionalidad(5)?");
                             n = int.Parse(Console.ReadLine());
                            switch (n)
                            {
                                case 0:
                                    Console.WriteLine("Nuevo Nombre:");
                                    cambio = Console.ReadLine();
                                    break;
                                case 1:
                                    Console.WriteLine("Nuevos apellidos:");
                                    cambio = Console.ReadLine();
                                    break;
                                case 2:
                                    Console.WriteLine("Nueva edad:");
                                    cambio = Console.ReadLine();
                                    break;
                                case 3:
                                    Console.WriteLine("Nuevo DNI:");
                                    cambio = Console.ReadLine();
                                    break;
                                case 4:
                                    Console.WriteLine("Nuevo email:");
                                    cambio = Console.ReadLine();
                                    break;
                                case 5:
                                    Console.WriteLine("Nueva nacionalidad:");
                                    cambio = Console.ReadLine();
                                    break;

                            }
                            /* 
                             Console.WriteLine("Contacto modificado.Si quiere modificar algún dato más pulse s");
                            */
                            break;
       
                       case 6:
                           bandera = false;
                           break;
                     }
            
            } while(bandera);
        }    
     }
}
