﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApp1
{


    public class Contacto
    {
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Edad { get; set; }
        public string Email { get; set; }
        public string DNI { get; set; }
        public string Nacionalidad { get; set; }


        /*
                  Regex rNombre = new Regex(@"[a - zA-Z{2,}]$");
                  Regex rApellidos = new Regex(@"[a-zA-Z]*\s[a-zA-Z]$");
                  Regex rEdad = new Regex(@"[/d]$");
                  Regex rEmail = new Regex(@"[a-zA-Z0-9_\-\.~]+@[a-zA-Z0-9_\-\.~]+\.[a-zA-Z]+$");
                  Regex rDNI = new Regex(@"[\d{8}+[a-zA-Z]$");
                  Regex rNacionalidad = new Regex(@"[a-zA-Z]$");

        public Contacto(string nombre, string apellidos, string edad, string email, string dni, string nacionalidad)
        {

            if (!rNombre.IsMatch(nombre))
            {
                throw new Exception("Formato inválido");
            }
            else { Nombre = nombre; }
            if (!rApellidos.IsMatch(apellidos)) { throw new Exception("Formato inválido"); }
            else { Apellidos = apellidos; }
            if (!rEdad.IsMatch(edad)) { throw new Exception("Formato inválido"); }
            else { Edad = edad; }

            if (!rEmail.IsMatch(email)) { throw new Exception("Formato inválido"); }
            else { Email = email; }

            if (!rDNI.IsMatch(dni)) { throw new Exception("Formato inválido"); }
            else { DNI = dni; }

            if (!rNacionalidad.IsMatch(nacionalidad)) { throw new Exception("Formato inválido"); }
            else { Nacionalidad = nacionalidad; }
        }
   */
        public Contacto(string nombre, string apellidos, string edad, string email, string dni, string nacionalidad)
        {
                   nombre = Nombre;
                   apellidos = Apellidos;
                   edad = Edad;
                   email = Email;
                   dni = DNI;
                   nacionalidad = Nacionalidad;
                } 
       
            public override string ToString()
           {
            return String.Format("nombre:{0}  \n apellidos:{1} \n edad:{2} \n email:{3} \n dni:{4} \n nacionalidad:{5}", Nombre, Apellidos,Edad, Email, DNI, Nacionalidad);
            //public override string ToString()=> $"{Nombre}{Apellidos}{Email}{DNI}{Nacionalidad}";
           }
     }
}
