﻿using System;
using Tipos;
using System.Text.RegularExpressions;

namespace EjercicioCsharp
{
    class Program
    {
        static void Menu(Grupo<Clients> g, int idcount)
        {
            Console.WriteLine(@"1 -> Alta clientes");
            Console.WriteLine(@"2 -> Modificar un cliente");
            Console.WriteLine(@"3 -> Dar de baja a un cliente");
            Console.WriteLine(@"4 -> Listado de clientes");
            Console.WriteLine(@"5 -> Search");
            Console.WriteLine(@"6 -> Salir");
            Console.WriteLine(@"-----------------------------------");

            Console.Write("Elige una opciones: ");
            string menuselection = Console.ReadLine();

            int selected;
            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");
            if (menuselection == "" || !val.IsMatch(menuselection))
            {
                menuselection = "6";
                selected = Convert.ToInt32(menuselection);
            }
            else
            {
                selected = Convert.ToInt32(menuselection);
            }
            switch (selected)
            {
                case 1: Alta(g, idcount); break;
                case 2: Modify(g, idcount); break;
                case 3: Baja(g, idcount); break;
                case 4: List(g, idcount); break;
                case 5: Search(g, idcount); break;
                case 6: Console.WriteLine("Hasta otra!"); break;
            }
        }
        static void CreateDefault(Grupo<Clients> g)
        {
            g.Add(new Clients(1, "Cliente1", "Apellido1 Apellido2", "emailcliente1@cliente1.com", "1234", "37220005W", "ES", @"05/12/1985"));
            g.Add(new Clients(2, "Cliente2", "Apellido3 Apellido4", "emailcliente2@cliente2.com", "56789", "91496104B", "EX", @"06/08/1952"));

            Console.WriteLine(@"ID | Nombre | Apellidos | Email | Contraseña | DNI | Nacionalidad | Fecha de nacimiento");
            int i = 0;
            for (i = 0; i < 2; i++)
            {
                Console.WriteLine(g.Componentes[i].ID + @" | " + g.Componentes[i].Name + @" | " + g.Componentes[i].Apellido + @" | " + g.Componentes[i].Email + @" | " + g.Componentes[i].Password + @" | " + g.Componentes[i].Dni + @" | " + g.Componentes[i].Nationality + @" | " + g.Componentes[i].BirthDate);
            }
        }
        static void Alta (Grupo<Clients> g, int idcount)
        {
            Console.WriteLine("Alta de clientes!");
            Console.WriteLine(@"--------------------------");

            Console.Write("ID de cliente: ");
            string idName = Console.ReadLine();
            Console.Write("Nombre de cliente: ");
            string nombre = Console.ReadLine();
            Console.Write("Apellidos del cliente: ");
            string apellidos = Console.ReadLine();
            Console.Write("Introduce la contraseña: ");
            string pass = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write(@"Fecha de nacimiento(dd/mm/yyyy): ");
            string fecha = Console.ReadLine();
            Console.Write("Dni: ");
            string nif = Console.ReadLine();
            Console.Write("Nacionalidad(Españos: ES; Extranjero EX): ");
            string nacionalidad = Console.ReadLine();
            string nat = nacionalidad.ToUpper();
            
            Boolean Avalido = Clients.ApellidoValido(apellidos); // comprueba que sea mayor de 5 y que tenga espacios
            Boolean Natvalido = Clients.NacionalidadValida(nat); // comprueba que sea ES o EX.
            Boolean Fvalido = Clients.FechaValida(fecha); // comprueba que la fecha no sea en el futuro y que se sea + 18
            Boolean Evalido = Clients.EmailValido(email); // comprueba que sea un email valido

            if (idName == "" || nombre == "" || nif == "")
            {
                Console.WriteLine();
                Console.WriteLine("Los campos ID, nombre y DNI son OBLIGATORIOS!");
            } else
            {
                Boolean IDvalido = Clients.IDValido(idName); //comprueba que el valor introducido es numerico
                Boolean Nvalido = Clients.NombreValido(nombre); // comprueba que sea mayor de dos caracteres
                if (IDvalido && Nvalido && Avalido && Fvalido && Natvalido && Evalido)
                {
                    int id = Convert.ToInt32(idName);
                    Clients cliente = g.Find(c => c.ID == id);

                    if (cliente == null)
                    {
                        try
                        {
                            Dni dni = new Dni(nif);
                            if (Dni.EsValido(nif))
                            {
                                Clients cDNI = g.Find(c => c.Dni == nif);
                                if (cDNI == null)
                                {
                                    dni = new Dni(nif);
                                    g.Add(new Clients(id, nombre, apellidos, email, pass, nif, nat, fecha));
                                    Console.WriteLine("El cliente ha sido creado!");
                                    idcount++;
                                } else
                                {
                                    Console.WriteLine("No pueden existir dos clientes diferentes con el mismo DNI.");
                                }
                            }
                        }
                        catch
                        {
                            Console.WriteLine("El DNI no es valido.");
                        }
                    } else
                    {
                        Console.WriteLine("El ID introducido ya existe...");
                    }
                }
            }

            Repeat(g, idcount);
        }
        static void Modify(Grupo<Clients> g, int idcount)
        {
            Console.Write("Por favor introduzca el id del cliente a modificar: ");
            string modifyID = Console.ReadLine();
            int Mid = Convert.ToInt32(modifyID);

            int i = 0;
            Boolean found = false;
            for (i = 0; i < idcount; i++)
            {
                if (g.Componentes[i].ID == Mid)
                {
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Cliente no encontrado");
            } else
            {
                Console.WriteLine();
                Console.WriteLine(@"----------------------------------------------");
                Console.WriteLine(@"| Si no desea modificar el campo pulse enter |");
                Console.WriteLine(@"----------------------------------------------");
                Console.WriteLine();

                Console.WriteLine("Nombre actual -> " + g.Componentes[i].Name);
                Console.Write("Nombre:");
                string nombre = Console.ReadLine();
                if (nombre == "")
                {
                     nombre = g.Componentes[i].Name;
                }
                Console.WriteLine("Apellido actual -> " + g.Componentes[i].Apellido);
                Console.Write("Apellidos:");
                string apellido = Console.ReadLine();
                if (apellido == "")
                {
                     apellido = g.Componentes[i].Apellido;
                }
                Console.WriteLine("Email actual -> " + g.Componentes[i].Email);
                Console.Write("Email:");
                string email = Console.ReadLine();
                if (email == "")
                {
                    email = g.Componentes[i].Email;
                }
                Console.WriteLine("Contraseña actual -> " + g.Componentes[i].Password);
                Console.Write("Nueva contraseña:");
                string pass = Console.ReadLine();
                if (pass == "")
                {
                    pass = g.Componentes[i].Password;
                }
                Console.WriteLine("El DNI actual -> " + g.Componentes[i].Dni);
                Console.Write("DNI:");
                string nif = Console.ReadLine();
                if (nif == "")
                {
                    nif = g.Componentes[i].Dni;
                }
                Console.WriteLine("Nacionalidad actual -> " + g.Componentes[i].Nationality);
                Console.Write("Nacionalidad:");
                string nat = Console.ReadLine();
                if (nat == "")
                {
                    nat = g.Componentes[i].Nationality;
                }
                Console.WriteLine("Fecha de nacimiento actual -> " + g.Componentes[i].BirthDate);
                Console.Write("Fecha de nacimiento:");
                string fecha = Console.ReadLine();
                if (fecha == "")
                {
                    fecha = g.Componentes[i].BirthDate;
                }

                Boolean Avalido = Clients.ApellidoValido(apellido); // comprueba que sea mayor de 5 y que tenga espacios
                Boolean Natvalido = Clients.NacionalidadValida(nat); // comprueba que sea ES o EX.
                Boolean Fvalido = Clients.FechaValida(fecha); // comprueba que la fecha no sea en el futuro y que se sea + 18
                Boolean Evalido = Clients.EmailValido(email); // comprueba que sea un email valido

                if (nombre == "" || nif == "")
                {
                    Console.WriteLine();
                    Console.WriteLine("Los campos ID, nombre y DNI son OBLIGATORIOS!");
                }
                else
                {
                    Boolean Nvalido = Clients.NombreValido(nombre); // comprueba que sea mayor de dos caracteres
                    if (Nvalido && Avalido && Fvalido && Natvalido)
                    {
                        try
                        {
                            Dni dni = new Dni(nif);
                            if (Dni.EsValido(nif))
                            {
                                dni = new Dni(nif);
                                g.Componentes[i].Name = nombre;
                                g.Componentes[i].Apellido = apellido;
                                g.Componentes[i].Email = email;
                                g.Componentes[i].Password = pass;
                                g.Componentes[i].Dni = nif;
                                g.Componentes[i].Nationality = nat;
                                g.Componentes[i].BirthDate = fecha;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("El DNI no es valido.");
                        }
                    }
                }
            }
            Repeat(g, idcount);
        }
        static void Baja (Grupo<Clients> g, int idcount)
        {
            Console.Write("Introduce el ID del usuario a eliminar: ");
            string id = Console.ReadLine();
            if (id != "")
            {
                int DeleteId = Convert.ToInt32(id);
                Clients cliente = g.Find(c => c.ID == DeleteId);
                if (cliente != null)
                {
                    Console.WriteLine(cliente);
                    Console.Write(@"¿Estas seguro? s/N ");
                    string choosed = Console.ReadLine();
                    string choose = choosed.ToUpper();
                    if (choose == "S")
                    {
                        g.Remove(cliente);
                        Console.WriteLine(@"------------------");
                        Console.WriteLine("El cliente ha sido eliminado.");
                        idcount--;
                    }
                } else
                {
                    Console.WriteLine("El ID no existe");
                }
            } else
            {
                Console.WriteLine("No puede introducir valores nulos");
            }
                Repeat(g, idcount);
        }
        static void List (Grupo<Clients> g, int idcount)
        {
            Console.WriteLine(@"ID | Nombre | Apellidos | Email | Contraseña | DNI | Nacionalidad | Fecha de nacimiento");
            int i = 0;
            for (i = 0; i < idcount; i++)
            {
                Console.WriteLine(g.Componentes[i].ID + @" | " + g.Componentes[i].Name + @" | " + g.Componentes[i].Apellido + @" | " + g.Componentes[i].Email + @" | " + g.Componentes[i].Password + @" | " + g.Componentes[i].Dni + @" | " + g.Componentes[i].Nationality + @" | " + g.Componentes[i].BirthDate);
            }
            Repeat(g, idcount);
        }
        static void Search (Grupo<Clients> g, int idcount)
        {
            Console.WriteLine("Selecciona mediante que atributo quieres buscar");
            Console.WriteLine(@"1 -> ID");
            Console.WriteLine(@"2 -> Nombre");
            Console.WriteLine(@"3 -> Apellidos");
            Console.WriteLine(@"4 -> Email");
            Console.WriteLine(@"5 -> Contraseña");
            Console.WriteLine(@"6 -> DNI");
            Console.WriteLine(@"7 -> Nacionalidad");
            Console.WriteLine(@"8 -> Fecha");
            Console.WriteLine(@"-----------------------------------");

            Console.Write("Elige una opciones: ");
            string attSelection = Console.ReadLine();

            int selected;
            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");
            if (attSelection == "" || !val.IsMatch(attSelection))
            {
                attSelection = "8";
                selected = Convert.ToInt32(attSelection);
            }
            else
            {
                selected = Convert.ToInt32(attSelection);
            }
            switch (selected)
            {
                case 1:
                    Console.Write("Introduzca el ID: ");
                    string id = Console.ReadLine();
                    int searchid = Convert.ToInt32(id);
                    Clients clienteID = g.Find(c => c.ID == searchid);
                    Console.WriteLine(clienteID);
                    break;
                case 2:
                    Console.Write("Introduzca el Nombre: ");
                    string nombre = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Name", nombre);
                    break;
                case 3:
                    Console.Write("Introduzca el apellidos: ");
                    string apellido = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Apellido", apellido);
                    break;
                case 4:
                    Console.Write("Introduzca el Email: ");
                    string email = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Email", email);
                    break;
                case 5:
                    Console.Write("Introduzca el constraseña: ");
                    string pass = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Pass", pass);
                    break;
                case 6:
                    Console.Write("Introduzca el DNI: ");
                    string DNI = Console.ReadLine();
                    Clients clienteDNI = g.Find(c => c.Dni == DNI);
                    Console.WriteLine(clienteDNI);
                    break;
                case 7:
                    Console.Write("Introduzca el nacionalidad: ");
                    string nat = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Nat", nat);
                    break;
                case 8:
                    Console.Write("Introduzca el fecha de nacimiento: ");
                    string fecha = Console.ReadLine();
                    Clients.SearchClient(g, idcount, "Fecha", fecha);
                    break;
                default: Console.WriteLine("Opcion no valida..."); break;
            }
            Repeat(g, idcount);
        }
        static void Repeat (Grupo<Clients> g, int idcount)
        {
            Console.Write(@"Desea hacer algo mas? s/N ");
            string Volver = Console.ReadLine();

            if (Volver == "s" || Volver == "S")
            {
                Console.Clear();
                Menu(g, idcount);
            }
            else
            {
                Console.WriteLine("Hasta lueguito!");
            }
        }
        static void Main()
        {
            Grupo<Clients> g = new Grupo<Clients>("Clientes");
            CreateDefault(g);
            int idcount = 2;
            Console.WriteLine(@"-----------------------------------");
            Menu(g, idcount);
        }
    }
}
