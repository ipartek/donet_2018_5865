﻿using System;

namespace Tipos
{
    internal class OcultoParaBusquedasAttribute : Attribute
    {
    }
}
