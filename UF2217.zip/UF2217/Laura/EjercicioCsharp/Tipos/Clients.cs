﻿using System;
using System.Text.RegularExpressions;

namespace Tipos
{
    //[OcultoParaBusquedas]
    public class Clients
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Apellido { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Dni { get; set; }
        public string BirthDate { get; set; }
        public string Nationality { get; set; }

        public Clients(int id = 0, string name = null, string lastName = null, string email = null, string password = null, string dni = null, string nacionalidad = null, string birthDate = null)
        {
            ID = id;
            Name = name;
            Apellido = lastName;
            Email = email;
            Password = password;
            Dni = dni;
            Nationality = nacionalidad;
            BirthDate = birthDate;
            
        }
        public static bool IDValido (string id)
        {
            Regex val = new Regex(@"[0-9]{1,9}(\.[0-9]{0,2})?$");
            if (val.IsMatch(id))
            {
                return true;
            } else
            {
                Console.WriteLine("El ID tiene que ser numerico");
                return false;
            }
        }
        public static bool NombreValido (string nombre)
        {
            if (nombre.Length < 2)
            {
                Console.WriteLine("El nombre tiene que tener más de 2 caracteres");
                return false;
            } else
            {
                return true;
            }
        }
        public static bool EmailValido(string email)
        {
            Regex val = new Regex(@"^[^@]+@[^@]+\.[a-zA-Z]{2,}$");
            if (val.IsMatch(email) || email == "")
            {
                return true;
            } else
            {
                Console.WriteLine(@"El email no es valido, ejemplo valido: alguien@algo.com");
                return false;
            }
        }
        public static bool ApellidoValido(string apellido)
        {
            Regex val = new Regex(@"\s");
            if ((apellido.Length >= 5 && val.IsMatch(apellido)) || apellido == "")
            {
                return true; 
            } else
            {
                Console.WriteLine("El apellido tiene que tener más de 5 caracteres o asegurese de introducir ambos apellidos");
                return false;
            }
        }
        public static bool NacionalidadValida(string nat)
        {
            if (nat == "ES" || nat == "EX" || nat == "")
            {
                return true;
            } else
            {
                Console.WriteLine(@"El valor introducido como nacionalidad no es valido. Solo admite ES/EX");
                return false;
            }
        }
        public static bool FechaValida (string fecha)
        {
            if (fecha == "")
            {
                return true;
            }
            else
            {
                Regex val = new Regex(@"^([0][1-9]|[12][0-9]|3[01])(\/)([0][1-9]|[1][0-2])\2(\d{4})$");
                string d = fecha.Substring(0, 2),
                    m = fecha.Substring(3, fecha.Length - 8),
                    y = fecha.Substring(fecha.Length - 4, 4),
                    idDate = DateTime.Now.ToString("yyyyMMddHHmmss"),
                    D = idDate.Substring(6, idDate.Length - 12),
                    M = idDate.Substring(4, idDate.Length - 12),
                    Y = idDate.Substring(0, 4);
                

                if (!val.IsMatch(fecha))
                {
                    Console.WriteLine("Fecha invalida.");
                    return false;
                }
                else
                {
                    int dia = Convert.ToInt32(d),
                    day = Convert.ToInt32(D),
                    mes = Convert.ToInt32(m),
                    month = Convert.ToInt32(M),
                    anio = Convert.ToInt32(y),
                    year = Convert.ToInt32(Y);

                        if ((year - anio) > 18)
                        {
                            return true;
                        }
                        else if ((year - anio) == 18)
                        {
                            if (mes < month)
                            {
                                return true;
                            }
                            else if (mes == month && dia <= day)
                            {
                                return true;
                            }
                            else
                            {
                                Console.WriteLine("Tienes que ser mayor de 18 años para poder ser cliente.");
                                return false;
                            }
                        }
                        else if (anio > year)
                        {
                            Console.WriteLine("No puedes haber nacido en el futuro.");
                            return false;
                        }
                        else
                        {
                            Console.WriteLine("Tienes que ser mayor de 18 años para poder ser cliente.");
                            return false;
                        }
                }
            }
        }
        public static void SearchClient (Grupo<Clients> g, int idcount, string option, string searchobject)
        {
            Boolean found = false;
            for (int i = 0; i < idcount; i++)
            {
                string actualAtt = null;
                if (option == "Name")
                {
                    actualAtt = g.Componentes[i].Name;
                } else if (option == "Apellido")
                {
                    actualAtt = g.Componentes[i].Apellido;
                } else if (option == "Email")
                {
                    actualAtt = g.Componentes[i].Email;
                } else if (option == "Pass")
                {
                    actualAtt = g.Componentes[i].Password;
                } else if (option == "Nat")
                {
                    actualAtt = g.Componentes[i].Nationality;
                } else if (option == "Fecha")
                {
                    actualAtt = g.Componentes[i].BirthDate;
                }
                if (actualAtt == searchobject)
                {
                    Console.WriteLine("ID: {0}, Name: {1}, Apellido: {2}, Email: {3}, Contraseña: {4}, Nacionalidad: {5}, Fecha de nacimiento: {6}", g.Componentes[i].ID, g.Componentes[i].Name, g.Componentes[i].Apellido, g.Componentes[i].Email, g.Componentes[i].Password, g.Componentes[i].Nationality, g.Componentes[i].BirthDate);
                    Console.WriteLine();
                    found = true;
                }

            }
            if (!found)
            {
                Console.WriteLine("Cliente no encontrado");
            }
        }
         //Método de instancia
        public virtual string GetTexto()
        {
            return string.Format("ID: {0}, Name: {1}, Apellido: {2}, Email: {3}, Contraseña: {4}, Nacionalidad: {5}, Fecha de nacimiento: {6}", ID, Name, Apellido, Email, Password, Nationality, BirthDate);
        }

        public enum Formatos
        {
            Bonito,
            Compacto
        }

        //Sobrecargas
        public string GetTexto(string formato)
        {
            switch (formato)
            {
                case "bonito":
                    return GetTexto();
                case "compacto":
                    return string.Format("{0},{1}", Email, Password);
                default:
                    return GetTexto();
            }
        }
        public string GetTexto(Formatos formato)
        {
            switch (formato)
            {
                case Formatos.Bonito:
                    return GetTexto("bonito");
                case Formatos.Compacto:
                    return GetTexto("compacto");
                default:
                    return GetTexto();
            }
        }

        //Sobrecarga de operadores
        public static bool operator >(Clients c1, Clients c2)
        {
            return c1.Email.CompareTo(c2.Email) > 0;
        }

        public static bool operator <(Clients c1, Clients c2)
        {
            return c1.Email.CompareTo(c2.Email) < 0;
        }

        public override string ToString()
        {
            return GetTexto();
        }

    }
}
