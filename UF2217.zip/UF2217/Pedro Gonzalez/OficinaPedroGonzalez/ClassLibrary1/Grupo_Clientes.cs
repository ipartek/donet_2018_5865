﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oficina
{
    public class Grupo_Clientes
    {
        public static List<Cliente> grupoclientes= new List<Cliente>();
    }
}
