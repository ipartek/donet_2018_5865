﻿using Excepciones;
using System;
using System.Text.RegularExpressions;

namespace Oficina
{
    public class Cliente 
    {
        private const string LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE";
        public Cliente(int id, string nombre, string apellido, string email, string password, string dni, DateTime fecha_nacimiento, bool nacionalidad)
        {
            Id = id;
            Nombre = nombre;
            Apellido = apellido;
            Email = email;
            Password = password;
            Dni = dni;
            Fecha_nacimiento = fecha_nacimiento;
            Nacionalidad = nacionalidad;
        }
        public Cliente(int id) { Id = id; }

        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            
            set
            {
                string val = value.Trim();
                val = Regex.Replace(val, @"\s+", " ");
                if (value == null)
                {
                    throw new TiposException("No se admiten Nombres nulos");
                }

                if (val.Length == 0)
                {
                    throw new TiposException("Es obligatorio rellenar el Nombre");
                }

                if (!Regex.IsMatch(val, @"^\D{2,}$")) 
                {
                    throw new TiposException("Se requiere un formato correcto de almenos 2 caracteres");
                }
               

                nombre = val;
                //nombre = value.Trim();
            }
        }
        private string apellido;
        public string Apellido
        {
            get { return apellido; }
           
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admiten apellidos nulos");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Debes rellenar dos apellidos");
                }

                if (!Regex.IsMatch(value.Trim(), @"^[^0-9\s]{2,} [^0-9\s]{2,}$"))
                {
                    throw new TiposException("Se requiere un formato correcto de almenos 5 caracteres un espacio y otro apellido");
                }

                apellido = value.Trim();
            }
        }
        private string email;
        public string Email
        {
            get { return email; }
           
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admite un email nulo");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Debes rellenar el Email");
                }

                if (!Regex.IsMatch(value.Trim(), @"^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$"))//
                {
                    throw new TiposException("Se requiere un formato correcto ejemplo@mail.com");
                }

                email = value.Trim();
            }
        }
        private string password;
        public string Password
        {
            get { return password; }
            
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admite una Contraseña nula");
                }

                if (value.Trim().Length == 0)
                {
                    throw new TiposException("Debes rellenar una contraseña");
                }

                if (!Regex.IsMatch(value.Trim(), @".{8,}"))//
                {
                    throw new TiposException("Se requiere una contraseña de 8 digitos");
                }

                password = value.Trim();
            }
        }
        private string dni;
        public string Dni
        {
            get { return dni; }
           
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admite un dni nulo");
                }

                if (value.Length == 0)
                {
                    throw new TiposException("Debes rellenar un DNI");
                }

                if (!Regex.IsMatch(value.Trim(), @"[XYZ\d]\d{7}[ABCDEFGHJKLMNPQRSTVWXYZ]$") )
                {
                    if(!EsValido(value))    
                    throw new TiposException("Debes rellenar un DNI Correcto");
                    
                }
                dni = value.Trim();
            }
        }
        private DateTime fecha_nacimiento;
        public DateTime Fecha_nacimiento
        {
            get { return fecha_nacimiento; }
            
            set
            {
                if (value == null)
                {
                    throw new TiposException("No se admite una fecha nula");
                }

                if (value.GetHashCode()==0)
                {
                    throw new TiposException("Debes rellenar una Fecha Correcta");
                }

                if (!(value.AddYears(18) < DateTime.Today))
                {
                  
                        throw new TiposException("Debes tener al menos 18 años");

                }
                fecha_nacimiento = value;
            }
        }


        private bool nacionalidad;
        public bool Nacionalidad
        {
            get { return nacionalidad; }
            // public void set_Email(string value){
            set
            {
                nacionalidad = value;
            }
        }
        public string Nac
        {
            get { return (nacionalidad)?"ESP":"EXT"; }

        }

        private static bool EsValido(string dni)
        {
            string sNumero = ExtraerNumero(dni);

            char letra = dni[8];

            sNumero = sNumero.Replace('X', '0').Replace('Y', '1').Replace('Z', '2');

            return letra == CalcularLetra(int.Parse(sNumero));
        }

        private static string ExtraerNumero(string dni)
        {
            return dni.Substring(0, dni.Length - 1);
        }

        private static char CalcularLetra(int numero)
        {
            return LETRAS[numero % 23];
        }



    }
}
