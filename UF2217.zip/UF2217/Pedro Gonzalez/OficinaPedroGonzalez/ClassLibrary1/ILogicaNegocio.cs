﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oficina
{
    public interface ILogicaNegocio
    {
        //definimos los metodos a implementar (insertar, editar, eliminar)

        bool CrearCliente(Cliente cliente);
        List<Cliente> Listar();
        bool Editar(Cliente cliente, Cliente ClienteEncontrado);
        bool Borrar(string nombre);
        bool BuscarPorId(int Id);
        Cliente FindId(int id);
        Cliente FindName(string nombre);

    }
}
