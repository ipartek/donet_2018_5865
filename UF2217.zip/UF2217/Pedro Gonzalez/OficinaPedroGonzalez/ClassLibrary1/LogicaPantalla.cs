﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Oficina
{
    public class LogicaPantalla
    {
        private ILogicaNegocio logicaNegocio = new LogicaNegocio();
        int id = 0;
        bool ctrlerror = true;
        private const string LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE";

        public static string[] mensajesdeerror =
        {
            "El nombre debe tener al menos dos cararcteres",
            "El Apellido debe tener al menos 5 caracteres",
            "EL Email debe ser en un formato correcto ejemplo@mail.com",
            "El La contraseña debe tener 8 caracteres ",
            @"El Formato debe ser dd/MM/YY ",
            "El dni no es valido",
            "Debes tener al menos 18"
        };
        public static string[] mensajesdecampos =
        {
            "Introduzca un Nombre",
            "Introduzca dos Apellidos",
            "Introduzca un Email",
            "Introduzca una Contraseña",
            "Introduzca un Dni",
            "Introduzca la Fecha de Nacimiento",
            "Introduzca su Nacionalidad"
        };
        public void Insertar()
        {


            Cliente cliente = new Cliente(id);

            
            PedirNombre(mensajesdecampos[0], n => cliente.Nombre = n);
            PedirApellido(mensajesdecampos[1], ap => cliente.Apellido = ap);
            PedirEmail(mensajesdecampos[2], eml => cliente.Email = eml);
            PedirPassword(mensajesdecampos[3], pass => cliente.Password = pass);
            PedirDni(mensajesdecampos[4], nif => cliente.Dni = nif);
            PedirFecha(mensajesdecampos[5], fecha => cliente.Fecha_nacimiento = fecha);
            PedirNacionalidad(mensajesdecampos[6], nac => cliente.Nacionalidad = nac);

            logicaNegocio = new LogicaNegocio();
            if (logicaNegocio.CrearCliente(cliente))

            {
                Console.Write("Datos Ingresados bien");
                id++;
            }
            else
            {
                Console.WriteLine("Datos no ingresados ");
            }
        }

        public void Editar()
        {
            Listar();
            do
            {
                Console.WriteLine();
                Console.WriteLine("Ingrese el id de la persona que desea editar:");
                int capturarCliente = int.Parse(Console.ReadLine());


                ctrlerror = false;


                Cliente ClienteEncontrado = logicaNegocio.FindId(capturarCliente);
                if (ClienteEncontrado != null)
                {
                    Cliente cliente = new Cliente(id);


                    PedirNombre(mensajesdecampos[0], n => cliente.Nombre = n);
                    PedirApellido(mensajesdecampos[1], ap => cliente.Apellido = ap);
                    PedirEmail(mensajesdecampos[2], eml => cliente.Email = eml);
                    PedirPassword(mensajesdecampos[3], pass => cliente.Password = pass);
                    PedirDni(mensajesdecampos[4], nif => cliente.Dni = nif);
                    PedirFecha(mensajesdecampos[5], fecha => cliente.Fecha_nacimiento = fecha);
                    PedirNacionalidad(mensajesdecampos[6], nac => cliente.Nacionalidad = nac);
                    ctrlerror = true;

                    if (logicaNegocio.Editar(cliente, ClienteEncontrado))

                    {

                        Console.Write("Datos Modificados bien");
                        ctrlerror = true;
                    }
                    else
                    {
                        Console.WriteLine("Datos no modificados ");
                        ctrlerror = false;
                    }
                }
                else
                {
                    Console.WriteLine("Cliente no encontrado");
                    ctrlerror = false;
                }
            } while (ctrlerror == false);
        }

        private delegate void DelegadoPedirNacionalidad(bool nac);
        private static void PedirNacionalidad(string mensajes, DelegadoPedirNacionalidad delegateNacionalidad)
        {
            bool repetir;
            bool val = true;
            bool repeat = true;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    do
                    {
                        string escribir = Console.ReadLine();
                        if (escribir == "ESP")

                        {
                            val = true;
                            repeat = false;
                        }
                        else if (escribir == "EXT")
                        {

                            val = false;
                            repeat = false;
                        }
                        if (repeat == true)
                        {
                            Console.WriteLine("Debe escribir Nacionalidad ESP : EXT");
                        }
                    } while (repeat == true);

                    delegateNacionalidad(val);
                    repetir = false;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private delegate void DelegadoPedirFecha(DateTime fecha);
        private static void PedirFecha(string mensajes, DelegadoPedirFecha delegatefecha)
        {
            bool repetir;
            string format = "dd/MM/yyyy";
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegatefecha(DateTime.ParseExact(Console.ReadLine(), format, System.Globalization.CultureInfo.InvariantCulture));
                }
                catch (FormatException)
                {
                    Console.WriteLine(mensajesdeerror[4]);
                    repetir = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }

        private delegate void DelegadoPedirDni(string nif);
        private static void PedirDni(string mensajes, DelegadoPedirDni delegateDni)
        {
            bool repetir;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegateDni(Console.ReadLine());
                }
                catch (IndexOutOfRangeException)
                {

                    Console.WriteLine(mensajesdeerror[5]);
                    repetir = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private delegate void DelegadoPedirPassword(string pass);
        private static void PedirPassword(string mensajes, DelegadoPedirPassword delegatePasword)
        {
            bool repetir;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegatePasword(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }

        private delegate void DelegadoPedirEmail(string eml);

        private static void PedirEmail(string mensajes, DelegadoPedirEmail delegateEmail)
        {
            bool repetir;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegateEmail(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }
        private delegate void DelegadoPedirapellido(string ap);
        private static void PedirApellido(string mensajes, DelegadoPedirapellido delegateApellido)
        {
            bool repetir;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegateApellido(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }

        private delegate void DelegadoPedirNombre(string n);

        private static void PedirNombre(string mensajes, DelegadoPedirNombre delegateNombre)
        {
            bool repetir;
            do
            {
                try
                {
                    repetir = false;
                    Console.WriteLine(mensajes);
                    delegateNombre(Console.ReadLine());

                }
                catch (FormatException)
                {
                    Console.WriteLine(mensajesdeerror[0]);
                    repetir = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    repetir = true;
                }
            } while (repetir);
        }

        public void Listar()
        {
            ILogicaNegocio imetodos = new LogicaNegocio();
            List<Cliente> listaClientes = imetodos.Listar();
            int i = 1;

            foreach (Cliente item in listaClientes)
            {

                Console.WriteLine(string.Concat(item.Id, " ID ", item.Nombre, " - ", item.Apellido, " - ", item.Email, " - ", item.Password, " - ", item.Dni, " - ", item.Fecha_nacimiento, " - ", item.Nac));
                i++;
            }
        }
        public void Borrar()
        {
            Listar();

            Console.WriteLine();
            Console.WriteLine("Ingrese el nombre de la persona que desea Borrar:");

            string capturarCliente = Console.ReadLine();

            ILogicaNegocio imetodos = new LogicaNegocio();

            if (imetodos.Borrar(capturarCliente))

            {
                Console.Write("Datos Borrados bien");

            }
            else
            {
                Console.WriteLine("Datos no Borrados ");
            }
        }
        public void FindbyName()
        {
            Console.WriteLine("Ingrese el nombre de la persona que desea Buscar:");

            string encontrarnombre = Console.ReadLine();
            int i = 1;

            Cliente clientepillado = logicaNegocio.FindName(encontrarnombre);

            if (clientepillado != null)
            {

                Console.WriteLine(string.Concat(clientepillado.Id, " ID ", clientepillado.Nombre, " - ", clientepillado.Apellido, " - ", clientepillado.Email, " - ", clientepillado.Password, " - ", clientepillado.Dni, " - ", clientepillado.Fecha_nacimiento, " - ", clientepillado.Nac));
                i++;
            }
            else
            {
                if (encontrarnombre == "")
                {

                    Console.WriteLine("se ha buscado en vacio vuelve a intentarlo");
                }
                Console.WriteLine("No se ha encontrado el cliente con el nombre:" + encontrarnombre);
            }
        }
        public void FindbyId()
        {
            Console.WriteLine("Ingrese el id de la persona que desea Buscar:");
            int encontrarid;
            int i = 1;

            if (int.TryParse(Console.ReadLine(), out encontrarid))
            {



                Cliente clientepillado = logicaNegocio.FindId(encontrarid);

                if (clientepillado != null)
                {

                    Console.WriteLine(string.Concat(clientepillado.Id, " ID ", clientepillado.Nombre, " - ", clientepillado.Apellido, " - ", clientepillado.Email, " - ", clientepillado.Password, " - ", clientepillado.Dni, " - ", clientepillado.Fecha_nacimiento, " - ", clientepillado.Nac));
                    i++;
                }
                else
                {
                    Console.WriteLine("No se ha encontrado el cliente con el nombre:" + encontrarid);
                }
            }
            else
            {

                Console.WriteLine("No se ha encontrado el cliente con el id:" + encontrarid);
            }
        }
    }
}

