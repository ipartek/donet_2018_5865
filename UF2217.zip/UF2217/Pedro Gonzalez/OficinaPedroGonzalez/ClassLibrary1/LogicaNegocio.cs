﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oficina
{
    public class LogicaNegocio : ILogicaNegocio
    {
        public bool Borrar(string nombre)
        {
            int posicionCliente = 0;
            bool existeNombre = false;

            foreach (Cliente item in Grupo_Clientes.grupoclientes)
            {
                if (item.Nombre == nombre)
                {
                    existeNombre = true;
                    break;
                }
                posicionCliente++;
            }
            if (existeNombre)
            {
                Grupo_Clientes.grupoclientes.RemoveAt(posicionCliente);
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool BuscarPorId(int Id)
        {
            throw new NotImplementedException();
        }
       
        public bool CrearCliente(Cliente cliente)
        {
            Grupo_Clientes.grupoclientes.Add(cliente);
            return true;
        }

        public bool Editar(Cliente cliente, Cliente ClienteEncontrado)
        {
            ClienteEncontrado.Nombre = cliente.Nombre;
            ClienteEncontrado.Apellido = cliente.Apellido;
            ClienteEncontrado.Email = cliente.Email;
            ClienteEncontrado.Password = cliente.Password;
            ClienteEncontrado.Dni = cliente.Dni;
            ClienteEncontrado.Fecha_nacimiento = cliente.Fecha_nacimiento;
            ClienteEncontrado.Nacionalidad = cliente.Nacionalidad;
            return true;
        }
        public List<Cliente> Listar()
        {
            return Grupo_Clientes.grupoclientes;
        }
        public Cliente FindId(int id)
        {
            Cliente searchid = Grupo_Clientes.grupoclientes.Find(u => u.Id == id);

            if (searchid == null)
            {
                return default(Cliente);
            }
            return searchid;
           
        }
        public Cliente FindName(string nombre)
        {
            Cliente searchname = Grupo_Clientes.grupoclientes.Find(u => u.Nombre == nombre);

            if (searchname == null)
            {
                return default(Cliente);
            }
            return searchname;    
        }
        
    }
}
