﻿using System;

namespace Oficina
{
    class Program
    {
        public static void Main(string[] args)
        {

            int opcion = 0;

            LogicaPantalla logica = new LogicaPantalla();

            while (opcion != 7)
            {
                Console.WriteLine("1. Dar de alta Cliente.");
                Console.WriteLine("2. Listar Cliente.");
                Console.WriteLine("3. Editar Cliente.");
                Console.WriteLine("4. Eliminar Cliente.");
                Console.WriteLine("5. Buscar Por Nombre.");
                Console.WriteLine("6. Buscar Por id.");
                Console.WriteLine("7. Salir.");
                Console.WriteLine("----------------------------------------------------");
                Console.WriteLine("Elige una opción:");

                string opcionposible = Console.ReadLine();

                if (int.TryParse(opcionposible, out int x))
                {
                    opcion = int.Parse(opcionposible);

                    switch (opcion)
                    {
                        case 1:

                            logica.Insertar();

                            break;
                        case 2:
                            logica.Listar();
                            break;
                        case 3:
                            logica.Editar();
                            break;
                        case 4:
                            logica.Borrar();
                            break;
                        case 5:
                            logica.FindbyName();
                            break;
                        case 6:
                            logica.FindbyId();
                            break;
                        case 7:

                            break;

                        default:
                            Console.WriteLine("La opción elegida dabe ser de 1-5.");

                            break;
                    }
                }
                else
                {
                    opcion = 0;

                    Console.WriteLine("El valor ingresado no es correcto");
                }

                if (opcion != 7)
                {
                    Console.ReadLine();
                }

                Console.Clear();
            }
        }
    }
}
