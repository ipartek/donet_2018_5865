﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Tipos
{
    public class Grupo
    {
        private List<Cliente> listaClientes = new List<Cliente>();

        private string Nombre { get; set; }

        public Grupo(string nombre)
        {
            Nombre = nombre;
            
        }

        public void Alta(Cliente c)
        {
            if (listaClientes.Count == 0)
                c.Id = 1;
            else
                c.Id = listaClientes[listaClientes.Count-1].Id + 1;
            listaClientes.Add(c);
        }

        public void Modificar(int idCliente, Cliente c)
        {
            Cliente seleccionado = BuscarPorId(idCliente);
            seleccionado.Nombre = c.Nombre;
            seleccionado.Apellidos = c.Apellidos;
            seleccionado.Email = c.Email;
            seleccionado.Pass = c.Pass;
            seleccionado.Dni = c.Dni;
            seleccionado.FechaNac = c.FechaNac;
            seleccionado.Nacionalidad = c.Nacionalidad;
        }

        public void DarDeBaja(int id)
        {
            Cliente seleccionado = BuscarPorId(id);
            if (seleccionado == null)
            {
                throw new ExcepcionesDelPrograma("No existe un cliente sin valores.");
            }
            listaClientes.Remove(seleccionado);
        }

        private ReadOnlyCollection<Cliente> VerListado()
        {
            return new ReadOnlyCollection<Cliente>(listaClientes);
        }

        public ReadOnlyCollection<Cliente> Listado
        {
            get { return VerListado(); }
        }

        public Cliente BuscarPorId(int id)
        {
            Cliente clienteSeleccionado = listaClientes.Find(Cliente => Cliente.Id == id);
            if (clienteSeleccionado == null)
            {
                throw new ExcepcionesDelPrograma("No existe ningun cliente con ese ID.");
            }
            return clienteSeleccionado;
        }

        public List<Cliente> BuscarPorNombre(string nombre)
        {
            List<Cliente> clienteSeleccionado = listaClientes.FindAll(Cliente => Cliente.Nombre == nombre);
            if (clienteSeleccionado == null)
            {
                throw new ExcepcionesDelPrograma("No existe ningun cliente con ese ID.");
            }
            return clienteSeleccionado;
        }

        public List<Cliente> Buscar(Predicate<Cliente> delegadoDeBusqueda)
        {

            List<Cliente> buscado = listaClientes.FindAll(delegadoDeBusqueda);
            
            return buscado;
        }
        public List<Cliente> this[string propiedad, string dato]
        {
            get
            {
                switch (propiedad)
                {
                    case "Nombre":
                    case "nombre":
                        return Buscar(c=>c.Nombre == dato);
                    case "Apellidos":
                    case "apellidos":
                        return Buscar(c => c.Apellidos.Contains(dato));
                    case "Email":
                    case "email":
                        return Buscar(c => c.Email == dato);
                    case "Contraseña":
                    case "contraseña":
                        return Buscar(c => c.Pass == dato);
                    case "Dni":
                    case "dni":
                        return Buscar(c => c.Dni == dato);
                    case "Fecha de nacimiento":
                    case "fecha de nacimiento":
                        return Buscar(c => c.FechaNac == DateTime.Parse(dato));
                    case "Nacionalidad":
                    case "nacionalidad":
                        return Buscar(c => c.Nacionalidad == dato);
                    case "Id":
                    case "id":
                        return Buscar(c => c.Id == int.Parse(dato));
                    default:
                        throw new ExcepcionesDelPrograma("Introduce un campo valido.");
                }
            }
        }
    }
}
