﻿using System;
using System.Text.RegularExpressions;

namespace Tipos
{
    public class Cliente

    { 
        private int id;
        private string nombre;
        private string apellidos;
        private string email;
        private string pass;
        private string dni;
        private DateTime? fechaNac;
        private string nacionalidad;
        private const string LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE";
        private static string sNumero;

        #region getters & setters
        public int Id { get => id; set => id = value; }
        public string Nombre {
            get => nombre;
            set {
                Regex regex = new Regex(@"[A-Za-z]{2,}");
                if (regex.IsMatch(value))
                    nombre = value;
                else
                    throw new ExcepcionesDelPrograma("El nombre debe contener minimo 2 letras.");
            }
        }
        public string Apellidos {
            get => apellidos;
            set
            {
                Regex regex = new Regex(@"\D{2,} \D{2,}");
                if (regex.IsMatch(value) || value == "")
                    apellidos = value;
                else
                    throw new ExcepcionesDelPrograma("Los apellidos deben contener minimo 5 letras y un espacio.");
            }
        }
        public string Email {
            get => email;
            set
            {
                Regex regex = new Regex(@"^(([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,})+)*$");
                if (regex.IsMatch(value))
                    email = value;
                else
                    throw new ExcepcionesDelPrograma("El email debe seguir el formato ejemplo@ejemplo.es.");
            }

        }
        public string Pass { get => pass; set => pass = value; }
        public string Dni {
            get => dni;
            set
            {
                if (value == null)
                {
                    throw new ExcepcionesDelPrograma("No se aceptan DNIs incorrectos");
                }

                if (!Regex.IsMatch(value, @"^[XYZ\d]\d{7}[" + LETRAS + "]$"))
                {
                    throw new ExcepcionesDelPrograma("El formato de DNI no es correcto");
                }

                if (!EsValidoDni(value))
                {
                    throw new ExcepcionesDelPrograma("El DNI no es válido");
                }
                dni = value;
            }
        }
        public DateTime? FechaNac {
            get => fechaNac;
            set {
                if (!value.HasValue) {
                    fechaNac = value;
                }
                else {
                    if (EsDeEdadLegalParaTrabajar(value.Value))
                        fechaNac = value;
                    else
                        throw new ExcepcionesDelPrograma("Debe ser mayor de 18 y menor de 65 años.");
                }
            }
        }
        public string Nacionalidad {
            get => nacionalidad;
            set
            {
                if (EsNacionalidadCorrecta(value) || value == "")
                    nacionalidad = value;
                else
                    throw new ExcepcionesDelPrograma("La nacionalidad no concuerda con tu NIF.");
            }
        }
        #endregion
        #region constructores
        public Cliente( string nombre, string apellidos, string email, string pass, string dni, DateTime fechaNac, string nacionalidad)
        {
            Nombre = nombre;
            Apellidos = apellidos;
            Email = email;
            Pass = pass;
            Dni = dni;
            FechaNac = fechaNac;
            Nacionalidad = nacionalidad;

        }
        public Cliente() { }
        #endregion

        public override string ToString()
        {
            return string.Format("Id: {0}\n, Nombre: {1}\n, Apellidos: {2}\n, Email: {3}\n, Pass: {4}\n, Dni: {5}\n, Fecha de Nacimiento: {6}\n, Nacionalidad: {7}\n",
                Id, Nombre, Apellidos, Email, Pass, Dni, FechaNac, Nacionalidad); 
        }
        public object this[int i]
        {
            get
            {
                switch (i)
                {
                    case 0: return Nombre;
                    case 1: return Apellidos;
                    case 2: return Email;
                    case 3: return Pass;
                    case 4: return Dni;
                    case 5: return FechaNac;
                    case 6: return Nacionalidad;

                    default: throw new ArgumentException("i");
                }
            }
            set
            {
                switch (i)
                {
                    case 0:  Nombre = (string)value; break;
                    case 1:  Apellidos = (string)value; break;
                    case 2:  Email = (string)value; break;
                    case 3:  Pass = (string)value; break;
                    case 4:  Dni = (string)value; break;
                    case 5:
                        DateTime? dt = string.IsNullOrEmpty((string)value) ? (DateTime?)null : Convert.ToDateTime(value);
                        FechaNac = dt; break;
                    case 6:  Nacionalidad = (string)value; break;

                    default: throw new ArgumentException("i");
                }
            }
        }

        #region Metodos para la fecha de nacimiento
        public static int Years(DateTime start, DateTime end)
        {
            return (end.Year - start.Year - 1) +
                (((end.Month > start.Month) ||
                ((end.Month == start.Month) && (end.Day >= start.Day))) ? 1 : 0);
        }
        public static bool EsDeEdadLegalParaTrabajar(DateTime fechaDeNacimiento)
        {
            DateTime today = DateTime.Today;
            int years =Years(fechaDeNacimiento, today);
            
            if (years > 17 && years < 66)
                return true;
            else
                return false;

        }
        #endregion
        #region Metodos para el DNI
        public static bool EsValidoDni(string dni)
        {
            sNumero = ExtraerNumero(dni);

            char letra = dni[8];

            string soloNumeros = sNumero.Replace('X', '0').Replace('Y', '1').Replace('Z', '2');

            return letra == CalcularLetra(int.Parse(soloNumeros));
        }

        private static string ExtraerNumero(string dni)
        {
            return dni.Substring(0, dni.Length - 1);
        }

        private static char CalcularLetra(int numero)
        {
            return LETRAS[numero % 23];
        }
        #endregion
        #region Metodos para la Nacionalidad
        private static bool EsNacionalidadCorrecta(string nacdad)
        {
            if (sNumero.StartsWith("Z") || sNumero.StartsWith("X") || sNumero.StartsWith("Y"))
            {
                if (nacdad == "Extranjero" || nacdad == "extranjero")
                    return true;
                else
                    return false;
            }
            else
            {
                if (nacdad == "Español" || nacdad == "español")
                    return true;
                else
                    return false;
            }
        }
        #endregion
    }
}
