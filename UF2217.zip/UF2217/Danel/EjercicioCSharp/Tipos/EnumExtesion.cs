﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipos
{
    public class EnumExtensions
    {
        public enum MyEnum
        {
            Nombre = 0,
            Apellidos = 1,
            Email = 2,
            Contraseña = 3,
            Dni = 4,
            FechaNacimiento = 5,
            Nacionaliad = 6,
            id = 7
        }

        public static string ToFriendlyString(MyEnum me)
        {
            switch (me)
            {
                case MyEnum.Nombre:
                    return "Introduce un nombre: ";
                case MyEnum.Apellidos:
                    return "Introduce los apellidos: ";
                case MyEnum.Email:
                    return "Introduce un email: ";
                case MyEnum.Contraseña:
                    return "Introduce una contraseña: ";
                case MyEnum.Dni:
                    return "Introduce un Dni: ";
                case MyEnum.FechaNacimiento:
                    return "Introduce tu fecha de nacimiento: ";
                case MyEnum.Nacionaliad:
                    return "Introduce tu nacionalidad: ";
                default:
                    return "";
            }
        }
    }
}
