﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tipos
{
    [Serializable]
    public class ExcepcionesDelPrograma: Exception
    {
        public ExcepcionesDelPrograma() { }
        public ExcepcionesDelPrograma(string message) : base(message) { }
        public ExcepcionesDelPrograma(string message, System.Exception inner) : base(message, inner) { }
        protected ExcepcionesDelPrograma(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
