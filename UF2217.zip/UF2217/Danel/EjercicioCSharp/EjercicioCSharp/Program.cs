﻿using System;
using Tipos;

namespace EjercicioCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Cliente c1 = new Cliente("danel", "riano Onaindia", "danel@riano.com", "danel", "12345678Z", new DateTime(1992, 5, 1), "español");
            Cliente c2 = new Cliente("jon", "sanchez amd", "jon@sanchez.com", "jon", "12345678Z", new DateTime(1997, 9, 24), "español");
            Cliente c3 = new Cliente("asier", "fernandez djdsd", "asier@fernandez.com", "asier", "12345678Z", new DateTime(1993, 2, 7), "español");
            Cliente c4 = new Cliente("mikel", "lorda sdks", "mikel@lorda.com", "mikel", "12345678Z", new DateTime(1985, 6, 14), "español");
            Cliente c5 = new Cliente("ander", "artegui sdd", "ander@artegui.com", "ander", "12345678Z", new DateTime(1955, 10, 28), "español");
            
            Grupo grupo = new Grupo("Clientes");
            grupo.Alta(c1);
            grupo.Alta(c2);
            grupo.Alta(c3);
            grupo.Alta(c4);
            grupo.Alta(c5);
            

            Console.WriteLine(c1.ToString());
            Console.WriteLine(c2.ToString());
            Console.WriteLine(c3.ToString());
            Console.WriteLine(c4.ToString());
            Console.WriteLine(c5.ToString());

            bool continuar = true;
            do
            {
                Console.Clear();
                Console.WriteLine("Menú:");
                Console.WriteLine("\t1. Alta");
                Console.WriteLine("\t2. Modificación");
                Console.WriteLine("\t3. Baja");
                Console.WriteLine("\t4. Ver Listado");
                Console.WriteLine("\t5. Buscar por Id");
                Console.WriteLine("\t6. Buscar por Nombre");
                Console.WriteLine("\t7. Buscar por Propiedad");
                Console.WriteLine("\t8. Salir");
                Console.WriteLine();

                Console.Write("Seleccione una opción del menú:");
                int.TryParse(Console.ReadLine(), out int contador);
                Console.WriteLine();
                try
                {
                    switch (contador)
                    {
                        case 1:
                            Console.WriteLine("\t******************DAR DE ALTA******************");
                            DarDeAlta(grupo);
                            break;
                        case 2:
                            Console.WriteLine("\t******************MODIFICAR******************");
                            Modificar(grupo);
                            break;
                        case 3:
                            Console.WriteLine("******************DAR DE BAJA******************");
                            DarDeBaja(grupo);
                            break;
                        case 4:
                            Console.WriteLine("\t******************VER LISTA******************");
                            VerListado(grupo);
                            break;
                        case 5:
                            Console.WriteLine("\t******************BUSCAR POR ID******************");
                            BuscarPorId(grupo);
                            break;
                        case 6:
                            Console.WriteLine("\t******************BUSCAR POR NOMBRE******************");
                            BuscarPorNombre(grupo);
                            break;
                        case 7:
                            Console.WriteLine("\t******************BUSCAR******************");
                            Buscar(grupo);
                            break;
                        case 8:
                            Console.WriteLine("salir de la aplicación.");
                            continuar = false;
                            return;
                        default:
                             throw new ExcepcionesDelPrograma("Introduce una opción valida.");
                            
                        
                    }
                
                    Console.WriteLine("----------------------------------------");
                    Console.Write("¿volver al menu? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                    {
                        continuar = false;
                        Console.WriteLine("hasta luego xD");
                    }
                }
                catch(ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                    System.Threading.Thread.Sleep(3000);
                }
            } while (continuar);
           
        }

        private static void DarDeAlta(Grupo grupo)
        {
            Cliente nuevoCliente = new Cliente();
            nuevoCliente = IntroducirDatos(nuevoCliente);
            grupo.Alta(nuevoCliente);
            Console.WriteLine("\t********************************************");
            Console.WriteLine("\tEl cliente ha sido añadido correctamente.");
            Console.WriteLine("\t********************************************");
        }

        private static void Modificar(Grupo grupo)
        {
            bool repetir = true, encontrado = false;
            do
            {
                try
                {
                    Console.Write("Seleccione el id del cliente que quieres modificar:");
                    int.TryParse(Console.ReadLine(), out int idCliente);
                    foreach (var item in grupo.Listado)
                    {
                        if(item.Id == idCliente)
                        {
                            Cliente usuarioModificado = new Cliente();
                            usuarioModificado = IntroducirDatos(usuarioModificado);
                            grupo.Modificar(idCliente, usuarioModificado);
                            Console.WriteLine("********************************************");
                            Console.WriteLine("\tEl usuario has sido modificado correctamente");
                            Console.WriteLine("********************************************");
                            repetir = false;
                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado)
                    {
                        throw new ExcepcionesDelPrograma("No eiste el Id indicado.");
                    }
                    
                }
                catch (ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.Write("¿Desea modificar a otro cliente? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                        repetir = false;
                }


            } while (repetir);
        }

        private static void DarDeBaja(Grupo grupo)
        {
            bool repetir = true;
            do
            {
                try
                {
                    Console.Write("Seleccione el id del cliente que quieres dar de baja:");
                    bool idCorrecto = int.TryParse(Console.ReadLine(), out int id);
                    if (!idCorrecto)
                    {
                        throw new ExcepcionesDelPrograma("introduce un numero.");
                    }
                    Console.Write("Estas seguro de que deseas dar de baja al usuario {0} [s, n]", id);
                    char.TryParse(Console.ReadLine(), out char respuesta);
                    if (respuesta == 's' || respuesta == 'S')
                    {
                        grupo.DarDeBaja(id);
                        Console.WriteLine("********************************************");
                        Console.WriteLine("\tDiste de baja al usuario con id" + id);
                        Console.WriteLine("********************************************");
                        repetir = false;
                    }
                    
                }
                catch (ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.Write("¿Desea dar de baja a otro cliente? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                        repetir = false;
                }

            } while (repetir);
        }

        private static void VerListado(Grupo grupo)
        {
            foreach (var item in grupo.Listado)
            {
                Console.WriteLine(item.ToString());
            }
            /*for (int i = 0; i < grupo.Listado.Count; i++)
            {
                Console.WriteLine(grupo.Listado[i].ToString());
            }*/
        }

        private static void BuscarPorId(Grupo grupo)
        {
            bool repetir = true;
            do
            {
                try
                {
                    Console.Write("Introduce un Id de usuario:");
                    int.TryParse(Console.ReadLine(), out int idUsuario);
                    Cliente buscadoPorId = grupo.BuscarPorId(idUsuario);
                    Console.WriteLine(buscadoPorId.ToString());
                    repetir = false;
                }
                catch (ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.Write("¿Desea buscar a otro cliente por Id? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                        repetir = false;
                }

            } while (repetir);
        }

        private static void BuscarPorNombre(Grupo grupo)
        {
            bool repetir = true;
            do
            {
                try
                {
                    Console.Write("Introduce un nombre del usuario:");
                    string NombreUsuario = Console.ReadLine();
                    var buscadoPorNombre = grupo.BuscarPorNombre(NombreUsuario);
                    if (buscadoPorNombre.Count == 0)
                    {
                        repetir = false;
                        throw new ExcepcionesDelPrograma("El cliente no se ha dado de alta.");
                    }
                    else
                    {
                        foreach (var item in buscadoPorNombre)
                        {
                            Console.WriteLine(item);
                        }
                    }
                    repetir = false;
                }
                catch (ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.Write("¿Desea buscar a otro cliente por nombre? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                        repetir = false;
                }

            } while (repetir);
        }

        private static void Buscar(Grupo grupo)
        {
            bool repetir = true;
            do
            {
                try
                {
                    Console.Write("Introduce la propiedad por la que quieres buscar:");
                    string propiedad = Console.ReadLine();
                    Console.Write("Introduce el dato a buscar:");
                    string dato = Console.ReadLine();
                    var buscado = grupo[propiedad, dato];
                    if (buscado.Count == 0)
                    {
                        repetir = false;
                        throw new ExcepcionesDelPrograma("El cliente no se ha dado de alta.");
                    }
                    else
                    {
                        foreach (var item in buscado)
                        {
                            Console.WriteLine(item);
                        }
                    }
                    repetir = false;
                }
                catch (ExcepcionesDelPrograma e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    Console.Write("¿Desea buscar a otro cliente? [s, n]");
                    char.TryParse(Console.ReadLine(), out char respuestaContinuacion);
                    if (respuestaContinuacion == 'n' || respuestaContinuacion == 'N')
                        repetir = false;
                }
            } while (repetir);
        }

        private static Cliente IntroducirDatos(Cliente cliente)
        {
            
            int contIndex = 0;
            
            foreach (EnumExtensions.MyEnum item in Enum.GetValues(typeof(EnumExtensions.MyEnum)))
            {

                bool esErroneo = true;
                
                do
                {
                    try
                    {
                        if (item == EnumExtensions.MyEnum.id)
                            esErroneo = false;
                        else
                        {
                            Console.Write(EnumExtensions.ToFriendlyString(item));
                            cliente[contIndex] = Console.ReadLine();
                            contIndex++;
                            esErroneo = false;
                        }

                    }
                    catch (ExcepcionesDelPrograma e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                } while (esErroneo);
            }
                
            return cliente;
        }
    }
    
}
